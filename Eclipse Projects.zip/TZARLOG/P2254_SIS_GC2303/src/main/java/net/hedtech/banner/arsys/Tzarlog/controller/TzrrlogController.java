package net.hedtech.banner.arsys.Tzarlog.controller;

import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.util.globals.Globals.setGlobal;
import net.hedtech.general.common.forms.controller.DefaultBlockController;
import net.hedtech.banner.arsys.Tzarlog.TzarlogTask;
import net.hedtech.banner.arsys.Tzarlog.model.TzarlogModel;
import morphis.foundations.core.appsupportlib.runtime.action.*;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;

import static morphis.foundations.core.types.Types.*;
import morphis.core.utils.behavior.annotations.*;
import morphis.foundations.core.appdatalayer.data.*;
import morphis.foundations.core.appsupportlib.exceptions.ApplicationException;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import net.hedtech.general.common.dbservices.GNls;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.nextBlock;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.errorMessage;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.runtime.*;
import net.hedtech.banner.arsys.Tzarlog.model.*;
import morphis.foundations.core.appdatalayer.events.BeforeQuery;
import morphis.foundations.core.appdatalayer.events.QueryEvent;

public class TzrrlogController extends DefaultBlockController {

	public TzrrlogController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public TzarlogTask getTask() {
		return (TzarlogTask) super.getTask();
	}

	public TzarlogModel getFormModel() {
		return getTask().getModel();
	}

	@After
	@ActionTrigger(action="PRE-BLOCK", function=KeyFunction.BLOCK_IN)
	public void tzrrlog_blockIn()
	{
		//TODO to be filled by the user
	}

	@BeforeQuery
	public void tzrrlog_BeforeQuery(QueryEvent queryEvent) {
		((IDBBusinessObject) queryEvent.getSource()).getSelectCommandParams()
		.add(DbManager.getDataBaseFactory().createDataParameter("DATE_FROM", NString.toStr(getFormModel().getKeyBlock().getProcessDateFrom())));
		

		((IDBBusinessObject) queryEvent.getSource()).getSelectCommandParams()
		.add(DbManager.getDataBaseFactory().createDataParameter("DATE_TO", NString.toStr(getFormModel().getKeyBlock().getProcessDateTo())));

		NNumber pidm = NNumber.getNull();
		
		if(this.getFormModel().getKeyBlock().getId().isNotNull()) {
			pidm = this.getTask().getServices().IDToPidm(this.getFormModel().getKeyBlock().getId());
		} 
		
		((IDBBusinessObject) queryEvent.getSource()).getSelectCommandParams()
		.add(DbManager.getDataBaseFactory().createDataParameter("PIDM", pidm));	
		
		if (getFormModel().getKeyBlock().getProcess().equals("TODOS") || getFormModel().getKeyBlock().getProcess().isNull()) {
			((IDBBusinessObject) queryEvent.getSource()).getSelectCommandParams()
			.add(DbManager.getDataBaseFactory().createDataParameter("PROCESS", NString.toStr("ALL")));

		} else { 
			((IDBBusinessObject) queryEvent.getSource()).getSelectCommandParams()
			.add(DbManager.getDataBaseFactory().createDataParameter("PROCESS", getFormModel().getKeyBlock().getProcess()));
			System.out.println("PROCESS = "+getFormModel().getKeyBlock().getProcess());
		}
		

		((IDBBusinessObject) queryEvent.getSource()).getSelectCommandParams()
		.add(DbManager.getDataBaseFactory().createDataParameter("ID_PROCESS", getFormModel().getKeyBlock().getIdProcess()));

	}
	
}