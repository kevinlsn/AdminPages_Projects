package net.hedtech.banner.arsys.Tzarlog.services;

import morphis.foundations.core.appdatalayer.data.DataCursor;
import morphis.foundations.core.appdatalayer.data.ResultSet;
import morphis.foundations.core.appsupportlib.runtime.ISupportCodeContainer;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.common.forms.baseForm.services.DefaultSupportCodeObject;
import net.hedtech.banner.arsys.Tzarlog.TzarlogTask;
import net.hedtech.banner.arsys.Tzarlog.model.TzarlogModel;

public class TzarlogServices extends DefaultSupportCodeObject {

	public TzarlogServices(ISupportCodeContainer container) {
		super(container);
	}

	public TzarlogTask getTask() {
		return (TzarlogTask) super.getContainer();
	}

	public TzarlogModel getFormModel() {
		return getTask().getModel();
	}

	// TODO: put your services here
	
	public NNumber validateProcessName(NString processName) {
	    NNumber countC = NNumber.toNumber(0);	
		String consultaTzarlog = "select count(TZRRLOG_PROCESS) from tzrrlog where TZRRLOG_PROCESS = :proc";
		DataCursor tzarlogCursor = new DataCursor(consultaTzarlog);
		
		try {
			tzarlogCursor.addParameter("proc", processName);
			tzarlogCursor.open();
			ResultSet tzarlogCursorResults = tzarlogCursor.fetchInto();
			
			if (tzarlogCursorResults != null) 
				countC = tzarlogCursorResults.getNumber(0);
		
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			tzarlogCursor.close();
		}	
		
		return countC;

	}
	
	public NNumber existsIdOnSpriden (NString id) {

		NNumber counter = NNumber.toNumber(0);
		
		if(id.isNotNull()) {
			
			DataCursor cursor = new DataCursor("SELECT COUNT(SPRIDEN_ID) FROM SPRIDEN WHERE SPRIDEN_ID = :SPRIDEN_ID");
			
			try {
				cursor.addParameter("SPRIDEN_ID", id);
				cursor.open();
				ResultSet result = cursor.fetchInto();
					
				if (result != null) {
					counter = result.getNumber(0);
				}
			} catch (Exception e) {
				if(e != null) {
					System.out.println(e.getLocalizedMessage());
				}	
			} finally {
				if (cursor.isOpen()) {
					cursor.close();
					cursor.dispose();
				}
			}
			
		}
		
		return counter;
	}
	
	public NNumber IDToPidm (NString id) {
		NNumber pidm = NNumber.toNumber(-1);
		DataCursor cursor = new DataCursor("select gb_common.f_get_pidm(:ID) from dual");
			
		try {
			cursor.addParameter("ID", id);
			cursor.open();
			ResultSet result = cursor.fetchInto();
				
			if (result != null) {
				pidm = result.getNumber(0);
			}
		} catch (Exception e) {
			if(e != null) {
				System.out.println(e.getLocalizedMessage());
			}	
		} finally {
			if (cursor.isOpen()) {
				cursor.close();
				cursor.dispose();
			}
		}
		
		return pidm;
	}

}