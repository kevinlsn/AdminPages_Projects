package net.hedtech.banner.arsys.Tzarlog.controller;

import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import net.hedtech.general.common.forms.controller.DefaultBlockController;
import net.hedtech.banner.arsys.Tzarlog.TzarlogTask;
import net.hedtech.banner.arsys.Tzarlog.model.TzarlogModel;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.exceptions.ApplicationException;
import net.hedtech.general.common.dbservices.GNls;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.nextBlock;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.errorMessage;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;

public class KeyBlockController extends DefaultBlockController {

	public KeyBlockController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public TzarlogTask getTask() {
		return (TzarlogTask) super.getTask();
	}

	public TzarlogModel getFormModel() {
		return getTask().getModel();
	}

	@ActionTrigger(action="KEY-NXTBLK", function=KeyFunction.NEXT_BLOCK)
	public void keyBlock_NextBlock()
	{
		nextBlock();
		executeQuery();
		executeAction("DISABLE_KEYS");
	}

	@ActionTrigger(action="POST-BLOCK", function=KeyFunction.BLOCK_OUT)
	public void keyBlock_blockOut()
	{
		getFormModel().getButtonControlBlock().setCheckKeys(toStr("Y"));
	}

	@ActionTrigger(item = "PROCESS", function = KeyFunction.LIST_VALUES)
	public void process_KeyAction_list_values() {
		listValues();
		nextItem();
	}
	
	@ActionTrigger(action="WHEN-BUTTON-PRESSED", item="ID_LBT")
	public void tzrrlogId_buttonClick() {
		this.getTask().getGoqrpls().gKeyOptMenu(toStr("KEY_BLOCK.ID"), 
				GNls.Fget(toStr("TZARLOG-0050"), toStr("FORM"), toStr("Person search (SOAIDEN)")), toStr("LIST_VALUES"), 
				GNls.Fget(toStr("TZARLOG-0051"), toStr("FORM"), toStr("Non-Person search (SOACOMP)")), toStr("COUNT_QUERY"), 
				GNls.Fget(toStr("TZARLOG-0052"), toStr("FORM"), toStr("Alternate ID search (GUIALTI)")), toStr("DUPLICATE_ITEM"), toStr(""), toStr(""));
		this.getTask().getGoqrpls().gCheckFailure();
		getFormModel().getButtonControlBlock().setCheckKeys(toStr("N"));
	}

	@ActionTrigger(action="KEY_LISTVAL", item="ID", function=KeyFunction.LIST_VALUES)
	public void id_KeyAction_list_values() {
		getTask().getGoqrpls().gCopyFldAttr();
		executeAction("G$_REVOKE_ACCESS");
		getTask().getGoqrpls().gCheckFailure();
		getTask().getGoqrpls().gSecuredFormCall(getGlobal("CURRENT_USER"), toStr("SOAIDEN"), toStr("QUERY"));
		getTask().getGoqrpls().gResetGlobal();
		
		if (!getGlobal("VALUE").isNull()) {
			getFormModel().getKeyBlock().setId(NString.toStr(getGlobal("VALUE")));
			getTask().getGoqrpls().gCheckFailure();
			nextItem();
		}
	}

	@ActionTrigger(action="KEY-CQUERY", item = "ID", function = KeyFunction.COUNT_QUERY)
	public void id_KeyAction_count_query() {
		executeAction("G$_REVOKE_ACCESS");
		getTask().getGoqrpls().gCheckFailure();
		getTask().getGoqrpls().gSecuredFormCall(getGlobal("CURRENT_USER"), toStr("SOACOMP"), toStr("QUERY"));
		
		if (!getGlobal("VALUE").isNull() ){
			getFormModel().getKeyBlock().setId(NString.toStr(getGlobal("VALUE")));
			getTask().getGoqrpls().gCheckFailure();
			nextItem();
		}
	}

	@ActionTrigger(action="KEY-DUP-ITEM", item = "ID", function = KeyFunction.DUPLICATE_ITEM)
	public void id_KeyAction_duplicate_item() {
		executeAction("G$_REVOKE_ACCESS");
		getTask().getGoqrpls().gSecuredFormCall(getGlobal("CURRENT_USER"), toStr("GUIALTI"), toStr("QUERY"));
		getTask().getGoqrpls().gResetGlobal();
		
		if (!getGlobal("VALUE").isNull()){
			getFormModel().getKeyBlock().setId(NString.toStr(getGlobal("VALUE")));
			getTask().getGoqrpls().gCheckFailure();
			nextItem();
		}
	}
	
	@ValidationTrigger(item = "PROCESS_DATE_FROM")
	public void process_date_from_validation() {
		if(getFormModel().getKeyBlock().getProcessDateFrom().greater(getFormModel().getKeyBlock().getProcessDateTo())) {
			errorMessage(GNls.Fget(toStr("TZARLOG-0001"), toStr("FORM"), toStr("*ERROR* Fecha Desde no puede ser mayor a Fecha Hasta.")));		
			goItem("PROCESS_DATE_FROM");
			throw new ApplicationException();
		}
	}

	@ValidationTrigger(item = "PROCESS_DATE_TO")
	public void process_date_to_validation() {
		if(getFormModel().getKeyBlock().getProcessDateTo().lesser(getFormModel().getKeyBlock().getProcessDateFrom())) {
			errorMessage(GNls.Fget(toStr("TZARLOG-0002"), toStr("FORM"), toStr("*ERROR* Fecha Hasta no puede ser menor a Fecha Desde.")));
			goItem("PROCESS_DATE_TO");
			throw new ApplicationException();
		}
	}

	@ValidationTrigger(item = "PROCESS")
	public void process_validation() {
		
		NNumber validateProcess = this.getTask().getServices().validateProcessName(this.getFormModel().getKeyBlock().getProcess());
		if(validateProcess.equals(NNumber.toNumber(0)) && this.getFormModel().getKeyBlock().getProcess().notEquals("TODOS")) {
			errorMessage(GNls.Fget(toStr("TZARLOG-0003"), toStr("FORM"), toStr("Enter a valid Process.")));			
			goItem("PROCESS");
			throw new ApplicationException();
		}	
	}

	@ValidationTrigger(item = "ID")
	public void id_validation() {	
		
		if(this.getFormModel().getKeyBlock().getId().isNotNull()) {
			
			NNumber validateIDSpriden = this.getTask().getServices().existsIdOnSpriden(this.getFormModel().getKeyBlock().getId());
			
			if (validateIDSpriden.equals(NNumber.toNumber(0))) {
				errorMessage(GNls.Fget(toStr("TZARLOG-0004"), toStr("FORM"), toStr("Invalid ID, please verify and try again.")));
				goItem("ID");
				throw new ApplicationException();
			}	
		}
		
	}
	
}