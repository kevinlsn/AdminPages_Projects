package net.hedtech.banner.arsys.Tzarlog.controller;

import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import morphis.foundations.core.appsupportlib.runtime.action.MenuTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.AbstractMenuController;
import net.hedtech.banner.arsys.Tzarlog.TzarlogTask;
import net.hedtech.banner.arsys.Tzarlog.model.TzarlogModel;

public class OptionListIdMenuController extends AbstractMenuController {

	public OptionListIdMenuController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public TzarlogTask getTask() {
		return (TzarlogTask) super.getTask();
	}

	public TzarlogModel getFormModel() {
		return getTask().getModel();
	}

	@MenuTrigger(item="SOACOMP_OPTION")
	public void soacompOptionClick() {
		// TODO Auto-generated method stub
	}

	@MenuTrigger(item="SOAIDEN_OPTION")
	public void soaidenOptionClick() {
		// TODO Auto-generated method stub
	}
	
	@MenuTrigger(item="GUIALTI_OPTION")
	public void guialtiOptionClick() {
		// TODO Auto-generated method stub
	}
}