package net.hedtech.banner.arsys.Tzarlog.model;

import java.util.Date;
import java.math.BigDecimal;
import org.jdesktop.databuffer.DataRow;
//import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.types.*;
import morphis.foundations.core.appsupportlib.model.*;
import morphis.foundations.flavors.forms.appdatalayer.data.BaseRowAdapter;

public class TzrrlogDetailAdapter extends BaseRowAdapter {

	public TzrrlogDetailAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NString getTzrrlogLog() {
		NString v = new NString((String)this.getValue("TZRRLOG_LOG"));
		return v;
	}
	
	public void setTzrrlogLog(NString value) {
		this.setValue("TZRRLOG_LOG", value.getValue());
	}

	public NString getTzrrlogUserId() {
		NString v = new NString((String)this.getValue("TZRRLOG_USER_ID"));
		return v;
	}
	
	public void setTzrrlogUserId(NString value) {
		this.setValue("TZRRLOG_USER_ID", value.getValue());
	}

	public NDate getTzrrlogActivityDate() {
		NDate v = new NDate((java.util.Date)this.getValue("TZRRLOG_ACTIVITY_DATE"));
		return v;
	}
	
	public void setTzrrlogActivityDate(NDate value) {
		this.setValue("TZRRLOG_ACTIVITY_DATE", value.getValue());
	}

}