package net.hedtech.banner.arsys.Tzarlog.model;

import morphis.foundations.core.appsupportlib.model.SimpleBusinessObject;
import morphis.foundations.core.appsupportlib.model.configuration.SimpleBusinessObjectConfiguration;
import morphis.foundations.core.types.*;
import static morphis.foundations.core.types.Types.*;

public class KeyBlock extends morphis.foundations.flavors.forms.appsupportlib.model.SimpleBusinessObject {

	public KeyBlock() {
		super();
	}

	public KeyBlock(SimpleBusinessObjectConfiguration configuration, String name) {
		super(configuration, name);
	}
	
	public NDate getProcessDateFrom() {
		return toDate(super.getValue("PROCESS_DATE_FROM"));
	}
	
	public void setProcessDateFrom(NDate value) {
		super.setValue("PROCESS_DATE_FROM", value);
	}

	public NDate getProcessDateTo() {
		return toDate(super.getValue("PROCESS_DATE_TO"));
	}
	
	public void setProcessDateTo(NDate value) {
		super.setValue("PROCESS_DATE_TO", value);
	}

	public NString getId() {
		return toStr(super.getValue("ID"));
	}
	
	public void setId(NString value) {
		super.setValue("ID", value);
	}

	public NString getProcess() {
		return toStr(super.getValue("PROCESS"));
	}
	
	public void setProcess(NString value) {
		super.setValue("PROCESS", value);
	}

	public NString getIdProcess() {
		return toStr(super.getValue("ID_PROCESS"));
	}
	
	public void setIdProcess(NString value) {
		super.setValue("ID_PROCESS", value);
	}

	public NString getIdLbt() {
		return toStr(super.getValue("ID_LBT"));
	}

	public void setIdLbt(NString value) {
		super.setValue("ID_LBT", value);
	}
}