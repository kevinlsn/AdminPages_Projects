package net.hedtech.banner.arsys.Tzarlog;

import java.util.Hashtable;
import net.hedtech.general.common.forms.BaseTask;

public class TzarlogTask extends BaseTask {
	public TzarlogTask(String taskName) {
		super(taskName);
	}
	
	public TzarlogTask(String taskName, Hashtable sharedLibraries, Hashtable parameters) {
		super(taskName, sharedLibraries, parameters);
	}
	
	@Override
	public net.hedtech.banner.arsys.Tzarlog.model.TzarlogModel getModel() {
		return (net.hedtech.banner.arsys.Tzarlog.model.TzarlogModel)super.getModel();
	}
	
	public net.hedtech.banner.arsys.Tzarlog.services.TzarlogServices getServices() {
		return (net.hedtech.banner.arsys.Tzarlog.services.TzarlogServices)getSupportCodeManager().getServices();
	}
	
	// Attached Libraries
	
	public net.hedtech.general.common.libraries.Goqrpls.GoqrplsServices getGoqrpls() {
		return (net.hedtech.general.common.libraries.Goqrpls.GoqrplsServices)getSupportCodeManager().getLibrary("GOQRPLS");
	}
}
