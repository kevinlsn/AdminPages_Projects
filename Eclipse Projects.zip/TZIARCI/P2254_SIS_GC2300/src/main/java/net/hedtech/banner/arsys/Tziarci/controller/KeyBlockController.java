package net.hedtech.banner.arsys.Tziarci.controller;

import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.util.globals.Globals.setGlobal;
import static net.hedtech.general.common.forms.services.BaseTaskServices.executeAction;

import net.hedtech.general.common.forms.controller.DefaultBlockController;
import net.hedtech.banner.arsys.Tziarci.TziarciTask;
import net.hedtech.banner.arsys.Tziarci.model.TbraccdTzrarciAdapter;
import net.hedtech.banner.arsys.Tziarci.model.TziarciModel;
import morphis.foundations.core.appsupportlib.runtime.action.*;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;

import static morphis.foundations.core.types.Types.*;
import morphis.core.utils.behavior.annotations.*;
import morphis.foundations.core.appdatalayer.data.*;
import morphis.foundations.core.appsupportlib.exceptions.ApplicationException;
import net.hedtech.general.common.dbservices.GNls;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.nextBlock;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.errorMessage;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.runtime.*;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appdatalayer.events.AfterQuery;

public class KeyBlockController extends DefaultBlockController {

	public KeyBlockController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public TziarciTask getTask() {
		return (TziarciTask) super.getTask();
	}

	public TziarciModel getFormModel() {
		return getTask().getModel();
	}

	@ActionTrigger(action="KEY-NXTBLK", function=KeyFunction.NEXT_BLOCK)
	public void keyBlock_NextBlock()
	{
		nextBlock();
		executeQuery();
		executeAction("DISABLE_KEYS");
	}

	@ActionTrigger(action="POST-BLOCK", function=KeyFunction.BLOCK_OUT)
	public void keyBlock_blockOut()
	{
		getFormModel().getButtonControlBlock().setCheckKeys(toStr("Y"));
	}
	
	@ActionTrigger(item = "CURRENCY", function = KeyFunction.LIST_VALUES)
	public void currency_KeyAction_list_values() {
		listValues();
		nextItem();
	}
	
	@ActionTrigger(item = "ID_LBT", action = "WHEN-BUTTON-PRESSED")
	public void id_action() {
		this.getTask().getGoqrpls().gKeyOptMenu(toStr("KEY_BLOCK.ID"), 
				GNls.Fget(toStr("TZIARCI-0050"), toStr("FORM"), toStr("Person search (SOAIDEN)")), toStr("LIST_VALUES"), 
				GNls.Fget(toStr("TZIARCI-0051"), toStr("FORM"), toStr("Non-Person search (SOACOMP)")), toStr("COUNT_QUERY"), 
				GNls.Fget(toStr("TZIARCI-0052"), toStr("FORM"), toStr("Alternate ID search (GUIALTI)")), toStr("DUPLICATE_ITEM"), 
				toStr(""), toStr(""));
		this.getTask().getGoqrpls().gCheckFailure();
		getFormModel().getButtonControlBlock().setCheckKeys(toStr("N"));
	}
	
	@ActionTrigger(action="KEY_LISTVAL", item = "ID", function = KeyFunction.LIST_VALUES)
	public void id_KeyAction_list_values() {
		getTask().getGoqrpls().gCopyFldAttr();
		executeAction("G$_REVOKE_ACCESS");
		getTask().getGoqrpls().gCheckFailure();
		getTask().getGoqrpls().gSecuredFormCall(getGlobal("CURRENT_USER"), toStr("SOAIDEN"), toStr("QUERY"));
		getTask().getGoqrpls().gResetGlobal();
		
		if (!getGlobal("VALUE").isNull()) {
			getFormModel().getKeyBlock().setId(NString.toStr(getGlobal("VALUE")));
			getFormModel().getKeyBlock().setUserName(this.getTask().getServices().getIDDescription(this.getFormModel().getKeyBlock().getId()));
			getTask().getGoqrpls().gCheckFailure();
			nextItem();
		}
		
	}
	
	@ActionTrigger(action="KEY-CQUERY", item = "ID", function = KeyFunction.COUNT_QUERY)
	public void id_KeyAction_count_query() {
		executeAction("G$_REVOKE_ACCESS");
		getTask().getGoqrpls().gCheckFailure();
		getTask().getGoqrpls().gSecuredFormCall(getGlobal("CURRENT_USER"), toStr("SOACOMP"), toStr("QUERY"));
		
		if (!getGlobal("VALUE").isNull()){
			this.getFormModel().getKeyBlock().setId(NString.toStr(getGlobal("VALUE")));
			this.getFormModel().getKeyBlock().setUserName(this.getTask().getServices().getIDDescription(this.getFormModel().getKeyBlock().getId()));
			getTask().getGoqrpls().gCheckFailure();
			nextItem();
		}
	}
	
	@ActionTrigger(action="KEY-DUP-ITEM", item = "ID", function = KeyFunction.DUPLICATE_ITEM)
	public void id_KeyAction_duplicate_item() {
		executeAction("G$_REVOKE_ACCESS");
		getTask().getGoqrpls().gSecuredFormCall(getGlobal("CURRENT_USER"), toStr("GUIALTI"), toStr("QUERY"));
		getTask().getGoqrpls().gResetGlobal();
		
		if (!getGlobal("VALUE").isNull()){
			this.getFormModel().getKeyBlock().setId(NString.toStr(getGlobal("VALUE")));
			this.getFormModel().getKeyBlock().setUserName(this.getTask().getServices().getIDDescription(this.getFormModel().getKeyBlock().getId()));
			getTask().getGoqrpls().gCheckFailure();
			nextItem();
		}
	}

	@ValidationTrigger(item = "CURRENCY")
	public void currency_validation() {
		NNumber currencyCode = this.getTask().getServices().getCurrencyCode(this.getFormModel().getKeyBlock().getCurrency());
		if (this.getFormModel().getKeyBlock().getCurrency().isNotNull()) {
			if(currencyCode.equals(NNumber.toNumber(0))) {
				errorMessage(GNls.Fget(toStr("TZIARCI-0001"), toStr("FORM"), toStr("*ERROR* Currency does not exist")));
				goItem("KEY_BLOCK.CURRENCY");
				throw new ApplicationException();
			} 	
		} else {
			this.getFormModel().getKeyBlock().setCurrency(NString.toStr("MXN"));
		} 	
	}

	@ValidationTrigger(item = "ID")
	public void id_validation() {
		if(this.getFormModel().getKeyBlock().getId().isNull()) {
			errorMessage(GNls.Fget(toStr("TZIARCI-0003"), toStr("FORM"), toStr("ID must be entered.")));
			goItem("KEY_BLOCK.ID_LBT");
			throw new ApplicationException();
		} else {
			NNumber validateIDSpriden = this.getTask().getServices().existsIdOnSpriden(this.getFormModel().getKeyBlock().getId());
			if (validateIDSpriden.equals(NNumber.toNumber(0))) {
				errorMessage(GNls.Fget(toStr("TZIARCI-0002"), toStr("FORM"), toStr("*ERROR* Invalid ID, please verify and try again.")));
				goItem("KEY_BLOCK.ID_LBT");
				throw new ApplicationException();
			}
			this.getFormModel().getKeyBlock().setUserName(this.getTask().getServices().getIDDescription(
					this.getFormModel().getKeyBlock().getId()));
		}
	}

}