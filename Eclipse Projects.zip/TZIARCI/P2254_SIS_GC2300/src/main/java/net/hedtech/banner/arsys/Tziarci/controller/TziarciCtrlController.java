package net.hedtech.banner.arsys.Tziarci.controller;

import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;

import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.types.Types.toNumber;
import static morphis.foundations.core.util.globals.Globals.setGlobal;

import java.util.Map;

import net.hedtech.general.common.forms.controller.DefaultBlockController;
import net.hedtech.banner.arsys.Tziarci.TziarciTask;
import net.hedtech.banner.arsys.Tziarci.model.TbraccdTzrarciAdapter;
import net.hedtech.banner.arsys.Tziarci.model.TziarciModel;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;
import morphis.foundations.core.appdatalayer.events.BeforeQuery;
import morphis.foundations.core.appdatalayer.events.QueryEvent;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import morphis.foundations.core.appdatalayer.events.CurrentChanged;
import java.util.EventObject;

public class TziarciCtrlController extends DefaultBlockController {

	public TziarciCtrlController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public TziarciTask getTask() {
		return (TziarciTask) super.getTask();
	}

	public TziarciModel getFormModel() {
		return getTask().getModel();
	}
		
}