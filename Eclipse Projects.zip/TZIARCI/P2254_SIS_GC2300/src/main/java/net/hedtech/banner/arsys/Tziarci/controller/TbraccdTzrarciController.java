package net.hedtech.banner.arsys.Tziarci.controller;

import morphis.foundations.core.appsupportlib.exceptions.ApplicationException;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.util.Ref;

import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.errorMessage;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.types.Types.toNumber;
import static morphis.foundations.core.util.globals.Globals.setGlobal;

import java.util.Map;

import net.hedtech.general.common.dbservices.GNls;
import net.hedtech.general.common.forms.controller.DefaultBlockController;
import net.hedtech.banner.arsys.Tziarci.TziarciTask;
import net.hedtech.banner.arsys.Tziarci.model.TbraccdTzrarciAdapter;
import net.hedtech.banner.arsys.Tziarci.model.TziarciCtrl;
import net.hedtech.banner.arsys.Tziarci.model.TziarciModel;
import morphis.foundations.core.appdatalayer.data.DbManager;
import morphis.foundations.core.appdatalayer.events.BeforeQuery;
import morphis.foundations.core.appdatalayer.events.QueryEvent;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appdatalayer.events.AfterQuery;
import morphis.foundations.core.appdatalayer.events.QueryExecute;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.EventObject;
import morphis.foundations.core.appdatalayer.events.QueryComplete;
import morphis.foundations.core.appdatalayer.events.QueryExecuted;
import morphis.foundations.core.appsupportlib.runtime.action.RecordValidationTrigger;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;

public class TbraccdTzrarciController extends DefaultBlockController {

	Map<String, NNumber> balances;
	
	public TbraccdTzrarciController(IFormController parentController, String name) {
		super(parentController, name);
		
	}

	@Override
	public TziarciTask getTask() {
		return (TziarciTask) super.getTask();
	}

	public TziarciModel getFormModel() {
		return getTask().getModel();
	}
	
	public TbraccdTzrarciAdapter getRowAdapter() {
		return (TbraccdTzrarciAdapter) this.getFormModel().getTbraccdTzrarci().getRowAdapter(true);
	}

	@BeforeQuery
	public void tbraccd_tzrarci_BeforeQuery(QueryEvent queryEvent) {
			
		NNumber pidm = this.getTask().getServices().IDToPidm(this.getFormModel().getKeyBlock().getId());
		NString currency = this.getFormModel().getKeyBlock().getCurrency();
		
		if(currency.isNull()) {
			currency = NString.toStr("MXN");
		}
		
		((IDBBusinessObject) queryEvent.getSource()).getSelectCommandParams()
		.add(DbManager.getDataBaseFactory().createDataParameter("PIDM",pidm));
		
		((IDBBusinessObject) queryEvent.getSource()).getSelectCommandParams()
		.add(DbManager.getDataBaseFactory().createDataParameter("CURR_CODE",currency));
		
		this.getFormModel().getTziarciCtrl().setQueryBalance(toNumber(0.00));
		this.balances = this.getTask().getServices().P_TZRARCI_CALC(pidm,currency);
			
	}
	

	@AfterQuery
	public void tbraccd_tzrarci_AfterQuery(RowAdapterEvent rowAdapterEvent) {	
		
		if(this.getRowAdapter()==null) return;
		
		NString levelCode = this.getRowAdapter().getTzrarciLevlCode();
		NNumber pidm = this.getRowAdapter().getTbraccdPidm();
		NNumber tranNumber = this.getRowAdapter().getTbraccdTranNumber();
		NString invoiceStatusInd = this.getRowAdapter().getTzrarciInvoiceStatusInd();
		NString typeInd = this.getTask().getServices().getDetailCodeTypeInd(this.getRowAdapter().getTbraccdDetailCode());
		this.getRowAdapter().setChargeAmount(this.getRowAdapter().getTbraccdAmount());	
		
		if(levelCode.isNotNull()) this.getRowAdapter().setDescLevel(this.getTask().getServices().levelDescription(levelCode));
		this.getRowAdapter().setTaxType(this.getTask().getServices().getTaxType(pidm, tranNumber));
		getInvoiceStatusDesc(this.getRowAdapter(), invoiceStatusInd);
		if(typeInd.contains("P"))setDetailCodeTypeInd(typeInd,  this.getRowAdapter());
		
		this.getFormModel().getTziarciCtrl().setAccountBalance(balances.get("ACCOUNT_BALANCE"));
		this.getFormModel().getTziarciCtrl().setAmountDue(balances.get("AMOUNT_DUE"));
		this.getFormModel().getTziarciCtrl().setMemoBalance(balances.get("MEMO_BALANCE"));
		this.getFormModel().getTziarciCtrl().setNsfCount(balances.get("NSF_COUNT"));
		this.getFormModel().getTziarciCtrl().setAuthAidBalance(balances.get("AUTH_AID_BALANCE"));
		this.getFormModel().getTziarciCtrl().setReceipt(NString.toStr("N"));
		
	}
	
	public void getInvoiceStatusDesc(TbraccdTzrarciAdapter tbraccdTzrarciElement, NString invoiceStatusInd) {
		if(invoiceStatusInd.contains("C")) {
			tbraccdTzrarciElement.setInvoiceStatusInd(NString.toStr("FACTURADO"));
		}
		if(invoiceStatusInd.contains("X")){
			tbraccdTzrarciElement.setInvoiceStatusInd(NString.toStr("CANCELADO"));
		}
		if(invoiceStatusInd.isNull()){
			tbraccdTzrarciElement.setInvoiceStatusInd(NString.toStr("DISPONIBLE PARA FACTURAR"));
		}
	}
	
	public void setDetailCodeTypeInd(NString typeInd, TbraccdTzrarciAdapter tbraccdTzrarciElement) {
		tbraccdTzrarciElement.setPaymentAmount(tbraccdTzrarciElement.getTbraccdAmount());
		tbraccdTzrarciElement.setChargeAmount(NNumber.getNull());	
	}
	
}