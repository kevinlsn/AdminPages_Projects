package net.hedtech.banner.arsys.Tziarci.model;

import morphis.foundations.core.appsupportlib.model.SimpleBusinessObject;
import morphis.foundations.core.appsupportlib.model.configuration.SimpleBusinessObjectConfiguration;
import morphis.foundations.core.types.*;
import static morphis.foundations.core.types.Types.*;

public class TziarciCtrl extends morphis.foundations.flavors.forms.appsupportlib.model.SimpleBusinessObject {

	public TziarciCtrl() {
		super();
	}

	public TziarciCtrl(SimpleBusinessObjectConfiguration configuration, String name) {
		super(configuration, name);
	}
	
	public NNumber getAccountBalance() {
		return toNumber(super.getValue("ACCOUNT_BALANCE"));
	}
	
	public void setAccountBalance(NNumber value) {
		super.setValue("ACCOUNT_BALANCE", value);
	}

	public NNumber getQueryBalance() {
		return toNumber(super.getValue("QUERY_BALANCE"));
	}
	
	public void setQueryBalance(NNumber value) {
		super.setValue("QUERY_BALANCE", value);
	}

	public NNumber getAmountDue() {
		return toNumber(super.getValue("AMOUNT_DUE"));
	}
	
	public void setAmountDue(NNumber value) {
		super.setValue("AMOUNT_DUE", value);
	}

	public NNumber getTaxQueryBalance() {
		return toNumber(super.getValue("TAX_QUERY_BALANCE"));
	}
	
	public void setTaxQueryBalance(NNumber value) {
		super.setValue("TAX_QUERY_BALANCE", value);
	}

	public NNumber getTaxAccountBalance() {
		return toNumber(super.getValue("TAX_ACCOUNT_BALANCE"));
	}
	
	public void setTaxAccountBalance(NNumber value) {
		super.setValue("TAX_ACCOUNT_BALANCE", value);
	}

	public NNumber getTaxAmountDue() {
		return toNumber(super.getValue("TAX_AMOUNT_DUE"));
	}
	
	public void setTaxAmountDue(NNumber value) {
		super.setValue("TAX_AMOUNT_DUE", value);
	}

	public NNumber getNetQueryBalance() {
		return toNumber(super.getValue("NET_QUERY_BALANCE"));
	}
	
	public void setNetQueryBalance(NNumber value) {
		super.setValue("NET_QUERY_BALANCE", value);
	}

	public NNumber getNetAccountBalance() {
		return toNumber(super.getValue("NET_ACCOUNT_BALANCE"));
	}
	
	public void setNetAccountBalance(NNumber value) {
		super.setValue("NET_ACCOUNT_BALANCE", value);
	}

	public NNumber getNetAmountDue() {
		return toNumber(super.getValue("NET_AMOUNT_DUE"));
	}
	
	public void setNetAmountDue(NNumber value) {
		super.setValue("NET_AMOUNT_DUE", value);
	}

	public NNumber getMemoBalance() {
		return toNumber(super.getValue("MEMO_BALANCE"));
	}
	
	public void setMemoBalance(NNumber value) {
		super.setValue("MEMO_BALANCE", value);
	}

	public NNumber getNsfCount() {
		return toNumber(super.getValue("NSF_COUNT"));
	}
	
	public void setNsfCount(NNumber value) {
		super.setValue("NSF_COUNT", value);
	}

	public NNumber getAuthAidBalance() {
		return toNumber(super.getValue("AUTH_AID_BALANCE"));
	}
	
	public void setAuthAidBalance(NNumber value) {
		super.setValue("AUTH_AID_BALANCE", value);
	}

	public NString getReceipt() {
		return toStr(super.getValue("RECEIPT"));
	}
	
	public void setReceipt(NString value) {
		super.setValue("RECEIPT", value);
	}
}