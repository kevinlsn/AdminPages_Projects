package net.hedtech.banner.arsys.Tziarci;

import java.util.Hashtable;
import net.hedtech.general.common.forms.BaseTask;

public class TziarciTask extends BaseTask {
	public TziarciTask(String taskName) {
		super(taskName);
	}
	
	public TziarciTask(String taskName, Hashtable sharedLibraries, Hashtable parameters) {
		super(taskName, sharedLibraries, parameters);
	}
	
	@Override
	public net.hedtech.banner.arsys.Tziarci.model.TziarciModel getModel() {
		return (net.hedtech.banner.arsys.Tziarci.model.TziarciModel)super.getModel();
	}
	
	public net.hedtech.banner.arsys.Tziarci.services.TziarciServices getServices() {
		return (net.hedtech.banner.arsys.Tziarci.services.TziarciServices)getSupportCodeManager().getServices();
	}
	
	// Attached Libraries
	
	public net.hedtech.general.common.libraries.Goqrpls.GoqrplsServices getGoqrpls() {
		return (net.hedtech.general.common.libraries.Goqrpls.GoqrplsServices)getSupportCodeManager().getLibrary("GOQRPLS");
	}
}
