package net.hedtech.banner.arsys.Tziarci.model;

import morphis.foundations.core.appsupportlib.model.SimpleBusinessObject;
import morphis.foundations.core.appsupportlib.model.configuration.SimpleBusinessObjectConfiguration;
import morphis.foundations.core.types.*;
import static morphis.foundations.core.types.Types.*;

public class KeyBlock extends morphis.foundations.flavors.forms.appsupportlib.model.SimpleBusinessObject {

	public KeyBlock() {
		super();
	}

	public KeyBlock(SimpleBusinessObjectConfiguration configuration, String name) {
		super(configuration, name);
	}
	
	public NString getId() {
		return toStr(super.getValue("ID"));
	}
	
	public void setId(NString value) {
		super.setValue("ID", value);
	}

	public NString getCurrency() {
		return toStr(super.getValue("CURRENCY"));
	}
	
	public void setCurrency(NString value) {
		super.setValue("CURRENCY", value);
	}

	public NString getUser() {
		return toStr(super.getValue("USER"));
	}
	
	public void setUser(NString value) {
		super.setValue("USER", value);
	}

	public NString getUserName() {
		return toStr(super.getValue("USER_NAME"));
	}

	public void setUserName(NString value) {
		super.setValue("USER_NAME", value);
	}

	public NString getIdLbt() {
		return toStr(super.getValue("ID_LBT"));
	}

	public void setIdLbt(NString value) {
		super.setValue("ID_LBT", value);
	}
}