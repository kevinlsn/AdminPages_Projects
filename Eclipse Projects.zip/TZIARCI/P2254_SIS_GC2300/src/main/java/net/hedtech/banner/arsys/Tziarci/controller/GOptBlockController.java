package net.hedtech.banner.arsys.Tziarci.controller;

import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import net.hedtech.banner.arsys.Tziarci.TziarciTask;
import net.hedtech.banner.arsys.Tziarci.model.TziarciModel;
import net.hedtech.general.common.forms.controller.DefaultBlockController;
		
public class GOptBlockController extends DefaultBlockController {


	private net.hedtech.general.common.libraries.Goqolib.controller.GOptBlockController getGoqolibGOptBlockController() {
		return (net.hedtech.general.common.libraries.Goqolib.controller.GOptBlockController) this.getTask().getTaskPart("GOQOLIB").getSupportCodeManager().getPackage("G$_OPT_BLOCK");
	}
	
	public GOptBlockController(IFormController parentController, String name) 
	{
		super(parentController, name);
	}
		
	@Override
	public TziarciTask getTask() {
		return (TziarciTask) super.getTask();
	}

	public TziarciModel getFormModel() {
		return getTask().getModel();
	}
		
			
	//action methods generated from triggers
	
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * G$_OPT_BLOCK.WHEN-NEW-BLOCK-INSTANCE
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-NEW-BLOCK-INSTANCE", function=KeyFunction.BLOCK_CHANGE)
		public void gOptBlock_blockChange()
		{
			
			getGoqolibGOptBlockController().gOptBlock_blockChange();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * G$_OPT_BLOCK.KEY-PRVREC
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="KEY-PRVREC", function=KeyFunction.PREVIOUS_RECORD)
		public void gOptBlock_PreviousRecord()
		{
			
			getGoqolibGOptBlockController().gOptBlock_PreviousRecord();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * G$_OPT_BLOCK.KEY-NXTREC
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="KEY-NXTREC", function=KeyFunction.NEXT_RECORD)
		public void gOptBlock_NextRecord()
		{
			
			getGoqolibGOptBlockController().gOptBlock_NextRecord();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * G$_OPT_BLOCK.POST-TEXT-ITEM
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="POST-TEXT-ITEM", function=KeyFunction.ITEM_OUT)
		public void gOptBlock_itemOut()
		{
			
			getGoqolibGOptBlockController().gOptBlock_itemOut();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * G$_OPT_BLOCK.PRE-BLOCK
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="PRE-BLOCK", function=KeyFunction.BLOCK_IN)
		public void gOptBlock_blockIn()
		{
			
			getGoqolibGOptBlockController().gOptBlock_blockIn();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * G$_OPT_BLOCK.POST-BLOCK
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="POST-BLOCK", function=KeyFunction.BLOCK_OUT)
		public void gOptBlock_blockOut()
		{
			
			getGoqolibGOptBlockController().gOptBlock_blockOut();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * G$_OPT_BLOCK.KEY-DOWN
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="KEY-DOWN", function=KeyFunction.DOWN)
		public void gOptBlock_MoveDown()
		{
			
			getGoqolibGOptBlockController().gOptBlock_MoveDown();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * G$_OPT_BLOCK.KEY-UP
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="KEY-UP", function=KeyFunction.UP)
		public void gOptBlock_MoveUp()
		{
			
			getGoqolibGOptBlockController().gOptBlock_MoveUp();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * G$_OPT_BLOCK.KEY-NXTBLK
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="KEY-NXTBLK", function=KeyFunction.NEXT_BLOCK)
		public void gOptBlock_NextBlock()
		{
			
			getGoqolibGOptBlockController().gOptBlock_NextBlock();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * G$_OPT_BLOCK.KEY-PRVBLK
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="KEY-PRVBLK", function=KeyFunction.PREVIOUS_BLOCK)
		public void gOptBlock_PreviousBlock()
		{
			
			getGoqolibGOptBlockController().gOptBlock_PreviousBlock();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * SELECT_A_DESC.WHEN-MOUSE-CLICK
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-MOUSE-CLICK", item="SELECT_A_DESC")
		public void selectADesc_click()
		{
			
			getGoqolibGOptBlockController().selectADesc_click();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * SELECT_A_DESC.WHEN-BUTTON-PRESSED
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-BUTTON-PRESSED", item="SELECT_A_DESC")
		public void selectADesc_buttonClick()
		{
			
			getGoqolibGOptBlockController().selectADesc_buttonClick();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * SELECT_A_DESC.WHEN-NEW-ITEM-INSTANCE
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-NEW-ITEM-INSTANCE", item="SELECT_A_DESC", function=KeyFunction.ITEM_CHANGE)
		public void selectADesc_itemChange()
		{
			
			getGoqolibGOptBlockController().selectADesc_itemChange();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * SELECT_B_DESC.WHEN-MOUSE-CLICK
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-MOUSE-CLICK", item="SELECT_B_DESC")
		public void selectBDesc_click()
		{
			
			getGoqolibGOptBlockController().selectBDesc_click();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * SELECT_B_DESC.WHEN-BUTTON-PRESSED
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-BUTTON-PRESSED", item="SELECT_B_DESC")
		public void selectBDesc_buttonClick()
		{
			
			getGoqolibGOptBlockController().selectBDesc_buttonClick();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * SELECT_B_DESC.WHEN-NEW-ITEM-INSTANCE
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-NEW-ITEM-INSTANCE", item="SELECT_B_DESC", function=KeyFunction.ITEM_CHANGE)
		public void selectBDesc_itemChange()
		{
			
			getGoqolibGOptBlockController().selectBDesc_itemChange();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * SELECT_C_DESC.WHEN-MOUSE-CLICK
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-MOUSE-CLICK", item="SELECT_C_DESC")
		public void selectCDesc_click()
		{
			
			getGoqolibGOptBlockController().selectCDesc_click();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * SELECT_C_DESC.WHEN-BUTTON-PRESSED
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-BUTTON-PRESSED", item="SELECT_C_DESC")
		public void selectCDesc_buttonClick()
		{
			
			getGoqolibGOptBlockController().selectCDesc_buttonClick();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * SELECT_C_DESC.WHEN-NEW-ITEM-INSTANCE
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-NEW-ITEM-INSTANCE", item="SELECT_C_DESC", function=KeyFunction.ITEM_CHANGE)
		public void selectCDesc_itemChange()
		{
			
			getGoqolibGOptBlockController().selectCDesc_itemChange();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * SELECT_D_DESC.WHEN-MOUSE-CLICK
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-MOUSE-CLICK", item="SELECT_D_DESC")
		public void selectDDesc_click()
		{
			
			getGoqolibGOptBlockController().selectDDesc_click();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * SELECT_D_DESC.WHEN-BUTTON-PRESSED
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-BUTTON-PRESSED", item="SELECT_D_DESC")
		public void selectDDesc_buttonClick()
		{
			
			getGoqolibGOptBlockController().selectDDesc_buttonClick();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * SELECT_D_DESC.WHEN-NEW-ITEM-INSTANCE
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-NEW-ITEM-INSTANCE", item="SELECT_D_DESC", function=KeyFunction.ITEM_CHANGE)
		public void selectDDesc_itemChange()
		{
			
			getGoqolibGOptBlockController().selectDDesc_itemChange();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * SELECT_E_DESC.WHEN-MOUSE-CLICK
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-MOUSE-CLICK", item="SELECT_E_DESC")
		public void selectEDesc_click()
		{
			
			getGoqolibGOptBlockController().selectEDesc_click();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * SELECT_E_DESC.WHEN-BUTTON-PRESSED
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-BUTTON-PRESSED", item="SELECT_E_DESC")
		public void selectEDesc_buttonClick()
		{
			
			getGoqolibGOptBlockController().selectEDesc_buttonClick();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * SELECT_E_DESC.WHEN-NEW-ITEM-INSTANCE
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-NEW-ITEM-INSTANCE", item="SELECT_E_DESC", function=KeyFunction.ITEM_CHANGE)
		public void selectEDesc_itemChange()
		{
			
			getGoqolibGOptBlockController().selectEDesc_itemChange();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * SELECT_F_DESC.WHEN-MOUSE-CLICK
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-MOUSE-CLICK", item="SELECT_F_DESC")
		public void selectFDesc_click()
		{
			
			getGoqolibGOptBlockController().selectFDesc_click();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * SELECT_F_DESC.WHEN-BUTTON-PRESSED
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-BUTTON-PRESSED", item="SELECT_F_DESC")
		public void selectFDesc_buttonClick()
		{
			
			getGoqolibGOptBlockController().selectFDesc_buttonClick();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * SELECT_F_DESC.WHEN-NEW-ITEM-INSTANCE
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-NEW-ITEM-INSTANCE", item="SELECT_F_DESC", function=KeyFunction.ITEM_CHANGE)
		public void selectFDesc_itemChange()
		{
			
			getGoqolibGOptBlockController().selectFDesc_itemChange();
		}

		
		/*
		 *<p>
		 *<b>Migration Comments</b>
		 * Generated from trigger:
		 * OPT_CANCEL_BTN.WHEN-BUTTON-PRESSED
		 *
		 *
		 *</p>
		*/

		@ActionTrigger(action="WHEN-BUTTON-PRESSED", item="OPT_CANCEL_BTN")
		public void optCancelBtn_buttonClick()
		{
			
			getGoqolibGOptBlockController().optCancelBtn_buttonClick();
		}

}
