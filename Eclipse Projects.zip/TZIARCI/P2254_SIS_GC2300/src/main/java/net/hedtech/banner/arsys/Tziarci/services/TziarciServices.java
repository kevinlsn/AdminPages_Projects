package net.hedtech.banner.arsys.Tziarci.services;

import morphis.foundations.core.appdatalayer.data.CommandType;
import morphis.foundations.core.appdatalayer.data.DataCursor;
import morphis.foundations.core.appdatalayer.data.DbManager;
import morphis.foundations.core.appdatalayer.data.IDataCommand;
import morphis.foundations.core.appdatalayer.data.ResultSet;
import morphis.foundations.core.appsupportlib.runtime.ISupportCodeContainer;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;

import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.util.globals.Globals.setGlobal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import morphis.common.forms.baseForm.services.DefaultSupportCodeObject;
import net.hedtech.banner.arsys.Tziarci.TziarciTask;
import net.hedtech.banner.arsys.Tziarci.model.TziarciModel;
import net.hedtech.banner.arsys.Tziarci.parts.goqolib.model.DataConstant;

public class TziarciServices extends DefaultSupportCodeObject {

	public TziarciServices(ISupportCodeContainer container) {
		super(container);
	}

	public TziarciTask getTask() {
		return (TziarciTask) super.getContainer();
	}

	public TziarciModel getFormModel() {
		return getTask().getModel();
	}
	
	public NNumber getCurrencyCode(NString currencyCode) {
		
		NNumber currency = NNumber.getNull();
		DataCursor cursor = new DataCursor(DataConstant.VALIDATE_CURRENCY);
		
		try {
			cursor.addParameter(DataConstant.CURRENCY, currencyCode);
			cursor.open();
			ResultSet spridenCResults = cursor.fetchInto();
			
			if (spridenCResults != null) 
				currency = spridenCResults.getNumber(0);
		
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (cursor.isOpen()) {
				cursor.close();
				cursor.dispose();
			}
		}	
		
		return currency;
	}
	
	public NNumber existsIdOnSpriden (NString id) {
		NNumber counter = NNumber.getNull();
		if(id.isNotNull()) {
			DataCursor cursor = new DataCursor(DataConstant.VALIDATE_SPRIDEN_ID);
			try {
				cursor.addParameter(DataConstant.SPRINDEN_ID, id);
				cursor.open();
				ResultSet result = cursor.fetchInto();
				if (result != null) {
					counter = result.getNumber(0);
				}
			} catch (Exception e) {
				if(e != null) {
					System.out.println(e.getLocalizedMessage());
				}	
			} finally {
				if (cursor.isOpen()) {
					cursor.close();
					cursor.dispose();
				}
			}
			
		}
		
		return counter;
	}
	
	public NString getIDDescription(NString id) {
		NString desc = NString.getNull();
		DataCursor cursor = new DataCursor(DataConstant.GET_NAME_BY_ID);
		try {
			cursor.addParameter(DataConstant.SPRINDEN_ID, id);
			cursor.open();
			ResultSet result = cursor.fetchInto();
			
			if (result != null) 				
				desc = result.getStr(0);
		
		} catch (Exception e) {
			if(e != null)
			System.out.println(e.getMessage());
		} finally {
			if (cursor.isOpen()) {
				cursor.close();
				cursor.dispose();
			}
		}
		return desc;	
	}
	
	public NNumber IDToPidm (NString id) {
		NNumber pidm = NNumber.getNull();
		DataCursor cursor = new DataCursor(DataConstant.GET_PIDM);
			
		try {
			cursor.addParameter(DataConstant.ID, id);
			cursor.open();
			ResultSet result = cursor.fetchInto();
				
			if (result != null) {
				pidm = result.getNumber(0);
			}
		} catch (Exception e) {
			if(e != null) {
				System.out.println(e.getLocalizedMessage());
			}	
		} finally {
			if (cursor.isOpen()) {
				cursor.close();
				cursor.dispose();
			}
		}
		
		return pidm;
	}
	
	public Map<String, NNumber> P_TZRARCI_CALC (NNumber pidm, NString currency) {
		Map<String, NNumber> balance = new HashMap<>();
		try {
			IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand(DataConstant.SP_CALCULO_BALANCES,
			DbManager.getDataBaseFactory());
			cmd.getCommand().setCommandType(CommandType.StoredProcedure); 
			cmd.addParameter("p_pidm", pidm);
			cmd.addParameter("p_currency", currency);
			cmd.addParameter("ACCOUNT_BALANCE", NNumber.class);
			cmd.addParameter("QUERY_BALANCE", NNumber.class);
			cmd.addParameter("AMOUNT_DUE",  NNumber.class);
			cmd.addParameter("MEMO_BALANCE", NNumber.class);
			cmd.addParameter("NSF_COUNT", NNumber.class);
			cmd.addParameter("AUTH_AID_BALANCE",  NNumber.class);
			cmd.execute();
			
			NNumber ACCOUNT_BALANCE = cmd.getParameterValue("ACCOUNT_BALANCE", NNumber.class);
			NNumber QUERY_BALANCE = cmd.getParameterValue("QUERY_BALANCE",  NNumber.class);
			NNumber AMOUNT_DUE = cmd.getParameterValue("AMOUNT_DUE",  NNumber.class);
			NNumber MEMO_BALANCE = cmd.getParameterValue("MEMO_BALANCE",  NNumber.class);
			NNumber NSF_COUNT = cmd.getParameterValue("NSF_COUNT",  NNumber.class);
			NNumber AUTH_AID_BALANCE = cmd.getParameterValue("AUTH_AID_BALANCE",  NNumber.class);
			
			balance.put("ACCOUNT_BALANCE", ACCOUNT_BALANCE);
			balance.put("QUERY_BALANCE", QUERY_BALANCE);
			balance.put("AMOUNT_DUE", AMOUNT_DUE);
			balance.put("MEMO_BALANCE", MEMO_BALANCE);
			balance.put("NSF_COUNT", NSF_COUNT);
			balance.put("AUTH_AID_BALANCE", AUTH_AID_BALANCE);
			  
			} catch (Exception e) {
			     System.out.println("TziarciServices.calcBalances: " + e.getLocalizedMessage());
			}

		return balance;
	}
	
	public NString levelDescription(NString levelCode) {
		NString desc = NString.getNull();
		DataCursor cursor = new DataCursor(DataConstant.LEVEL_DESCRIPTION);
		try {
			cursor.addParameter(DataConstant.LEVEL_CODE, levelCode);
			cursor.open();
			ResultSet result = cursor.fetchInto();
			
			if (result != null) 				
				desc = result.getStr(0);
		
		} catch (Exception e) {
			if(e != null)
			System.out.println(e.getMessage());
		} finally {
			if (cursor.isOpen()) {
				cursor.close();
				cursor.dispose();
			}
		}
		return desc;	
	}
	
	public NString getTaxType(NNumber pidm, NNumber transactionNumber) {
		NString taxType = NString.getNull();
		DataCursor cursor = new DataCursor(DataConstant.GET_TAX_TYPE);
		try {
			cursor.addParameter(DataConstant.PIDM, pidm);
			cursor.addParameter(DataConstant.TRAN_NUMBER, transactionNumber);
			cursor.open();
			ResultSet result = cursor.fetchInto();
			
			if (result != null) 				
				taxType = result.getStr(0);
		
		} catch (Exception e) {
			if(e != null)
			System.out.println(e.getMessage());
		} finally {
			if (cursor.isOpen()) {
				cursor.close();
				cursor.dispose();
			}
		}
		return taxType;	
	}
	
	
	public NString getDetailCodeTypeInd(NString detailCode) {
		NString typeInd = NString.getNull();
		DataCursor cursor = new DataCursor(DataConstant.GET_TYPE_IND);
		try {
			cursor.addParameter(DataConstant.DETAIL_CODE, detailCode);

			cursor.open();
			ResultSet result = cursor.fetchInto();
			
			if (result != null) 				
				typeInd = result.getStr(0);
		
		} catch (Exception e) {
			if(e != null)
			System.out.println(e.getMessage());
		} finally {
			if (cursor.isOpen()) {
				cursor.close();
				cursor.dispose();
			}
		}
		return typeInd;	
	}
	

}