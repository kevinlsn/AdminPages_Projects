package net.hedtech.banner.arsys.Tziarci.model;

import java.util.Date;
import java.math.BigDecimal;
import org.jdesktop.databuffer.DataRow;
//import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.types.*;
import morphis.foundations.core.appsupportlib.model.*;
import morphis.foundations.flavors.forms.appdatalayer.data.BaseRowAdapter;

public class TbraccdTzrarciAdapter extends BaseRowAdapter {

	public TbraccdTzrarciAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NString getTbraccdDetailCode() {
		NString v = new NString((String)this.getValue("TBRACCD_DETAIL_CODE"));
		return v;
	}
	
	public void setTbraccdDetailCode(NString value) {
		this.setValue("TBRACCD_DETAIL_CODE", value.getValue());
	}

	public NString getTbraccdDesc() {
		NString v = new NString((String)this.getValue("TBRACCD_DESC"));
		return v;
	}
	
	public void setTbraccdDesc(NString value) {
		this.setValue("TBRACCD_DESC", value.getValue());
	}

	public NString getTbraccdTermCode() {
		NString v = new NString((String)this.getValue("TBRACCD_TERM_CODE"));
		return v;
	}
	
	public void setTbraccdTermCode(NString value) {
		this.setValue("TBRACCD_TERM_CODE", value.getValue());
	}

	public NNumber getTbraccdAmount() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TBRACCD_AMOUNT"));
		return v;
	}
	
	public void setTbraccdAmount(NNumber value) {
		this.setValue("TBRACCD_AMOUNT", value.getValue());
	}

	public NString getTbraccdPaymentId() {
		NString v = new NString((String)this.getValue("TBRACCD_PAYMENT_ID"));
		return v;
	}
	
	public void setTbraccdPaymentId(NString value) {
		this.setValue("TBRACCD_PAYMENT_ID", value.getValue());
	}

	public NNumber getTbraccdBalance() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TBRACCD_BALANCE"));
		return v;
	}
	
	public void setTbraccdBalance(NNumber value) {
		this.setValue("TBRACCD_BALANCE", value.getValue());
	}

	public NNumber getTbraccdTaxAmount() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TBRACCD_TAX_AMOUNT"));
		return v;
	}
	
	public void setTbraccdTaxAmount(NNumber value) {
		this.setValue("TBRACCD_TAX_AMOUNT", value.getValue());
	}

	public NString getTbraccdCcrdCode() {
		NString v = new NString((String)this.getValue("TBRACCD_CCRD_CODE"));
		return v;
	}
	
	public void setTbraccdCcrdCode(NString value) {
		this.setValue("TBRACCD_CCRD_CODE", value.getValue());
	}

	public NString getTbraccdSrceCode() {
		NString v = new NString((String)this.getValue("TBRACCD_SRCE_CODE"));
		return v;
	}
	
	public void setTbraccdSrceCode(NString value) {
		this.setValue("TBRACCD_SRCE_CODE", value.getValue());
	}

	public NDate getTbraccdEffectiveDate() {
		NDate v = new NDate((java.util.Date)this.getValue("TBRACCD_EFFECTIVE_DATE"));
		return v;
	}
	
	public void setTbraccdEffectiveDate(NDate value) {
		this.setValue("TBRACCD_EFFECTIVE_DATE", value.getValue());
	}

	public NDate getTbraccdTransDate() {
		NDate v = new NDate((java.util.Date)this.getValue("TBRACCD_TRANS_DATE"));
		return v;
	}
	
	public void setTbraccdTransDate(NDate value) {
		this.setValue("TBRACCD_TRANS_DATE", value.getValue());
	}

	public NString getTbraccdAidyCode() {
		NString v = new NString((String)this.getValue("TBRACCD_AIDY_CODE"));
		return v;
	}
	
	public void setTbraccdAidyCode(NString value) {
		this.setValue("TBRACCD_AIDY_CODE", value.getValue());
	}

	public NString getTbraccdPeriod() {
		NString v = new NString((String)this.getValue("TBRACCD_PERIOD"));
		return v;
	}
	
	public void setTbraccdPeriod(NString value) {
		this.setValue("TBRACCD_PERIOD", value.getValue());
	}

	public NString getTzrarciCampCode() {
		NString v = new NString((String)this.getValue("TZRARCI_CAMP_CODE"));
		return v;
	}
	
	public void setTzrarciCampCode(NString value) {
		this.setValue("TZRARCI_CAMP_CODE", value.getValue());
	}

	public NString getTzrarciSiteCode() {
		NString v = new NString((String)this.getValue("TZRARCI_SITE_CODE"));
		return v;
	}
	
	public void setTzrarciSiteCode(NString value) {
		this.setValue("TZRARCI_SITE_CODE", value.getValue());
	}

	public NString getTzrarciMajrCode() {
		NString v = new NString((String)this.getValue("TZRARCI_MAJR_CODE"));
		return v;
	}
	
	public void setTzrarciMajrCode(NString value) {
		this.setValue("TZRARCI_MAJR_CODE", value.getValue());
	}

	public NString getTzrarciAcctCostCenter() {
		NString v = new NString((String)this.getValue("TZRARCI_ACCT_COST_CENTER"));
		return v;
	}
	
	public void setTzrarciAcctCostCenter(NString value) {
		this.setValue("TZRARCI_ACCT_COST_CENTER", value.getValue());
	}

	public NString getTzrarciCredTranNum() {
		NString v = new NString((String)this.getValue("TZRARCI_CRED_TRAN_NUM"));
		return v;
	}
	
	public void setTzrarciCredTranNum(NString value) {
		this.setValue("TZRARCI_CRED_TRAN_NUM", value.getValue());
	}

	public NNumber getTbraccdReceiptNumber() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TBRACCD_RECEIPT_NUMBER"));
		return v;
	}
	
	public void setTbraccdReceiptNumber(NNumber value) {
		this.setValue("TBRACCD_RECEIPT_NUMBER", value.getValue());
	}

	public NString getTbraccdOrigChgInd() {
		NString v = new NString((String)this.getValue("TBRACCD_ORIG_CHG_IND"));
		return v;
	}
	
	public void setTbraccdOrigChgInd(NString value) {
		this.setValue("TBRACCD_ORIG_CHG_IND", value.getValue());
	}

	public NString getTbraccdCpdtInd() {
		NString v = new NString((String)this.getValue("TBRACCD_CPDT_IND"));
		return v;
	}
	
	public void setTbraccdCpdtInd(NString value) {
		this.setValue("TBRACCD_CPDT_IND", value.getValue());
	}

	public NNumber getTbraccdTranNumber() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TBRACCD_TRAN_NUMBER"));
		return v;
	}
	
	public void setTbraccdTranNumber(NNumber value) {
		this.setValue("TBRACCD_TRAN_NUMBER", value.getValue());
	}

	public NNumber getTbraccdTranNumberPaid() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TBRACCD_TRAN_NUMBER_PAID"));
		return v;
	}
	
	public void setTbraccdTranNumberPaid(NNumber value) {
		this.setValue("TBRACCD_TRAN_NUMBER_PAID", value.getValue());
	}

	public NString getTbraccdDocumentNumber() {
		NString v = new NString((String)this.getValue("TBRACCD_DOCUMENT_NUMBER"));
		return v;
	}
	
	public void setTbraccdDocumentNumber(NString value) {
		this.setValue("TBRACCD_DOCUMENT_NUMBER", value.getValue());
	}

	public NString getTbraccdAcctFeedInd() {
		NString v = new NString((String)this.getValue("TBRACCD_ACCT_FEED_IND"));
		return v;
	}
	
	public void setTbraccdAcctFeedInd(NString value) {
		this.setValue("TBRACCD_ACCT_FEED_IND", value.getValue());
	}

	public NString getTbraccdFeedDocCode() {
		NString v = new NString((String)this.getValue("TBRACCD_FEED_DOC_CODE"));
		return v;
	}
	
	public void setTbraccdFeedDocCode(NString value) {
		this.setValue("TBRACCD_FEED_DOC_CODE", value.getValue());
	}

	public NDate getTbraccdFeedDate() {
		NDate v = new NDate((java.util.Date)this.getValue("TBRACCD_FEED_DATE"));
		return v;
	}
	
	public void setTbraccdFeedDate(NDate value) {
		this.setValue("TBRACCD_FEED_DATE", value.getValue());
	}

	public NString getTbraccdUser() {
		NString v = new NString((String)this.getValue("TBRACCD_USER"));
		return v;
	}
	
	public void setTbraccdUser(NString value) {
		this.setValue("TBRACCD_USER", value.getValue());
	}

	public NNumber getTbraccdSessionNumber() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TBRACCD_SESSION_NUMBER"));
		return v;
	}
	
	public void setTbraccdSessionNumber(NNumber value) {
		this.setValue("TBRACCD_SESSION_NUMBER", value.getValue());
	}

	public NDate getTbraccdCshrEndDate() {
		NDate v = new NDate((java.util.Date)this.getValue("TBRACCD_CSHR_END_DATE"));
		return v;
	}
	
	public void setTbraccdCshrEndDate(NDate value) {
		this.setValue("TBRACCD_CSHR_END_DATE", value.getValue());
	}

	public NDate getTbraccdEntryDate() {
		NDate v = new NDate((java.util.Date)this.getValue("TBRACCD_ENTRY_DATE"));
		return v;
	}
	
	public void setTbraccdEntryDate(NDate value) {
		this.setValue("TBRACCD_ENTRY_DATE", value.getValue());
	}

	public NString getTzrarciInvoiceStatusInd() {
		NString v = new NString((String)this.getValue("TZRARCI_INVOICE_STATUS_IND"));
		return v;
	}
	
	public void setTzrarciInvoiceStatusInd(NString value) {
		this.setValue("TZRARCI_INVOICE_STATUS_IND", value.getValue());
	}

	public NString getTzrarciNfacStatus() {
		NString v = new NString((String)this.getValue("TZRARCI_NFAC_STATUS"));
		return v;
	}
	
	public void setTzrarciNfacStatus(NString value) {
		this.setValue("TZRARCI_NFAC_STATUS", value.getValue());
	}

	public NNumber getTzrarciRate() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TZRARCI_RATE"));
		return v;
	}
	
	public void setTzrarciRate(NNumber value) {
		this.setValue("TZRARCI_RATE", value.getValue());
	}

	public NString getTzrarciLevlCode() {
		NString v = new NString((String)this.getValue("TZRARCI_LEVL_CODE"));
		return v;
	}
	
	public void setTzrarciLevlCode(NString value) {
		this.setValue("TZRARCI_LEVL_CODE", value.getValue());
	}

	public NNumber getTbraccdPidm() {
		NNumber v = new NNumber((BigDecimal) this.getValue("TBRACCD_PIDM"));
		return v;
	}

	public void setTbraccdPidm(NNumber value) {
		this.setValue("TBRACCD_PIDM", value.getValue());
	}

	public NString getTaxType() {
		NString v = new NString((String) this.getValue("TAX_TYPE"));
		return v;
	}

	public void setTaxType(NString value) {
		this.setValue("TAX_TYPE", value.getValue());
	}

	public NString getDescLevel() {
		NString v = new NString((String) this.getValue("DESC_LEVEL"));
		return v;
	}

	public void setDescLevel(NString value) {
		this.setValue("DESC_LEVEL", value.getValue());
	}

	public NString getInvoiceStatusInd() {
		NString v = new NString((String) this.getValue("INVOICE_STATUS_IND"));
		return v;
	}

	public void setInvoiceStatusInd(NString value) {
		this.setValue("INVOICE_STATUS_IND", value.getValue());
	}

	public NNumber getPaymentAmount() {
		NNumber v = new NNumber((BigDecimal) this.getValue("PAYMENT_AMOUNT"));
		return v;
	}

	public void setPaymentAmount(NNumber value) {
		this.setValue("PAYMENT_AMOUNT", value.getValue());
	}

	public NNumber getChargeAmount() {
		NNumber v = new NNumber((BigDecimal) this.getValue("CHARGE_AMOUNT"));
		return v;
	}

	public void setChargeAmount(NNumber value) {
		this.setValue("CHARGE_AMOUNT", value.getValue());
	}

}