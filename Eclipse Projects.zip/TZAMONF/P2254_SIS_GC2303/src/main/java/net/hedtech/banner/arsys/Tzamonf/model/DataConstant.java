package net.hedtech.banner.arsys.Tzamonf.model;

public final class DataConstant {
	public static final String POINT_LABEL = ".";
	public static final String HIGH_DASH_LABEL = "-";
	public static final String UNDERSCORE_LABEL = "_";
	public static final String FORM_TITLE = "TZAMONF";
	public static final String MAIN_TABLE = "TZRHSTB";
	public static final String LOG_FORM_TITLE = "TZRRLOG";
	public static final String CURRENT_USER_LABEL = "CURRENT_USER";
	public static final String SPRIDEN_ID_LABEL = "SPRIDEN_ID";
	public static final String FORM_LABEL = "FORM";
	public static final String EVENT_LIST_VALUES = "LIST_VALUES";
	public static final String EVENT_COUNT_QUERY = "COUNT_QUERY";
	public static final String EVENT_DUPLICATED_ITEM = "DUPLICATE_ITEM";
	public static final String EVENT_LIST_VALUES_COPY = EVENT_LIST_VALUES + "_COPY";
	public static final String MENU_OPTION_SOAIDEN = "Person search (SOAIDEN)";
	public static final String MENU_OPTION_SOACOMP = "Non-Person search (SOACOMP)";
	public static final String MENU_OPTION_GUIALTI = "Alternate ID search (GUIALTI)";
	public static final String VALUE_LABEL = "VALUE";
	public static final String GUIALTI_LABEL = "GUIALTI";
	public static final String SOACOMP_LABEL = "SOACOMP";
	public static final String SOAIDEN_LABEL = "SOAIDEN";
	public static final String QUERY_LABEL = "QUERY";
	public static final String ACTION_REVOKE_ACCESS = "G$_REVOKE_ACCESS";
	public static final String FIRST_MESSAGE_LABEL = FORM_TITLE + HIGH_DASH_LABEL + "0001";
	public static final String SECOND_MESSAGE_LABEL = FORM_TITLE + HIGH_DASH_LABEL + "0002";
	public static final String THIRD_MESSAGE_LABEL = FORM_TITLE + HIGH_DASH_LABEL + "0003";
	public static final String FOURTH_MESSAGE_LABEL = FORM_TITLE + HIGH_DASH_LABEL + "0004";
	public static final String FIFTH_MESSAGE_LABEL = FORM_TITLE + HIGH_DASH_LABEL + "0005";
	public static final String SIXTH_MESSAGE_LABEL = FORM_TITLE + HIGH_DASH_LABEL + "0006";
	public static final String SOAIDEN_OPTION_LABEL = FORM_TITLE + HIGH_DASH_LABEL + "0050";
	public static final String SOACOMP_OPTION_LABEL = FORM_TITLE + HIGH_DASH_LABEL + "0051";
	public static final String GUIALTI_OPTION_LABEL = FORM_TITLE + HIGH_DASH_LABEL + "0052";
	public static final String ID_LABEL = "ID";
	public static final String ID_DESCRIPTION_LABEL = "ID_DESCRIPTION";
	public static final String ID_PROCESS_LABEL = "ID_PROCESS";
	public static final String PROCESS_LABEL = "PROCESS";
	public static final String PROCESS_CODE_LABEL = "PROCESS_CODE";
	public static final String DATE_FROM_LABEL = "DATE_FROM";
	public static final String DATE_TO_LABEL = "DATE_TO";
	public static final String SHIPPING_STATUS_LABEL = "SHIPPING_STATUS";
	public static final String SHIPPING_STATUS_DESCRIPTION_LABEL = "SHIPPING_STATUS_DESCRIPTION";
	public static final String KEYBLOCK_LABEL = "KEY_BLOCK";
	public static final String PIDM_LABEL = "PIDM";
	public static final String PARAM_PIDM_LABEL = "P_TZRARCI_PIDM";
	public static final String PARAM_NUMBER_TRANSACTION_LABEL = "P_TZRARCI_TRAN_NUMBER";
	public static final String PROCESS_IND_LABEL = "TZRHSTB_PROCESS_IND";
	public static final String ITEM_ID_LABEL = KEYBLOCK_LABEL + POINT_LABEL + ID_LABEL;
	public static final String ITEM_DATE_FROM_LABEL = KEYBLOCK_LABEL + POINT_LABEL + DATE_FROM_LABEL;
	public static final String ITEM_DATE_TO_LABEL = KEYBLOCK_LABEL + POINT_LABEL + DATE_TO_LABEL;
	public static final String ITEM_SHIPPING_STATUS = KEYBLOCK_LABEL + POINT_LABEL + SHIPPING_STATUS_LABEL;
	public static final String ITEM_PROCESS_CODE = KEYBLOCK_LABEL + POINT_LABEL + PROCESS_CODE_LABEL;
	public static final String ITEM_PROCESS_ID = KEYBLOCK_LABEL + POINT_LABEL + ID_PROCESS_LABEL;
	public static final String ITEM_PROCESS_IND = MAIN_TABLE + POINT_LABEL + PROCESS_IND_LABEL;
	public static final String MESSAGE_SHIPPING_STATUS_INVALID = "Invalid Shipping Status, please verify and try again.";
	public static final String MESSAGE_INVALID_DATE = "The Start Process Date must be less than End Process Date.";
	public static final String MESSAGE_ID_INVALID = "Invalid ID, please verify and try again.";
	public static final String MESSAGE_PROCESS_INVALID = "Invalid Process, please verify and try again.";
	public static final String MESSAGE_CAN_NOT_DELETE_RECORD = "This record cannot be deleted.";
	public static final String MESSAGE_PROCESS_ID_INVALID = "Invalid Process Id, please verify and try again.";
	public static final String STATUS_VALID_CFDI = "CFDI Válido";
	public static final String REGEX_NUMERIC = "^[0-9]*$";
	public static final String FORMAT_DATE = "dd/MM/yyyy";
	
	public static final String QUERY_GET_NAME = "SELECT F_FORMAT_NAME (\r\n" +
			"(SELECT SPRIDEN_PIDM FROM SPRIDEN WHERE SPRIDEN_ID = :SPRIDEN_ID\r\n" +
			"AND ROWNUM = 1),'LFM') FROM dual";
	
	public static final String QUERY_GET_PIDM = "SELECT SPRIDEN_PIDM FROM SPRIDEN WHERE SPRIDEN_ID = :SPRIDEN_ID";
	
	public static final String QUERY_ID_EXISTS_SPRIDEN = "SELECT COUNT(SPRIDEN_ID) FROM SPRIDEN\r\n"
			+ "WHERE SPRIDEN_ID = :SPRIDEN_ID";
	
	public static final String QUERY_SHIPPING_STATUS_EXISTS = "SELECT COUNT(GTVSDAX_EXTERNAL_CODE)\r\n" + 
			"FROM GTVSDAX\r\n" + 
			"	WHERE (GTVSDAX_INTERNAL_CODE_GROUP = 'NFA_HSTB'\r\n" + 
			"		AND GTVSDAX_INTERNAL_CODE = 'EST_ENV'\r\n" + 
			"		AND GTVSDAX_EXTERNAL_CODE = :SHIPPING_STATUS)\r\n" + 
			"		OR (:SHIPPING_STATUS = 'E' AND ROWNUM = 1)";
	
	public static final String QUERY_GET_SHIPPING_STATUS_DESC = "SELECT	CASE\r\n" + 
			"			WHEN :SHIPPING_STATUS = 'E' THEN 'Con Error'\r\n" + 
			"			ELSE (SELECT GTVSDAX_DESC\r\n" + 
			"					FROM GTVSDAX  \r\n" + 
			"						WHERE GTVSDAX_INTERNAL_CODE_GROUP = 'NFA_HSTB'\r\n" + 
			"							AND GTVSDAX_INTERNAL_CODE     = 'EST_ENV'\r\n" + 
			"							AND GTVSDAX_EXTERNAL_CODE = :SHIPPING_STATUS\r\n" + 
			"							AND ROWNUM = 1)\r\n" + 
			"		END GTVSDAX_DESC\r\n" + 
			"FROM dual";
	
	public static final String QUERY_PROCESS_EXISTS = "SELECT COUNT(GTVSDAX_EXTERNAL_CODE)\r\n" + 
			"FROM GTVSDAX\r\n" + 
			"WHERE GTVSDAX_INTERNAL_CODE_GROUP ='ITESM_FACTURACION'\r\n" + 
			"	AND GTVSDAX_INTERNAL_CODE ='TZAMONF'\r\n" + 
			"	AND GTVSDAX_EXTERNAL_CODE = :PROCESS_CODE\r\n" + 
			"	AND ROWNUM = 1";
	
	public static final String QUERY_GET_PROCESS_DESC = "SELECT GTVSDAX_DESC\r\n" + 
			"FROM GTVSDAX\r\n" + 
			"WHERE GTVSDAX_INTERNAL_CODE_GROUP ='ITESM_FACTURACION'\r\n" + 
			"	AND GTVSDAX_INTERNAL_CODE ='TZAMONF'\r\n" + 
			"	AND GTVSDAX_EXTERNAL_CODE = :PROCESS_CODE\r\n" + 
			"	AND ROWNUM = 1";
	
	public static final String FUNCTION_GET_FAC_STATUS = "TZKHSTB.f_read_tzrarci_nfac_status";
}
