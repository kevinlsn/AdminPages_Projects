package net.hedtech.banner.arsys.Tzamonf;

import java.util.Hashtable;
import net.hedtech.general.common.forms.BaseTask;

public class TzamonfTask extends BaseTask {
	public TzamonfTask(String taskName) {
		super(taskName);
	}
	
	public TzamonfTask(String taskName, Hashtable sharedLibraries, Hashtable parameters) {
		super(taskName, sharedLibraries, parameters);
	}
	
	@Override
	public net.hedtech.banner.arsys.Tzamonf.model.TzamonfModel getModel() {
		return (net.hedtech.banner.arsys.Tzamonf.model.TzamonfModel)super.getModel();
	}
	
	public net.hedtech.banner.arsys.Tzamonf.services.TzamonfServices getServices() {
		return (net.hedtech.banner.arsys.Tzamonf.services.TzamonfServices)getSupportCodeManager().getServices();
	}
	
	// Attached Libraries
	
	public net.hedtech.general.common.libraries.Goqrpls.GoqrplsServices getGoqrpls() {
		return (net.hedtech.general.common.libraries.Goqrpls.GoqrplsServices)getSupportCodeManager().getLibrary("GOQRPLS");
	}
}
