package net.hedtech.banner.arsys.Tzamonf.model;

import morphis.foundations.core.appsupportlib.model.configuration.SimpleBusinessObjectConfiguration;
import morphis.foundations.core.types.*;
import static morphis.foundations.core.types.Types.*;

public class KeyBlock extends morphis.foundations.flavors.forms.appsupportlib.model.SimpleBusinessObject {

	public KeyBlock() {
		super();
	}

	public KeyBlock(SimpleBusinessObjectConfiguration configuration, String name) {
		super(configuration, name);
	}
		
	public NDate getDateFrom() {
		return toDate(super.getValue("DATE_FROM"));
	}

	public void setDateFrom(NDate value) {
		super.setValue("DATE_FROM", value);
	}

	public NDate getDateTo() {
		return toDate(super.getValue("DATE_TO"));
	}

	public void setDateTo(NDate value) {
		super.setValue("DATE_TO", value);
	}

	public NString getId() {
		return toStr(super.getValue("ID"));
	}

	public void setId(NString value) {
		super.setValue("ID", value);
	}

	public NString getIdDescription() {
		return toStr(super.getValue("ID_DESCRIPTION"));
	}

	public void setIdDescription(NString value) {
		super.setValue("ID_DESCRIPTION", value);
	}

	public NString getProcessCode() {
		return toStr(super.getValue("PROCESS_CODE"));
	}

	public void setProcessCode(NString value) {
		super.setValue("PROCESS_CODE", value);
	}

	public NString getShippingStatus() {
		return toStr(super.getValue("SHIPPING_STATUS"));
	}

	public void setShippingStatus(NString value) {
		super.setValue("SHIPPING_STATUS", value);
	}

	public NString getShippingStatusDescription() {
		return toStr(super.getValue("SHIPPING_STATUS_DESCRIPTION"));
	}

	public void setShippingStatusDescription(NString value) {
		super.setValue("SHIPPING_STATUS_DESCRIPTION", value);
	}

	public NString getIdProcess() {
		return toStr(super.getValue("ID_PROCESS"));
	}

	public void setIdProcess(NString value) {
		super.setValue("ID_PROCESS", value);
	}

	public NString getProcessDescription() {
		return toStr(super.getValue("PROCESS_DESCRIPTION"));
	}

	public void setProcessDescription(NString value) {
		super.setValue("PROCESS_DESCRIPTION", value);
	}

	public NString getIdLbt() {
		return toStr(super.getValue("ID_LBT"));
	}

	public void setIdLbt(NString value) {
		super.setValue("ID_LBT", value);
	}

	

		
}