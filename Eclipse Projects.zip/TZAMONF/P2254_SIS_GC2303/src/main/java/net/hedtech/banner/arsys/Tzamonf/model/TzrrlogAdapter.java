package net.hedtech.banner.arsys.Tzamonf.model;

import java.util.Date;
import java.math.BigDecimal;
import org.jdesktop.databuffer.DataRow;
//import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.types.*;
import morphis.foundations.core.appsupportlib.model.*;
import morphis.foundations.flavors.forms.appdatalayer.data.BaseRowAdapter;

public class TzrrlogAdapter extends BaseRowAdapter {

	public TzrrlogAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getTzrrlogPidm() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TZRRLOG_PIDM"));
		return v;
	}
	
	public void setTzrrlogPidm(NNumber value) {
		this.setValue("TZRRLOG_PIDM", value.getValue());
	}

	public NString getTzrrlogProcess() {
		NString v = new NString((String)this.getValue("TZRRLOG_PROCESS"));
		return v;
	}
	
	public void setTzrrlogProcess(NString value) {
		this.setValue("TZRRLOG_PROCESS", value.getValue());
	}

	public NString getTzrrlogReference() {
		NString v = new NString((String)this.getValue("TZRRLOG_REFERENCE"));
		return v;
	}
	
	public void setTzrrlogReference(NString value) {
		this.setValue("TZRRLOG_REFERENCE", value.getValue());
	}

	public NString getTzrrlogLog() {
		NString v = new NString((String)this.getValue("TZRRLOG_LOG"));
		return v;
	}
	
	public void setTzrrlogLog(NString value) {
		this.setValue("TZRRLOG_LOG", value.getValue());
	}

	public NString getTzrrlogUserId() {
		NString v = new NString((String)this.getValue("TZRRLOG_USER_ID"));
		return v;
	}
	
	public void setTzrrlogUserId(NString value) {
		this.setValue("TZRRLOG_USER_ID", value.getValue());
	}

	public NDate getTzrrlogActivityDate() {
		NDate v = new NDate((java.util.Date)this.getValue("TZRRLOG_ACTIVITY_DATE"));
		return v;
	}
	
	public void setTzrrlogActivityDate(NDate value) {
		this.setValue("TZRRLOG_ACTIVITY_DATE", value.getValue());
	}

	public NNumber getTzrrlogIdProcess() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TZRRLOG_ID_PROCESS"));
		return v;
	}
	
	public void setTzrrlogIdProcess(NNumber value) {
		this.setValue("TZRRLOG_ID_PROCESS", value.getValue());
	}

	public NNumber getTzrrlogSurrogateIdHstb() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TZRRLOG_SURROGATE_ID_HSTB"));
		return v;
	}
	
	public void setTzrrlogSurrogateIdHstb(NNumber value) {
		this.setValue("TZRRLOG_SURROGATE_ID_HSTB", value.getValue());
	}

	public NNumber getTzrrlogSequence() {
		NNumber v = new NNumber((BigDecimal) this.getValue("TZRRLOG_SEQUENCE"));
		return v;
	}

	public void setTzrrlogSequence(NNumber value) {
		this.setValue("TZRRLOG_SEQUENCE", value.getValue());
	}

}