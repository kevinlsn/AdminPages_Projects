package net.hedtech.banner.arsys.Tzamonf.controller;

import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import net.hedtech.general.common.dbservices.GNls;
import net.hedtech.general.common.forms.controller.DefaultBlockController;
import net.hedtech.banner.arsys.Tzamonf.TzamonfTask;
import net.hedtech.banner.arsys.Tzamonf.model.DataConstant;
import net.hedtech.banner.arsys.Tzamonf.model.TzamonfModel;
import net.hedtech.banner.arsys.Tzamonf.model.TzrhstbAdapter;
import morphis.foundations.core.appsupportlib.exceptions.ApplicationException;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.errorMessage;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.listValues;
import static morphis.foundations.core.types.Types.toStr;
import morphis.foundations.flavors.forms.types.formatting.OracleDateFormat;
import morphis.core.utils.behavior.annotations.*;
import morphis.foundations.core.appdatalayer.data.DbManager;
import morphis.foundations.core.appdatalayer.events.BeforeQuery;
import morphis.foundations.core.appdatalayer.events.QueryEvent;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appdatalayer.events.AfterQuery;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;
import morphis.foundations.core.appsupportlib.runtime.events.RecordRemoved;

public class TzrhstbController extends DefaultBlockController {

	public TzrhstbController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public TzamonfTask getTask() {
		return (TzamonfTask) super.getTask();
	}

	public TzamonfModel getFormModel() {
		return getTask().getModel();
	}

	@After
	@ActionTrigger(action="PRE-BLOCK", function=KeyFunction.BLOCK_IN)
	public void tzrhstb_blockIn()
	{
		
	}
	
	private void createParamOnQueryEvent(QueryEvent queryEvent, String parameterName, Object value) {
		((IDBBusinessObject) queryEvent.getSource()).getSelectCommandParams()
		.add(DbManager.getDataBaseFactory().createDataParameter(parameterName, value));
	}
	
	public TzrhstbAdapter getRowAdapter() {
		return (TzrhstbAdapter) this.getFormModel().getTzrhstb().getRowAdapter(true);
	}
	
	@BeforeQuery
	public void tzrhstb_BeforeQuery(QueryEvent queryEvent) {
		NNumber pidm = NNumber.getNull();
		
		if (this.getFormModel().getKeyBlock().getId().isNotNull()) {
			pidm = this.getTask().getServices().getPidm(this.getFormModel().getKeyBlock().getId());
		}
		
		OracleDateFormat formatter = new OracleDateFormat(DataConstant.FORMAT_DATE);
		
		NDate dateFrom = this.getFormModel().getKeyBlock().getDateFrom();
		NDate dateTo = this.getFormModel().getKeyBlock().getDateTo();
		NString dateFromFormatted = NString.getNull();
		NString dateToFormatted = NString.getNull();
		
		if (dateFrom.isNotNull()) {
			dateFromFormatted = NString.toStr(formatter.format(dateFrom.toDate()));
		}
		
		if (dateTo.isNotNull()) {
			dateToFormatted =  NString.toStr(formatter.format(dateTo.toDate()));
		}
		
		this.createParamOnQueryEvent(queryEvent, DataConstant.PIDM_LABEL, pidm);
		this.createParamOnQueryEvent(queryEvent, DataConstant.ID_PROCESS_LABEL, this.getFormModel().getKeyBlock().getIdProcess());
		this.createParamOnQueryEvent(queryEvent, DataConstant.PROCESS_LABEL, this.getFormModel().getKeyBlock().getProcessCode());
		this.createParamOnQueryEvent(queryEvent, DataConstant.SHIPPING_STATUS_LABEL, this.getFormModel().getKeyBlock().getShippingStatus());
		this.createParamOnQueryEvent(queryEvent, DataConstant.DATE_FROM_LABEL, dateFromFormatted);
		this.createParamOnQueryEvent(queryEvent, DataConstant.DATE_TO_LABEL, dateToFormatted);
	}

	@AfterQuery
	public void tzrhstb_AfterQuery(RowAdapterEvent rowAdapterEvent) {
		if (this.getRowAdapter() == null) return;
		
		NString status = NString.getNull();
		this.getRowAdapter().setTzrarciNfacStatusChg(status);
		this.getRowAdapter().setTzrarciNfacStatusPay(status);
		
		if (this.getRowAdapter().getTzrhstbTranNumChg().isNotNull()) {
			status = this.getTask().getServices().getfacStatus(this.getRowAdapter().getTzrhstbPidm(), this.getRowAdapter().getTzrhstbTranNumChg());
			this.getRowAdapter().setTzrarciNfacStatusChg(status);
		}
		
		if (this.getRowAdapter().getTzrhstbTranNumPay().isNotNull()) {
			status = this.getTask().getServices().getfacStatus(this.getRowAdapter().getTzrhstbPidm(), this.getRowAdapter().getTzrhstbTranNumPay());
			this.getRowAdapter().setTzrarciNfacStatusPay(status);
		}
		
		NString description = NString.getNull();
		
		if (this.getRowAdapter().getTzrhstbProcessInd().isNotNull()) {
			NBool exists = this.getTask().getServices().existsShippingStatus(this.getRowAdapter().getTzrhstbProcessInd());
			
			if (exists.isTrue()) {
				description = this.getTask().getServices().getShippingStatusDescription(this.getRowAdapter().getTzrhstbProcessInd());
			}
		}
		
		this.getRowAdapter().setTzrhstbProcessIndDesc(description);
	}

	@ActionTrigger(action="WHEN-NEW-RECORD-INSTANCE", item = "TZRHSTB_PROCESS_IND", function = KeyFunction.ITEM_IN)
	public void tzrhstb_process_ind_KeyAction_item_in() {
		if (this.getRowAdapter() != null && (this.getRowAdapter().getTzrhstbUuidRet().isNotNull() 
				|| this.getRowAdapter().getTzrhstbStatusIdRet().compareTo(DataConstant.STATUS_VALID_CFDI) == 0)) {
			setItemEnabled(DataConstant.ITEM_PROCESS_IND, NBool.False);
			setItemNavigable(DataConstant.ITEM_PROCESS_IND, NBool.False);
			setItemUpdateAllowed(DataConstant.ITEM_PROCESS_IND, NBool.False);
			setItemInsertAllowed(DataConstant.ITEM_PROCESS_IND, NBool.False);
		} else {
			setItemEnabled(DataConstant.ITEM_PROCESS_IND, NBool.True);
			setItemNavigable(DataConstant.ITEM_PROCESS_IND, NBool.True);
			setItemUpdateAllowed(DataConstant.ITEM_PROCESS_IND, NBool.True);
			setItemInsertAllowed(DataConstant.ITEM_PROCESS_IND, NBool.True);
		}
	}

	@ActionTrigger(item = "TZRHSTB_PROCESS_IND", function = KeyFunction.LIST_VALUES)
	public void tzrhstb_process_ind_KeyAction_list_values() {
		listValues();
		nextItem();
	}

	@ValidationTrigger(item = "TZRHSTB_PROCESS_IND")
	public void tzrhstb_process_ind_validation() {
		if (this.getRowAdapter() == null) return;
		
		NString description = NString.getNull();
		
		if (this.getRowAdapter().getTzrhstbProcessInd().isNotNull()) {
			NBool exists = this.getTask().getServices().existsShippingStatus(this.getRowAdapter().getTzrhstbProcessInd());
			
			if (exists.isFalse()) {
				this.getRowAdapter().setTzrhstbProcessInd(description);
				errorMessage(GNls.Fget(toStr(DataConstant.SECOND_MESSAGE_LABEL), toStr(DataConstant.FORM_LABEL), toStr(DataConstant.MESSAGE_SHIPPING_STATUS_INVALID)));
				goItem(DataConstant.ITEM_PROCESS_IND);
				throw new ApplicationException();
			}
			
			description = this.getTask().getServices().getShippingStatusDescription(this.getRowAdapter().getTzrhstbProcessInd());
		}
		
		this.getRowAdapter().setTzrhstbProcessIndDesc(description);
	}

	@RecordRemoved
	public void tzrhstb_RecordRemoved(RowAdapterEvent rowAdapterEvent) {
		if (this.getRowAdapter() == null) return;
		
		if (this.getRowAdapter().getTzrhstbUuidRet().isNotNull() 
				|| this.getRowAdapter().getTzrhstbStatusIdRet().compareTo(DataConstant.STATUS_VALID_CFDI) == 0) {
			errorMessage(GNls.Fget(toStr(DataConstant.FIFTH_MESSAGE_LABEL), toStr(DataConstant.FORM_LABEL), toStr(DataConstant.MESSAGE_CAN_NOT_DELETE_RECORD)));
			goItem(DataConstant.ITEM_ID_LABEL);
			throw new ApplicationException();
		}
	}
	
}