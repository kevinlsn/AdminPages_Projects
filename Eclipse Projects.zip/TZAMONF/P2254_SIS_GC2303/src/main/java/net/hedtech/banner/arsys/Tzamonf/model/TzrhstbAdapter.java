package net.hedtech.banner.arsys.Tzamonf.model;

import java.util.Date;
import java.math.BigDecimal;
import org.jdesktop.databuffer.DataRow;
//import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.types.*;
import morphis.foundations.core.appsupportlib.model.*;
import morphis.foundations.flavors.forms.appdatalayer.data.BaseRowAdapter;

public class TzrhstbAdapter extends BaseRowAdapter {

	public TzrhstbAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	public NNumber getTzrhstbPidm() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TZRHSTB_PIDM"));
		return v;
	}
	
	public void setTzrhstbPidm(NNumber value) {
		this.setValue("TZRHSTB_PIDM", value.getValue());
	}

	public NString getTzrhstbId() {
		NString v = new NString((String)this.getValue("TZRHSTB_ID"));
		return v;
	}
	
	public void setTzrhstbId(NString value) {
		this.setValue("TZRHSTB_ID", value.getValue());
	}

	public NString getTzrhstbFullName() {
		NString v = new NString((String)this.getValue("TZRHSTB_FULL_NAME"));
		return v;
	}
	
	public void setTzrhstbFullName(NString value) {
		this.setValue("TZRHSTB_FULL_NAME", value.getValue());
	}

	public NString getTzrhstbCampusChg() {
		NString v = new NString((String)this.getValue("TZRHSTB_CAMPUS_CHG"));
		return v;
	}
	
	public void setTzrhstbCampusChg(NString value) {
		this.setValue("TZRHSTB_CAMPUS_CHG", value.getValue());
	}

	public NString getTzrhstbCampusDescChg() {
		NString v = new NString((String)this.getValue("TZRHSTB_CAMPUS_DESC_CHG"));
		return v;
	}
	
	public void setTzrhstbCampusDescChg(NString value) {
		this.setValue("TZRHSTB_CAMPUS_DESC_CHG", value.getValue());
	}

	public NNumber getTzrhstbTranNumChg() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TZRHSTB_TRAN_NUM_CHG"));
		return v;
	}
	
	public void setTzrhstbTranNumChg(NNumber value) {
		this.setValue("TZRHSTB_TRAN_NUM_CHG", value.getValue());
	}

	public NString getTzrhstbDetailCodeChg() {
		NString v = new NString((String)this.getValue("TZRHSTB_DETAIL_CODE_CHG"));
		return v;
	}
	
	public void setTzrhstbDetailCodeChg(NString value) {
		this.setValue("TZRHSTB_DETAIL_CODE_CHG", value.getValue());
	}

	public NString getTzrhstbDescCodeChg() {
		NString v = new NString((String)this.getValue("TZRHSTB_DESC_CODE_CHG"));
		return v;
	}
	
	public void setTzrhstbDescCodeChg(NString value) {
		this.setValue("TZRHSTB_DESC_CODE_CHG", value.getValue());
	}

	public NDate getTzrhstbTransactionDateChg() {
		NDate v = new NDate((java.util.Date)this.getValue("TZRHSTB_TRANSACTION_DATE_CHG"));
		return v;
	}
	
	public void setTzrhstbTransactionDateChg(NDate value) {
		this.setValue("TZRHSTB_TRANSACTION_DATE_CHG", value.getValue());
	}

	public NDate getTzrhstbEffectiveDateChg() {
		NDate v = new NDate((java.util.Date)this.getValue("TZRHSTB_EFFECTIVE_DATE_CHG"));
		return v;
	}
	
	public void setTzrhstbEffectiveDateChg(NDate value) {
		this.setValue("TZRHSTB_EFFECTIVE_DATE_CHG", value.getValue());
	}

	public NString getTzrhstbTermChg() {
		NString v = new NString((String)this.getValue("TZRHSTB_TERM_CHG"));
		return v;
	}
	
	public void setTzrhstbTermChg(NString value) {
		this.setValue("TZRHSTB_TERM_CHG", value.getValue());
	}

	public NString getTzrhstbTermDescChg() {
		NString v = new NString((String)this.getValue("TZRHSTB_TERM_DESC_CHG"));
		return v;
	}
	
	public void setTzrhstbTermDescChg(NString value) {
		this.setValue("TZRHSTB_TERM_DESC_CHG", value.getValue());
	}	

	public NString getTzrhstbCampusPay() {
		NString v = new NString((String)this.getValue("TZRHSTB_CAMPUS_PAY"));
		return v;
	}
	
	public void setTzrhstbCampusPay(NString value) {
		this.setValue("TZRHSTB_CAMPUS_PAY", value.getValue());
	}

	public NString getTzrhstbCampusDescPay() {
		NString v = new NString((String)this.getValue("TZRHSTB_CAMPUS_DESC_PAY"));
		return v;
	}
	
	public void setTzrhstbCampusDescPay(NString value) {
		this.setValue("TZRHSTB_CAMPUS_DESC_PAY", value.getValue());
	}

	public NNumber getTzrhstbTranNumPay() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TZRHSTB_TRAN_NUM_PAY"));
		return v;
	}
	
	public void setTzrhstbTranNumPay(NNumber value) {
		this.setValue("TZRHSTB_TRAN_NUM_PAY", value.getValue());
	}

	public NString getTzrhstbDetailCodePay() {
		NString v = new NString((String)this.getValue("TZRHSTB_DETAIL_CODE_PAY"));
		return v;
	}
	
	public void setTzrhstbDetailCodePay(NString value) {
		this.setValue("TZRHSTB_DETAIL_CODE_PAY", value.getValue());
	}

	public NString getTzrhstbDescCodePay() {
		NString v = new NString((String)this.getValue("TZRHSTB_DESC_CODE_PAY"));
		return v;
	}
	
	public void setTzrhstbDescCodePay(NString value) {
		this.setValue("TZRHSTB_DESC_CODE_PAY", value.getValue());
	}

	public NString getTzrhstbCurrencyPay() {
		NString v = new NString((String)this.getValue("TZRHSTB_CURRENCY_PAY"));
		return v;
	}
	
	public void setTzrhstbCurrencyPay(NString value) {
		this.setValue("TZRHSTB_CURRENCY_PAY", value.getValue());
	}

	public NDate getTzrhstbTransactionDatePay() {
		NDate v = new NDate((java.util.Date)this.getValue("TZRHSTB_TRANSACTION_DATE_PAY"));
		return v;
	}
	
	public void setTzrhstbTransactionDatePay(NDate value) {
		this.setValue("TZRHSTB_TRANSACTION_DATE_PAY", value.getValue());
	}

	public NDate getTzrhstbEffectiveDatePay() {
		NDate v = new NDate((java.util.Date)this.getValue("TZRHSTB_EFFECTIVE_DATE_PAY"));
		return v;
	}
	
	public void setTzrhstbEffectiveDatePay(NDate value) {
		this.setValue("TZRHSTB_EFFECTIVE_DATE_PAY", value.getValue());
	}

	public NNumber getTzrhstbAmountInv() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TZRHSTB_AMOUNT_INV"));
		return v;
	}
	
	public void setTzrhstbAmountInv(NNumber value) {
		this.setValue("TZRHSTB_AMOUNT_INV", value.getValue());
	}

	public NString getTzrhstbInvoiceNumRet() {
		NString v = new NString((String)this.getValue("TZRHSTB_INVOICE_NUM_RET"));
		return v;
	}
	
	public void setTzrhstbInvoiceNumRet(NString value) {
		this.setValue("TZRHSTB_INVOICE_NUM_RET", value.getValue());
	}

	public NString getTzrhstbStatusIdRet() {
		NString v = new NString((String)this.getValue("TZRHSTB_STATUS_ID_RET"));
		return v;
	}
	
	public void setTzrhstbStatusIdRet(NString value) {
		this.setValue("TZRHSTB_STATUS_ID_RET", value.getValue());
	}

	public NString getTzrhstbVersionRet() {
		NString v = new NString((String)this.getValue("TZRHSTB_VERSION_RET"));
		return v;
	}
	
	public void setTzrhstbVersionRet(NString value) {
		this.setValue("TZRHSTB_VERSION_RET", value.getValue());
	}

	public NString getTzrhstbCompTypeRet() {
		NString v = new NString((String)this.getValue("TZRHSTB_COMP_TYPE_RET"));
		return v;
	}
	
	public void setTzrhstbCompTypeRet(NString value) {
		this.setValue("TZRHSTB_COMP_TYPE_RET", value.getValue());
	}

	public NString getTzrhstbCompSubTypeRet() {
		NString v = new NString((String)this.getValue("TZRHSTB_COMP_SUB_TYPE_RET"));
		return v;
	}
	
	public void setTzrhstbCompSubTypeRet(NString value) {
		this.setValue("TZRHSTB_COMP_SUB_TYPE_RET", value.getValue());
	}

	public NString getTzrhstbSerieRet() {
		NString v = new NString((String)this.getValue("TZRHSTB_SERIE_RET"));
		return v;
	}
	
	public void setTzrhstbSerieRet(NString value) {
		this.setValue("TZRHSTB_SERIE_RET", value.getValue());
	}

	public NString getTzrhstbFolioRet() {
		NString v = new NString((String)this.getValue("TZRHSTB_FOLIO_RET"));
		return v;
	}
	
	public void setTzrhstbFolioRet(NString value) {
		this.setValue("TZRHSTB_FOLIO_RET", value.getValue());
	}

	public NString getTzrhstbUuidRet() {
		NString v = new NString((String)this.getValue("TZRHSTB_UUID_RET"));
		return v;
	}
	
	public void setTzrhstbUuidRet(NString value) {
		this.setValue("TZRHSTB_UUID_RET", value.getValue());
	}

	public NString getTzrhstbUuidRelRet() {
		NString v = new NString((String)this.getValue("TZRHSTB_UUID_REL_RET"));
		return v;
	}
	
	public void setTzrhstbUuidRelRet(NString value) {
		this.setValue("TZRHSTB_UUID_REL_RET", value.getValue());
	}

	public NString getTzrhstbRelTypeRet() {
		NString v = new NString((String)this.getValue("TZRHSTB_REL_TYPE_RET"));
		return v;
	}
	
	public void setTzrhstbRelTypeRet(NString value) {
		this.setValue("TZRHSTB_REL_TYPE_RET", value.getValue());
	}

	public NString getTzrhstbPaymentTypeRet() {
		NString v = new NString((String)this.getValue("TZRHSTB_PAYMENT_TYPE_RET"));
		return v;
	}
	
	public void setTzrhstbPaymentTypeRet(NString value) {
		this.setValue("TZRHSTB_PAYMENT_TYPE_RET", value.getValue());
	}

	public NString getTzrhstbPaymentMethodRet() {
		NString v = new NString((String)this.getValue("TZRHSTB_PAYMENT_METHOD_RET"));
		return v;
	}
	
	public void setTzrhstbPaymentMethodRet(NString value) {
		this.setValue("TZRHSTB_PAYMENT_METHOD_RET", value.getValue());
	}

	public NString getTzrhstbRfcClientRet() {
		NString v = new NString((String)this.getValue("TZRHSTB_RFC_CLIENT_RET"));
		return v;
	}
	
	public void setTzrhstbRfcClientRet(NString value) {
		this.setValue("TZRHSTB_RFC_CLIENT_RET", value.getValue());
	}

	public NDate getTzrhstbIssueDateRet() {
		NDate v = new NDate((java.util.Date)this.getValue("TZRHSTB_ISSUE_DATE_RET"));
		return v;
	}
	
	public void setTzrhstbIssueDateRet(NDate value) {
		this.setValue("TZRHSTB_ISSUE_DATE_RET", value.getValue());
	}

	public NDate getTzrhstbCancelDateRet() {
		NDate v = new NDate((java.util.Date)this.getValue("TZRHSTB_CANCEL_DATE_RET"));
		return v;
	}
	
	public void setTzrhstbCancelDateRet(NDate value) {
		this.setValue("TZRHSTB_CANCEL_DATE_RET", value.getValue());
	}

	public NString getTzrhstbProcessedStatusRet() {
		NString v = new NString((String)this.getValue("TZRHSTB_PROCESSED_STATUS_RET"));
		return v;
	}
	
	public void setTzrhstbProcessedStatusRet(NString value) {
		this.setValue("TZRHSTB_PROCESSED_STATUS_RET", value.getValue());
	}

	public NString getTzrhstbSegment() {
		NString v = new NString((String)this.getValue("TZRHSTB_SEGMENT"));
		return v;
	}
	
	public void setTzrhstbSegment(NString value) {
		this.setValue("TZRHSTB_SEGMENT", value.getValue());
	}

	public NString getTzrhstbProcessInd() {
		NString v = new NString((String)this.getValue("TZRHSTB_PROCESS_IND"));
		return v;
	}
	
	public void setTzrhstbProcessInd(NString value) {
		this.setValue("TZRHSTB_PROCESS_IND", value.getValue());
	}

	public NDate getTzrhstbActivityDate() {
		NDate v = new NDate((java.util.Date)this.getValue("TZRHSTB_ACTIVITY_DATE"));
		return v;
	}
	
	public void setTzrhstbActivityDate(NDate value) {
		this.setValue("TZRHSTB_ACTIVITY_DATE", value.getValue());
	}

	public NString getTzrhstbUserId() {
		NString v = new NString((String)this.getValue("TZRHSTB_USER_ID"));
		return v;
	}
	
	public void setTzrhstbUserId(NString value) {
		this.setValue("TZRHSTB_USER_ID", value.getValue());
	}

	public NNumber getTzrhstbSurrogateId() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TZRHSTB_SURROGATE_ID"));
		return v;
	}
	
	public void setTzrhstbSurrogateId(NNumber value) {
		this.setValue("TZRHSTB_SURROGATE_ID", value.getValue());
	}

	public NString getTzrhstbDataOrigin() {
		NString v = new NString((String)this.getValue("TZRHSTB_DATA_ORIGIN"));
		return v;
	}
	
	public void setTzrhstbDataOrigin(NString value) {
		this.setValue("TZRHSTB_DATA_ORIGIN", value.getValue());
	}

	public NString getTzrhstbDescStatusRet() {
		NString v = new NString((String)this.getValue("TZRHSTB_DESC_STATUS_RET"));
		return v;
	}
	
	public void setTzrhstbDescStatusRet(NString value) {
		this.setValue("TZRHSTB_DESC_STATUS_RET", value.getValue());
	}

	public NString getTzrhstbCalcNfacStatus() {
		NString v = new NString((String)this.getValue("TZRHSTB_CALC_NFAC_STATUS"));
		return v;
	}
	
	public void setTzrhstbCalcNfacStatus(NString value) {
		this.setValue("TZRHSTB_CALC_NFAC_STATUS", value.getValue());
	}

	public NString getTzrhstbRazonSocialRet() {
		NString v = new NString((String)this.getValue("TZRHSTB_RAZON_SOCIAL_RET"));
		return v;
	}
	
	public void setTzrhstbRazonSocialRet(NString value) {
		this.setValue("TZRHSTB_RAZON_SOCIAL_RET", value.getValue());
	}

	public NNumber getTzrhstbIdProcess() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TZRHSTB_ID_PROCESS"));
		return v;
	}
	
	public void setTzrhstbIdProcess(NNumber value) {
		this.setValue("TZRHSTB_ID_PROCESS", value.getValue());
	}

	public NString getTzrarciNfacStatusChg() {
		NString v = new NString((String) this.getValue("TZRARCI_NFAC_STATUS_CHG"));
		return v;
	}

	public void setTzrarciNfacStatusChg(NString value) {
		this.setValue("TZRARCI_NFAC_STATUS_CHG", value.getValue());
	}

	public NString getTzrarciNfacStatusPay() {
		NString v = new NString((String) this.getValue("TZRARCI_NFAC_STATUS_PAY"));
		return v;
	}

	public void setTzrarciNfacStatusPay(NString value) {
		this.setValue("TZRARCI_NFAC_STATUS_PAY", value.getValue());
	}

	public NString getTzrhstbProcessIndDesc() {
		NString v = new NString((String) this.getValue("TZRHSTB_PROCESS_IND_DESC"));
		return v;
	}

	public void setTzrhstbProcessIndDesc(NString value) {
		this.setValue("TZRHSTB_PROCESS_IND_DESC", value.getValue());
	}

}