package net.hedtech.banner.arsys.Tzamonf.controller;

import morphis.foundations.core.appsupportlib.runtime.ITask;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.util.globals.Globals.setGlobal;
import net.hedtech.general.common.forms.controller.DefaultFormController;
import net.hedtech.banner.arsys.Tzamonf.TzamonfTask;
import net.hedtech.banner.arsys.Tzamonf.model.DataConstant;
import net.hedtech.banner.arsys.Tzamonf.model.TzamonfModel;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import morphis.foundations.core.types.*;
import java.util.EventObject;
import morphis.core.utils.behavior.annotations.Before;
import morphis.foundations.core.appdatalayer.events.CancelEvent;
import morphis.foundations.core.appsupportlib.model.AfterCommit;
import morphis.foundations.core.appsupportlib.model.BeforeCommit;
import morphis.foundations.core.appsupportlib.model.OnRollback;
import morphis.foundations.core.appsupportlib.runtime.events.TaskEnded;
import morphis.foundations.core.appsupportlib.runtime.events.TaskStarted;
import morphis.foundations.core.appsupportlib.runtime.events.TaskStartedPre;
import net.hedtech.general.common.libraries.Goqolib.services.GFormClass;
import net.hedtech.general.common.libraries.Goqolib.services.*;

public class TzamonfFormController extends DefaultFormController {

	public TzamonfFormController(ITask task) {
		super(task);
	}

	@Override
	public TzamonfTask getTask() {
		return (TzamonfTask) super.getTask();
	}

	public TzamonfModel getFormModel() {
		return getTask().getModel();
	}

	private GFormClass getGFormClass() {
		return (GFormClass) this.getTask().getTaskPart("GOQOLIB").getSupportCodeManager().getPackage("G$_FORM_CLASS");
	}	

	private GApplFormClass getGApplFormClass() {
		return (GApplFormClass) this.getTask().getTaskPart("GOQOLIB").getSupportCodeManager().getPackage("G$_APPL_FORM_CLASS");
	}	

	@ActionTrigger(action="SAVE_KEYS")
	public void Tzamonf_SaveKeys()
	{
		setGlobal(DataConstant.DATE_FROM_LABEL, this.getFormModel().getKeyBlock().getDateFrom());
		setGlobal(DataConstant.DATE_TO_LABEL, this.getFormModel().getKeyBlock().getDateTo());
		setGlobal(DataConstant.ID_LABEL, this.getFormModel().getKeyBlock().getId());
		setGlobal(DataConstant.ID_DESCRIPTION_LABEL, this.getFormModel().getKeyBlock().getIdDescription());
		setGlobal(DataConstant.ID_PROCESS_LABEL, this.getFormModel().getKeyBlock().getIdProcess());
		setGlobal(DataConstant.PROCESS_CODE_LABEL, this.getFormModel().getKeyBlock().getProcessCode());
		setGlobal(DataConstant.PROCESS_LABEL, this.getFormModel().getKeyBlock().getProcessDescription());
		setGlobal(DataConstant.SHIPPING_STATUS_LABEL, this.getFormModel().getKeyBlock().getShippingStatus());
		setGlobal(DataConstant.SHIPPING_STATUS_DESCRIPTION_LABEL, this.getFormModel().getKeyBlock().getShippingStatusDescription());
	}

	@ActionTrigger(action="GLOBAL_COPY")
	public void Tzamonf_GlobalCopy()
	{
		this.getFormModel().getKeyBlock().setDateFrom(NDate.toDate(getGlobal(DataConstant.DATE_FROM_LABEL)));
		this.getFormModel().getKeyBlock().setDateTo(NDate.toDate(getGlobal(DataConstant.DATE_TO_LABEL)));
		this.getFormModel().getKeyBlock().setId(getGlobal(DataConstant.ID_LABEL));
		this.getFormModel().getKeyBlock().setIdDescription(getGlobal(DataConstant.ID_DESCRIPTION_LABEL));
		this.getFormModel().getKeyBlock().setIdProcess(getGlobal(DataConstant.ID_PROCESS_LABEL));
		this.getFormModel().getKeyBlock().setProcessCode(getGlobal(DataConstant.PROCESS_CODE_LABEL));
		this.getFormModel().getKeyBlock().setProcessDescription(getGlobal(DataConstant.PROCESS_LABEL));
		this.getFormModel().getKeyBlock().setShippingStatus(getGlobal(DataConstant.SHIPPING_STATUS_LABEL));
		this.getFormModel().getKeyBlock().setShippingStatusDescription(getGlobal(DataConstant.SHIPPING_STATUS_DESCRIPTION_LABEL));
	}

	@ActionTrigger(action="CHECK_KEYS")
	public void Tzamonf_CheckKeys()
	{
	}

	@ActionTrigger(action="DISABLE_KEYS")
	public void Tzamonf_DisableKeys()
	{	
		setItemEnabled(DataConstant.DATE_FROM_LABEL, NBool.False);
		setItemEnabled(DataConstant.DATE_TO_LABEL, NBool.False);
		setItemEnabled(DataConstant.ID_LABEL, NBool.False);
		setItemEnabled(DataConstant.ID_PROCESS_LABEL, NBool.False);
		setItemEnabled(DataConstant.SHIPPING_STATUS_LABEL, NBool.False);
		setItemEnabled(DataConstant.PROCESS_CODE_LABEL, NBool.False);
	}

	@ActionTrigger(action="ENABLE_KEYS")
	public void Tzamonf_EnableKeys()
	{		
		setItemEnabled(DataConstant.DATE_FROM_LABEL, NBool.True);
		setItemEnabled(DataConstant.DATE_TO_LABEL, NBool.True);
		setItemEnabled(DataConstant.ID_LABEL, NBool.True);
		setItemEnabled(DataConstant.ID_PROCESS_LABEL, NBool.True);
		setItemEnabled(DataConstant.SHIPPING_STATUS_LABEL, NBool.True);
		setItemEnabled(DataConstant.PROCESS_CODE_LABEL, NBool.True);
	}

	@ActionTrigger(action="WHEN_NEW_BLOCK_INSTANCE_TRG")
	public void Tzamonf_WhenNewBlockInstanceTrg()
	{	
		
	}

	@ActionTrigger(action="LOAD_CURRENT_RELEASE")
	public void Tzamonf_LoadCurrentRelease()
	{	
		getFormModel().getFormHeader().setCurrentRelease(toStr(""));
	}

	@ActionTrigger(action="KEY-CLRFRM", function=KeyFunction.CLEAR_FORM)
	public void Tzamonf_ClearTask()
	{	
			executeAction("SAVE_KEYS");
			getTask().getGoqrpls().gCheckFailure();
			executeAction("ENABLE_KEYS");
			getTask().getGoqrpls().gCheckFailure();
			
			clearTask();
			getTask().getGoqrpls().gCheckFailure();
			
			executeAction("LOAD_FORM_HEADER");
			getTask().getGoqrpls().gCheckFailure();
			executeAction("GLOBAL_COPY");
			getTask().getGoqrpls().gCheckFailure();
	}

	@ActionTrigger(action="KEY-NXTBLK", function=KeyFunction.NEXT_BLOCK)
	public void Tzamonf_NextBlock()
	{
		getGFormClass().nextBlock();
	}

	@ActionTrigger(action="G$_VERIFY_ACCESS")
	public void Tzamonf_GVerifyAccess()
	{
		getGFormClass().gVerifyAccess();
	}

	@TaskStartedPre
	public void Tzamonf_TaskStartedPre(EventObject args)
	{
		getGFormClass().taskStartedPre(args);
	}

	@TaskStarted
	public void Tzamonf_TaskStarted(EventObject args)
	{
		getGFormClass().taskStarted(args);
	}

	@ActionTrigger(action="PRE_FORM_TRG")
	public void Tzamonf_PreFormTrg()
	{
		getGFormClass().preFormTrg();
	}

	@TaskEnded
	public void Tzamonf_TaskEnded(EventObject args)
	{
		getGFormClass().taskEnded(args);
	}

	@ActionTrigger(action="POST_FORM_TRG")
	public void Tzamonf_PostFormTrg()
	{
		getGFormClass().postFormTrg();
	}

	@ActionTrigger(action="PRE-BLOCK", function=KeyFunction.BLOCK_IN)
	@Before
	public void Tzamonf_blockIn()
	{
		getGFormClass().blockIn();
	}

	@ActionTrigger(action="PRE_BLOCK_TRG")
	public void Tzamonf_PreBlockTrg()
	{
		getGFormClass().preBlockTrg();
	}

	@ActionTrigger(action="POST-BLOCK", function=KeyFunction.BLOCK_OUT)
	@Before
	public void Tzamonf_blockOut()
	{
		getGFormClass().blockOut();
	}

	@ActionTrigger(action="POST_BLOCK_TRG")
	public void Tzamonf_PostBlockTrg()
	{
		getGFormClass().postBlockTrg();
	}

	@BeforeCommit
	public void Tzamonf_BeforeCommit(CancelEvent args)
	{
		getGFormClass().beforeCommit(args);
	}

	@ActionTrigger(action="PRE_COMMIT_TRG")
	public void Tzamonf_PreCommitTrg()
	{
		getGFormClass().preCommitTrg();
	}

	@OnRollback
	public void Tzamonf_OnRollback(EventObject args)
	{
		getGFormClass().onRollback();
	}

	@ActionTrigger(action="ON_ROLLBACK_TRG")
	public void Tzamonf_OnRollbackTrg()
	{
		getGFormClass().onRollbackTrg();
	}

	@ActionTrigger(action="ON-SELECT")
	public void Tzamonf_OnSelect()
	{
		getGFormClass().onSelect();
	}

	@AfterCommit
	public void Tzamonf_AfterCommit(EventObject args)
	{
		getGFormClass().afterCommit(args);
	}

	@ActionTrigger(action="POST_FORMS_COMMIT_TRG")
	public void Tzamonf_PostFormsCommitTrg()
	{
		getGFormClass().postFormsCommitTrg();
	}

	@ActionTrigger(action="WHEN-BUTTON-PRESSED")
	public void Tzamonf_buttonClick()
	{
		getGFormClass().click();
	}

	@ActionTrigger(action="WHEN-NEW-BLOCK-INSTANCE", function=KeyFunction.BLOCK_CHANGE)
	@Before
	public void Tzamonf_blockChange()
	{
		getGFormClass().blockChange();
	}

	@ActionTrigger(action="WHEN-WINDOW-ACTIVATED")
	public void Tzamonf_WhenWindowActivated()
	{
		getGFormClass().whenWindowActivated();
	}

	@ActionTrigger(action="WHEN-WINDOW-CLOSED")
	public void Tzamonf_WhenWindowClosed()
	{
		getGFormClass().whenWindowClosed();
	}

	@ActionTrigger(action="KEY-PRVBLK", function=KeyFunction.PREVIOUS_BLOCK)
	public void Tzamonf_PreviousBlock()
	{
		getGFormClass().previousBlock();
	}
}