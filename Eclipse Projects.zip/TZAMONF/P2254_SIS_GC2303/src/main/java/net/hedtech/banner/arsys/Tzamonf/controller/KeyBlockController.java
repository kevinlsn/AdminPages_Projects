package net.hedtech.banner.arsys.Tzamonf.controller;

import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static net.hedtech.general.common.forms.services.BaseTaskServices.executeAction;
import net.hedtech.general.common.forms.controller.DefaultBlockController;
import net.hedtech.banner.arsys.Tzamonf.model.DataConstant;
import net.hedtech.banner.arsys.Tzamonf.TzamonfTask;
import net.hedtech.banner.arsys.Tzamonf.model.TzamonfModel;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.appsupportlib.exceptions.ApplicationException;
import net.hedtech.general.common.dbservices.GNls;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.nextBlock;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.errorMessage;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;

public class KeyBlockController extends DefaultBlockController {

	public KeyBlockController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public TzamonfTask getTask() {
		return (TzamonfTask) super.getTask();
	}

	public TzamonfModel getFormModel() {
		return getTask().getModel();
	}

	@ActionTrigger(action="KEY-NXTBLK", function=KeyFunction.NEXT_BLOCK)
	public void keyBlock_NextBlock()
	{
		nextBlock();
		executeQuery();
		executeAction("DISABLE_KEYS");
	}

	@ActionTrigger(action="POST-BLOCK", function=KeyFunction.BLOCK_OUT)
	public void keyBlock_blockOut()
	{
		getFormModel().getButtonControlBlock().setCheckKeys(toStr("Y"));
	}
	
	@ActionTrigger(action="WHEN-BUTTON-PRESSED", item="ID_LBT")
	public void idLbt_buttonClick()
	{
		getTask().getGoqrpls().gKeyOptMenu(toStr("KEY_BLOCK.ID"), GNls.Fget(toStr("TZAMONF-0078"), toStr("FORM"), toStr("Person Search (SOAIDEN)")), toStr("LIST_VALUES"),
																  GNls.Fget(toStr("TZAMONF-0079"), toStr("FORM"), toStr("Non-Person Search (SOACOMP)")), toStr("COUNT_QUERY"),
																  GNls.Fget(toStr("TZAMONF-0080"), toStr("FORM"), toStr("Alternate ID Search (GUIALTI)")), toStr("DUPLICATE_ITEM"), 
																  //toStr(""), toStr(""),toStr(""), 
																  toStr(""), toStr(""));
		getTask().getGoqrpls().gCheckFailure();
		getFormModel().getButtonControlBlock().setCheckKeys(toStr("N"));
	}
	
	
	@ActionTrigger(action="KEY-LISTVAL", item="ID", function=KeyFunction.LIST_VALUES)
	public void id_KeyAction_list_values()
	{
		System.out.println("KeyBlockController.id_KeyAction_list_values()");
		

			// [DONE]F2J_TODO : This trigger does not fire on Enter Query mode. See documentation for details.
			getTask().getGoqrpls().gCopyFldAttr();
			//  CALL_FORM( 'SOAIDEN' ,NO_HIDE,DO_REPLACE,QUERY_ONLY);
			executeAction("G$_REVOKE_ACCESS");
			getTask().getGoqrpls().gCheckFailure();
			getTask().getGoqrpls().gSecuredFormCall(getGlobal("CURRENT_USER"), toStr("SOAIDEN"), toStr("QUERY"));
			getTask().getGoqrpls().gResetGlobal();
			// 
			if ( !getGlobal("VALUE").isNull() )
			{
				this.getFormModel().getKeyBlock().setId(getGlobal("VALUE"));
				getTask().getGoqrpls().gCheckFailure();
				nextItem();
			}
		}
	
	@ActionTrigger(action="KEY-CQUERY", item="ID", function=KeyFunction.COUNT_QUERY)
	public void id_KeyAction_count_query()
	{
		System.out.println("KeyBlockController.id_KeyAction_count_query()");
			executeAction("G$_REVOKE_ACCESS");
			getTask().getGoqrpls().gCheckFailure();
			getTask().getGoqrpls().gSecuredFormCall(getGlobal("CURRENT_USER"), toStr("SOACOMP"), toStr("QUERY"));
			// 
			if ( !getGlobal("VALUE").isNull() )
			{
				this.getFormModel().getKeyBlock().setId(getGlobal("VALUE"));
				getTask().getGoqrpls().gCheckFailure();
				nextItem();
			}
	}

	
	@ActionTrigger(action="KEY-DUP-ITEM", item = "ID", function = KeyFunction.DUPLICATE_ITEM)
	public void id_KeyAction_duplicate_item() {
		System.out.println("KeyBlockController.id_KeyAction_duplicate_item()");
		executeAction("G$_REVOKE_ACCESS");
		getTask().getGoqrpls().gSecuredFormCall(getGlobal("CURRENT_USER"), toStr("GUIALTI"), toStr("QUERY"));
		getTask().getGoqrpls().gResetGlobal();
		
		if ( !getGlobal("VALUE").isNull() )
		{
			this.getFormModel().getKeyBlock().setId(getGlobal("VALUE"));
			getTask().getGoqrpls().gCheckFailure();
			nextItem();
		}
	}
	
		
	/*@ActionTrigger(action="WHEN-BUTTON-PRESSED", item="ID")
	public void id_action_buttonPressed()
	{
		System.out.println("KeyBlockController.id_action_buttonPressed()");
		getTask().getGoqrpls().gKeyOptMenu(toStr("KEY_BLOCK.ID"), 
				GNls.Fget(toStr("TZAMONF-0050"), toStr("FORM"), toStr("Person Search (SOAIDEN)")), toStr("LIST_VALUES"),
				GNls.Fget(toStr("TZAMONF-0051"), toStr("FORM"), toStr("Non-Person Search (SOACOMP)")), toStr("COUNT_QUERY"),
				toStr(""), toStr(""), toStr(""), toStr(""));
		getTask().getGoqrpls().gCheckFailure();
			
	}
	
	@ActionTrigger(action="KEY-LISTVAL", item="ID", function=KeyFunction.LIST_VALUES)
	public void id_KeyAction_list_values()
	{
		System.out.println("KeyBlockController.id_KeyAction_list_values()");
			getTask().getGoqrpls().gCopyFldAttr();
			executeAction("G$_REVOKE_ACCESS");
			getTask().getGoqrpls().gCheckFailure();
			getTask().getGoqrpls().gSecuredFormCall(getGlobal("CURRENT_USER"), toStr("SOAIDEN"), toStr("QUERY"));
			getTask().getGoqrpls().gResetGlobal();
			// 
			if ( !getGlobal("VALUE").isNull() )
			{
				executeAction("LIST_VALUES_COPY");
				getTask().getGoqrpls().gCheckFailure();
				nextItem();
			}
	}
	
	@ActionTrigger(action="KEY-CQUERY", item="ID", function=KeyFunction.COUNT_QUERY)
	public void id_KeyAction_count_query()
	{
		System.out.println("KeyBlockController.id_KeyAction_count_query()");
			executeAction("G$_REVOKE_ACCESS");
			getTask().getGoqrpls().gCheckFailure();
			getTask().getGoqrpls().gSecuredFormCall(getGlobal("CURRENT_USER"), toStr("SOACOMP"), toStr("QUERY"));
			// 
			if ( !getGlobal("VALUE").isNull() )
			{
				executeAction("LIST_VALUES_COPY");
				getTask().getGoqrpls().gCheckFailure();
				nextItem();
			}
	}
	
	@ActionTrigger(action="WHEN-BUTTON-PRESSED", item="ID")
	public void id_action_buttonPressed() {
		goBlock(DataConstant.KEYBLOCK_LABEL);
		
		this.getTask().getGoqrpls().gKeyOptMenu(toStr(DataConstant.ITEM_ID_LABEL), 
				GNls.Fget(toStr(DataConstant.SOAIDEN_OPTION_LABEL), toStr(DataConstant.FORM_LABEL), toStr(DataConstant.MENU_OPTION_SOAIDEN)), toStr(DataConstant.EVENT_LIST_VALUES),
				GNls.Fget(toStr(DataConstant.SOACOMP_OPTION_LABEL), toStr(DataConstant.FORM_LABEL), toStr(DataConstant.MENU_OPTION_SOACOMP)), toStr(DataConstant.EVENT_COUNT_QUERY),
				GNls.Fget(toStr(DataConstant.GUIALTI_OPTION_LABEL), toStr(DataConstant.FORM_LABEL), toStr(DataConstant.MENU_OPTION_GUIALTI)), toStr(DataConstant.EVENT_DUPLICATED_ITEM), toStr(""), toStr(""));
		this.getTask().getGoqrpls().gCheckFailure();
	}

	@ActionTrigger(action="KEY_LISTVAL", item = "ID", function = KeyFunction.LIST_VALUES)
	public void id_KeyAction_list_values() {
		this.getTask().getGoqrpls().gCopyFldAttr();
		executeAction(DataConstant.ACTION_REVOKE_ACCESS);
		this.getTask().getGoqrpls().gSecuredFormCall(getGlobal(DataConstant.CURRENT_USER_LABEL), toStr(DataConstant.SOAIDEN_LABEL), toStr(DataConstant.QUERY_LABEL));
		this.getTask().getGoqrpls().gResetGlobal();
		
		if (getGlobal(DataConstant.VALUE_LABEL).isNotNull()) {
			this.getFormModel().getKeyBlock().setId(getGlobal(DataConstant.VALUE_LABEL));
			nextItem();
		}
	}

	@ActionTrigger(action="KEY-CQUERY", item = "ID", function = KeyFunction.COUNT_QUERY)
	public void id_KeyAction_count_query() {
		executeAction(DataConstant.ACTION_REVOKE_ACCESS);
		getTask().getGoqrpls().gSecuredFormCall(getGlobal(DataConstant.CURRENT_USER_LABEL), toStr(DataConstant.SOACOMP_LABEL), toStr(DataConstant.QUERY_LABEL));
		
		if (getGlobal(DataConstant.VALUE_LABEL).isNotNull())
		{
			this.getFormModel().getKeyBlock().setId(getGlobal(DataConstant.VALUE_LABEL));
			nextItem();
		}
	}

	@ActionTrigger(action="KEY-DUP-ITEM", item = "ID", function = KeyFunction.DUPLICATE_ITEM)
	public void id_KeyAction_duplicate_item() {
		executeAction(DataConstant.ACTION_REVOKE_ACCESS);
		getTask().getGoqrpls().gSecuredFormCall(getGlobal(DataConstant.CURRENT_USER_LABEL), toStr(DataConstant.GUIALTI_LABEL), toStr(DataConstant.QUERY_LABEL));
		getTask().getGoqrpls().gResetGlobal();
		
		if (getGlobal(DataConstant.VALUE_LABEL).isNotNull())
		{
			this.getFormModel().getKeyBlock().setId(getGlobal(DataConstant.VALUE_LABEL));
			nextItem();
		}
	}*/

	@ValidationTrigger(item = "DATE_FROM")
	public void date_from_validation() {
		NDate dateFrom = this.getFormModel().getKeyBlock().getDateFrom();
		NDate dateTo = this.getFormModel().getKeyBlock().getDateTo();
		
		if (dateFrom.isNotNull() && dateTo.isNotNull() && dateFrom.greater(dateTo)) {
			errorMessage(GNls.Fget(toStr(DataConstant.FIRST_MESSAGE_LABEL), toStr(DataConstant.FORM_LABEL), toStr(DataConstant.MESSAGE_INVALID_DATE)));
			goItem(DataConstant.ITEM_DATE_FROM_LABEL);
			throw new ApplicationException();
		}
	}

	@ValidationTrigger(item = "DATE_TO")
	public void date_to_validation() {
		NDate dateFrom = this.getFormModel().getKeyBlock().getDateFrom();
		NDate dateTo = this.getFormModel().getKeyBlock().getDateTo();
		
		if (dateFrom.isNotNull() && dateTo.isNotNull() && dateFrom.greater(dateTo)) {
			errorMessage(GNls.Fget(toStr(DataConstant.FIRST_MESSAGE_LABEL), toStr(DataConstant.FORM_LABEL), toStr(DataConstant.MESSAGE_INVALID_DATE)));
			goItem(DataConstant.ITEM_DATE_TO_LABEL);
			throw new ApplicationException();
		}
	}

	@ValidationTrigger(item = "SHIPPING_STATUS")
	public void shipping_status_validation() {
		NString description = NString.getNull();
		
		if (this.getFormModel().getKeyBlock().getShippingStatus().isNotNull()) {
			NBool exists = this.getTask().getServices().existsShippingStatus(this.getFormModel().getKeyBlock().getShippingStatus());
			
			if (exists.isFalse()) {
				this.getFormModel().getKeyBlock().setShippingStatusDescription(description);
				errorMessage(GNls.Fget(toStr(DataConstant.SECOND_MESSAGE_LABEL), toStr(DataConstant.FORM_LABEL), toStr(DataConstant.MESSAGE_SHIPPING_STATUS_INVALID)));
				goItem(DataConstant.ITEM_SHIPPING_STATUS);
				throw new ApplicationException();
			}
			
			description = this.getTask().getServices().getShippingStatusDescription(this.getFormModel().getKeyBlock().getShippingStatus());
		}
		
		this.getFormModel().getKeyBlock().setShippingStatusDescription(description);
	}
	
	@ValidationTrigger(item = "ID")
	public void id_validation() {
		if (this.getFormModel().getKeyBlock().getId().isNotNull()) {
			NBool isValidId = this.getTask().getServices().existsIdOnSpriden(this.getFormModel().getKeyBlock().getId());
			NString name = NString.getNull();
			
			if (isValidId.isFalse()) {
				this.getFormModel().getKeyBlock().setIdDescription(name);
				
				errorMessage(GNls.Fget(toStr(DataConstant.THIRD_MESSAGE_LABEL), toStr(DataConstant.FORM_LABEL), toStr(DataConstant.MESSAGE_ID_INVALID)));
				goItem(DataConstant.ITEM_ID_LABEL);
				throw new ApplicationException();
			}
			
			name = this.getTask().getServices().getName(this.getFormModel().getKeyBlock().getId());
			this.getFormModel().getKeyBlock().setIdDescription(name);
		} else {
			this.getFormModel().getKeyBlock().setIdDescription(NString.getNull());
		}
	}

	@ActionTrigger(item = "SHIPPING_STATUS", function = KeyFunction.LIST_VALUES)
	public void shipping_status_KeyAction_list_values() {
		listValues();
		nextItem();
	}

	@ActionTrigger(item = "PROCESS_CODE", function = KeyFunction.LIST_VALUES)
	public void process_code_KeyAction_list_values() {
		listValues();
		nextItem();
	}

	@ValidationTrigger(item = "PROCESS_CODE")
	public void process_code_validation() {
		this.getFormModel().getKeyBlock().setProcessDescription(NString.getNull());
		
		if (this.getFormModel().getKeyBlock().getProcessCode().isNotNull()) {
			NBool exists = this.getTask().getServices().existsProcess(this.getFormModel().getKeyBlock().getProcessCode());
			
			if (exists.isFalse()) {				
				errorMessage(GNls.Fget(toStr(DataConstant.FOURTH_MESSAGE_LABEL), toStr(DataConstant.FORM_LABEL), toStr(DataConstant.MESSAGE_PROCESS_INVALID)));
				goItem(DataConstant.ITEM_PROCESS_CODE);
				throw new ApplicationException();
			}
			
			NString processDescription = this.getTask().getServices().getProcessDescription(this.getFormModel().getKeyBlock().getProcessCode());
			this.getFormModel().getKeyBlock().setProcessDescription(processDescription);
		}
	}

	@ValidationTrigger(item = "ID_PROCESS")
	public void id_process_validation() {
		if(this.getFormModel().getKeyBlock().getIdProcess().isNotNull()) {
			NBool isValid = this.getTask().getServices().isNumeric(this.getFormModel().getKeyBlock().getIdProcess());
			
			if (isValid.isFalse()) {
				errorMessage(GNls.Fget(toStr(DataConstant.SIXTH_MESSAGE_LABEL), toStr(DataConstant.FORM_LABEL), toStr(DataConstant.MESSAGE_PROCESS_ID_INVALID)));
				goItem(DataConstant.ITEM_PROCESS_ID);
				throw new ApplicationException();
			}
		}
	}

	/*@ActionTrigger(item = "ID", function = KeyFunction.LIST_VALUES)
	public void id_KeyAction_list_values() {
		listValues();
		nextItem();
	}*/
}