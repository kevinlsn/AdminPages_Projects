package net.hedtech.banner.arsys.Tzamonf.services;

import morphis.foundations.core.appdatalayer.data.DataCursor;
import morphis.foundations.core.appdatalayer.data.DbManager;
import morphis.foundations.core.appdatalayer.data.IDataCommand;
import morphis.foundations.core.appdatalayer.data.ResultSet;
import morphis.foundations.core.appsupportlib.runtime.ISupportCodeContainer;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.common.forms.baseForm.services.DefaultSupportCodeObject;
import net.hedtech.banner.arsys.Tzamonf.model.DataConstant;
import net.hedtech.banner.arsys.Tzamonf.TzamonfTask;
import net.hedtech.banner.arsys.Tzamonf.model.TzamonfModel;

public class TzamonfServices extends DefaultSupportCodeObject {

	public TzamonfServices(ISupportCodeContainer container) {
		super(container);
	}

	public TzamonfTask getTask() {
		return (TzamonfTask) super.getContainer();
	}

	public TzamonfModel getFormModel() {
		return getTask().getModel();
	}
	
	public NBool isNumeric(NString data) {
		return NBool.toBool(data.toString().matches(DataConstant.REGEX_NUMERIC));
	}

	public NString getName (NString id) {
		NString name = NString.getNull();
		DataCursor cursor = new DataCursor(DataConstant.QUERY_GET_NAME);
			
		try {
			cursor.addParameter(DataConstant.SPRIDEN_ID_LABEL, id);
			cursor.open();
			ResultSet result = cursor.fetchInto();
				
			if (result != null) {
				name = result.getStr(0);
			}
		} catch (Exception e) {
			if(e != null) {
				System.out.println(e.getLocalizedMessage());
			}	
		} finally {
			if (cursor.isOpen()) {
				cursor.close();
				cursor.dispose();
			}
		}	
		
		return name;
	}
	
	public NNumber getPidm (NString id) {
		NNumber pidm = NNumber.getNull();
		DataCursor cursor = new DataCursor(DataConstant.QUERY_GET_PIDM);
			
		try {
			cursor.addParameter(DataConstant.SPRIDEN_ID_LABEL, id);
			cursor.open();
			ResultSet result = cursor.fetchInto();
				
			if (result != null) {
				pidm = result.getNumber(0);
			}
		} catch (Exception e) {
			if(e != null) {
				System.out.println(e.getLocalizedMessage());
			}	
		} finally {
			if (cursor.isOpen()) {
				cursor.close();
				cursor.dispose();
			}
		}	
		
		return pidm;
	}
	
	public NBool existsIdOnSpriden (NString id) {
		NNumber counter = NNumber.toNumber(0);
		DataCursor cursor = new DataCursor(DataConstant.QUERY_ID_EXISTS_SPRIDEN);
			
		try {
			cursor.addParameter(DataConstant.SPRIDEN_ID_LABEL, id);
			cursor.open();
			ResultSet result = cursor.fetchInto();
				
			if (result != null) {
				counter = result.getNumber(0);
			}
		} catch (Exception e) {
			if(e != null) {
				System.out.println(e.getLocalizedMessage());
			}	
		} finally {
			if (cursor.isOpen()) {
				cursor.close();
				cursor.dispose();
			}
		}
		
		return NBool.toBool(counter.greater(NNumber.toNumber(0)));
	}
	
	public NBool existsShippingStatus (NString code) {
		NNumber counter = NNumber.toNumber(0);
		DataCursor cursor = new DataCursor(DataConstant.QUERY_SHIPPING_STATUS_EXISTS);
			
		try {
			cursor.addParameter(DataConstant.SHIPPING_STATUS_LABEL, code);
			cursor.open();
			ResultSet result = cursor.fetchInto();
				
			if (result != null) {
				counter = result.getNumber(0);
			}
		} catch (Exception e) {
			if(e != null) {
				System.out.println(e.getLocalizedMessage());
			}	
		} finally {
			if (cursor.isOpen()) {
				cursor.close();
				cursor.dispose();
			}
		}
		
		return NBool.toBool(counter.greater(NNumber.toNumber(0)));
	}
	
	public NString getShippingStatusDescription (NString code) {
		NString description = NString.getNull();
		DataCursor cursor = new DataCursor(DataConstant.QUERY_GET_SHIPPING_STATUS_DESC);
			
		try {
			cursor.addParameter(DataConstant.SHIPPING_STATUS_LABEL, code);
			cursor.open();
			ResultSet result = cursor.fetchInto();
				
			if (result != null) {
				description = result.getStr(0);
			}
		} catch (Exception e) {
			if(e != null) {
				System.out.println(e.getLocalizedMessage());
			}	
		} finally {
			if (cursor.isOpen()) {
				cursor.close();
				cursor.dispose();
			}
		}
		
		return description;
	}
	
	public NBool existsProcess (NString code) {
		NNumber counter = NNumber.toNumber(0);
		DataCursor cursor = new DataCursor(DataConstant.QUERY_PROCESS_EXISTS);
			
		try {
			cursor.addParameter(DataConstant.PROCESS_CODE_LABEL, code);
			cursor.open();
			ResultSet result = cursor.fetchInto();
				
			if (result != null) {
				counter = result.getNumber(0);
			}
		} catch (Exception e) {
			if(e != null) {
				System.out.println(e.getLocalizedMessage());
			}	
		} finally {
			if (cursor.isOpen()) {
				cursor.close();
				cursor.dispose();
			}
		}
		
		return NBool.toBool(counter.greater(NNumber.toNumber(0)));
	}
	
	public NString getProcessDescription (NString code) {
		NString description = NString.getNull();
		DataCursor cursor = new DataCursor(DataConstant.QUERY_GET_PROCESS_DESC);
			
		try {
			cursor.addParameter(DataConstant.PROCESS_CODE_LABEL, code);
			cursor.open();
			ResultSet result = cursor.fetchInto();
				
			if (result != null) {
				description = result.getStr(0);
			}
		} catch (Exception e) {
			if(e != null) {
				System.out.println(e.getLocalizedMessage());
			}	
		} finally {
			if (cursor.isOpen()) {
				cursor.close();
				cursor.dispose();
			}
		}
		
		return description;
	}
	
	public NString getfacStatus (NNumber pidm, NNumber transaction) {
		NString status = NString.getNull();
		
		try {
			IDataCommand cmd = DbManager.getDataAccessFactory().createDataCommand(DataConstant.FUNCTION_GET_FAC_STATUS, DbManager.getDataBaseFactory());
			cmd.addParameter(DataConstant.PARAM_PIDM_LABEL, pidm);
			cmd.addParameter(DataConstant.PARAM_NUMBER_TRANSACTION_LABEL, transaction);
			cmd.addReturnParameter(NString.class);
			cmd.execute();
			
			status = cmd.getReturnValue(NString.class);
		} catch (Exception e) {
			if(e != null) {
				System.out.println(e.getLocalizedMessage());
			}	
		}
		
		return status;
	}
}