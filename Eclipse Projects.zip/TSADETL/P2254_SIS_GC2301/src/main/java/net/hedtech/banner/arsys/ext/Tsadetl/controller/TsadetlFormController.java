package net.hedtech.banner.arsys.ext.Tsadetl.controller;

import morphis.foundations.core.appsupportlib.exceptions.ApplicationException;
import morphis.foundations.core.appsupportlib.runtime.ITask;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.util.globals.Globals.setGlobal;
import net.hedtech.banner.arsys.ext.Tsadetl.TsadetlTask;
import net.hedtech.banner.arsys.ext.Tsadetl.model.TsadetlModel;
import net.hedtech.general.common.dbservices.GNls;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.types.NString;
import morphis.core.utils.behavior.annotations.After;
import morphis.core.utils.behavior.annotations.Replace;

public class TsadetlFormController extends net.hedtech.banner.arsys.Tsadetl.controller.TsadetlFormController {

	public TsadetlFormController(ITask task) {
		super(task);
	}

	@Override
	public TsadetlTask getTask() {
		return (TsadetlTask) super.getTask();
	}

	public TsadetlModel getFormModel() {
		return getTask().getModel();
	}

	@After
	@ActionTrigger(action = "LOAD_CURRENT_RELEASE")
	public void Tsadetl_LoadCurrentRelease_replace_after() {
		this.getFormModel().getFormHeader().setModId(NString.toStr("SIS GDC 1.0.4"));
	}
	
	@Replace
	@ActionTrigger(action="RUN_TGRAPPL")
	public void Tsadetl_RunTgrappl_replace()
	{
		
			nextItem();
			previousItem();
			getTask().getGoqrpls().gCheckFailure();
			if ( getCursorBlock().equals("KEY_BLOCK") )
			{
				if ( getFormModel().getKeyBlock().getId().isNull() )
				{
					getFormModel().getKeyBlock().setRwname(toStr(""));
					errorMessage(GNls.Fget(toStr("TSADETL-0029"), toStr("FORM"), toStr("ID must be entered before using Apply Transactions.")));
					throw new ApplicationException();
				}
			}
			if ( getBlockStatus().equals("CHANGED") )
			{
				errorMessage(GNls.Fget(toStr("TSADETL-0030"), toStr("FORM"), toStr("Select SAVE to perform a Commit before using Apply Transactions.")));
				throw new ApplicationException();
			}
			setGlobal("CALL_FORM", toStr("TSADETL"));
			setGlobal("ID_NO", getFormModel().getKeyBlock().getId());
			setGlobal("SUBMIT_TIME", toStr(""));
			this.getTask().getServices().tRunTzrappl(getFormModel().getKeyBlock().getId());
			//this.getTask().getToqrpls().tRunTgrappl(getFormModel().getKeyBlock().getId());
			if ( getCursorBlock().notEquals("TBRACCD") )
			{
				goBlock(toStr("TBRACCD"));
			}
			executeQuery();
		}

	@After
	@ActionTrigger(action="RUN_TGRAPPL")
	public void Tsadetl_RunTgrappl_after()
	{
		executeQuery("TBRACCD");
		executeAction("CALC_BALANCES");
			
	}
}