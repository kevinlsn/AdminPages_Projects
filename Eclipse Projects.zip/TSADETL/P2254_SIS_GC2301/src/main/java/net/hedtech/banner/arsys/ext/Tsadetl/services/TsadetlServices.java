package net.hedtech.banner.arsys.ext.Tsadetl.services;

import morphis.foundations.core.appsupportlib.runtime.ISupportCodeContainer;
import morphis.foundations.core.appsupportlib.runtime.MessageServices;
import morphis.foundations.core.types.NBool;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.flavors.forms.appsupportlib.runtime.FormsMessageLevel;

import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.util.globals.Globals.setGlobal;

import morphis.foundations.core.appdatalayer.data.DataCommand;
import morphis.foundations.core.appdatalayer.data.DataCursor;
import morphis.foundations.core.appdatalayer.data.ResultSet;
import net.hedtech.banner.arsys.ext.Tsadetl.TsadetlTask;
import net.hedtech.banner.arsys.ext.Tsadetl.model.TsadetlModel;
import net.hedtech.general.common.dbservices.GNls;

public class TsadetlServices extends net.hedtech.banner.arsys.Tsadetl.services.TsadetlServices {

	public TsadetlServices(ISupportCodeContainer container) {
		super(container);
	}

	public TsadetlTask getTask() {
		return (TsadetlTask) super.getContainer();
	}

	public TsadetlModel getFormModel() {
		return getTask().getModel();
	}   
	
	
	
	
	
	public void tRunTzrappl(NString holdId)
	{
		int rowCount = 0;
		NNumber oneUpNo= NNumber.getNull();
		NString jobTypeInd= NString.getNull();
		NString prunTimeStamp= NString.getNull();
		NString hold2RefPriorInd = toStr("Y");
		NString hold3ChgPriorInd = toStr("Y");
		NString hold4ContExpCredInd = toStr("C");
		NString hold5TivFirstInd = toStr("N");
		NString hold6AidFutureInd = toStr("Y");
		NString hold7NonaidCrFutureInd = toStr("Y");
		NString hold8OrderChgTermInd = toStr("1");
		NString hold9PrintRoster = toStr("N");
		String sqlcursor1 = "SELECT GJBPSEQ.NEXTVAL " +
" FROM DUAL ";
		DataCursor cursor1 = new DataCursor(sqlcursor1);
		String sqlcursor2 = "SELECT GJBJOBS_JOB_TYPE_IND " +
" FROM GJBJOBS " +
" WHERE GJBJOBS_NAME = 'TZRAPPL' ";
		DataCursor cursor2 = new DataCursor(sqlcursor2);
		try {
			// COPY(NAME_IN('GLOBAL.ID_NO'),'HOLD_ID');
			//   message('in T$_RUN_TGRAPPL ' || HOLD_ID,acknowledge);
			//F2J_WARNING : Make sure that the method "Close" is being called over the variable cursor1.
			cursor1.open();
			ResultSet cursor1Results = cursor1.fetchInto();
			if ( cursor1Results != null ) {
				oneUpNo = cursor1Results.getNumber(0);
			}
			getTask().getGoqrpls().gCheckValue(cursor1.notFound(), toStr(null), toBool(NBool.True));
			//F2J_WARNING : Make sure that the method "Close" is being called over the variable cursor2.
			cursor2.open();
			ResultSet cursor2Results = cursor2.fetchInto();
			if ( cursor2Results != null ) {
				jobTypeInd = cursor2Results.getStr(0);
			}
			getTask().getGoqrpls().gCheckValue(cursor1.notFound(), toStr(null), toBool(NBool.True));
			// INSERT INTO GJBPRUN
			// (GJBPRUN_JOB,
			// GJBPRUN_ONE_UP_NO,
			// GJBPRUN_NUMBER,
			// GJBPRUN_ACTIVITY_DATE,
			// GJBPRUN_VALUE)
			// SELECT
			// GJBPDEF_JOB,
			// ONE_UP_NO,
			// GJBPDEF_NUMBER,
			// SYSDATE,
			// DECODE(GJBPDEF_NUMBER, 1, HOLD_ID,
			// 2, HOLD2_REF_PRIOR_IND,
			// 3, HOLD3_CHG_PRIOR_IND,
			// 4, HOLD4_CONT_EXP_CRED_IND,
			// 5, HOLD5_TIV_FIRST_IND,
			// 6, HOLD6_AID_FUTURE_IND,
			// 7, HOLD7_NONAID_CR_FUTURE_IND,
			// 8, HOLD8_ORDER_CHG_TERM_IND,
			// 9, HOLD9_PRINT_ROSTER,
			// '')
			// FROM GJBPDEF
			// WHERE GJBPDEF_JOB = 'TGRAPPL';
			String sql1 = "INSERT INTO GJBPRUN " +
"(GJBPRUN_JOB, GJBPRUN_ONE_UP_NO, GJBPRUN_NUMBER, GJBPRUN_ACTIVITY_DATE, GJBPRUN_VALUE)" +
"SELECT GJBPDEF_JOB, :P_ONE_UP_NO, GJBPDEF_NUMBER, SYSDATE, DECODE(GJBPDEF_NUMBER, 1, :P_HOLD_ID, 2, NVL(A.GJBPDFT_VALUE, NVL(B.GJBPDFT_VALUE, 'Y')), 3, NVL(A.GJBPDFT_VALUE, NVL(B.GJBPDFT_VALUE, 'Y')), 4, NVL(A.GJBPDFT_VALUE, NVL(B.GJBPDFT_VALUE, 'C')), 5, NVL(A.GJBPDFT_VALUE, NVL(B.GJBPDFT_VALUE, 'N')), 6, NVL(A.GJBPDFT_VALUE, NVL(B.GJBPDFT_VALUE, 'Y')), 7, NVL(A.GJBPDFT_VALUE, NVL(B.GJBPDFT_VALUE, 'Y')), 8, NVL(A.GJBPDFT_VALUE, NVL(B.GJBPDFT_VALUE, '1')), 9, 'N', '') " +
" FROM GJBPDFT A, GJBPDFT B, GJBPDEF " +
" WHERE GJBPDEF_JOB = 'TZRAPPL' AND A.GJBPDFT_JOB(+) = GJBPDEF_JOB AND A.GJBPDFT_JPRM_CODE(+) IS NULL AND A.GJBPDFT_NUMBER(+) = GJBPDEF_NUMBER AND A.GJBPDFT_USER_ID(+) = USER AND B.GJBPDFT_JOB(+) = GJBPDEF_JOB AND B.GJBPDFT_JPRM_CODE(+) IS NULL AND B.GJBPDFT_NUMBER(+) = GJBPDEF_NUMBER AND B.GJBPDFT_USER_ID(+) IS NULL ";
			DataCommand command1 = new DataCommand(sql1);
			//Setting query parameters
			command1.addParameter("P_ONE_UP_NO", oneUpNo);
			command1.addParameter("P_HOLD_ID", holdId);
			rowCount = command1.execute();
			getTask().getGoqrpls().gCheckValue(rowCount == 0, GNls.Fget(toStr("TOQRPLS-0020"), toStr("LIB"), toStr("*ERROR* Could not insert parameters for Application of Payment.")), toBool(NBool.True));
			// F2J_WARNING : Please validate if you need to surround the message level manipulation with a try/finally block
			MessageServices.setMessageLevel(FormsMessageLevel.decodeMessageLevel("5"));
			commitTask();
			//  EXECUTE_TRIGGER('GET_PRUN_TIME_STAMP');
			prunTimeStamp = toChar(NDate.getNow(), "MMDDYYYYHH24MISS");
			copy(GNls.Fget(toStr("TOQRPLS-0022"), toStr("LIB"), toStr("**Performing Application of Payment process, please wait**")),"GLOBAL.CALL_DISPLAY_MSG");
			
			setGlobal("CALL_FORM","GJAPCTL");
			setGlobal("PRNT_CODE","DATABASE");
			setGlobal("DISPLAY_SUBMIT_IND","S");
			setGlobal("SUBMIT_TIME","");
			
			copy("tzrappl","GLOBAL.JOB_ID");
			copy(jobTypeInd,"GLOBAL.JOB_TYPE_IND");
			copy(prunTimeStamp,"GLOBAL.TIME_STAMP");
			copy(toChar(oneUpNo),"GLOBAL.ONE_UP_NO");
			// F2J_WARNING : Please validate if you need to surround the message level manipulation with a try/finally block
			MessageServices.setMessageLevel(FormsMessageLevel.decodeMessageLevel("0"));
			copy("Y","GLOBAL.WAIT_UNTIL_DONE");
			// F2J_WARNING : Please validate if you need to surround the message level manipulation with a try/finally block
			MessageServices.setMessageLevel(FormsMessageLevel.decodeMessageLevel("5"));
			executeAction("G$_REVOKE_ACCESS");
			getTask().getGoqrpls().gCheckFailure();
			// message('before call  ' || HOLD_ID,acknowledge);
			getTask().getGoqrpls().gSecuredFormCall(getNameIn("GLOBAL.CURRENT_USER"), toStr("GUQINTF"), toStr(""));
			// F2J_WARNING : Please validate if you need to surround the message level manipulation with a try/finally block
			MessageServices.setMessageLevel(FormsMessageLevel.decodeMessageLevel("0"));
			getTask().getGoqrpls().gCheckFailure();
			}finally{
				cursor1.close();
				cursor2.close();
			}
	}

}