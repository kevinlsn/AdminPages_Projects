package net.hedtech.banner.arsys.ext.Tsaarev;

import java.util.Hashtable;
import net.hedtech.general.common.forms.BaseTask;
import morphis.foundations.core.appsupportlib.runtime.Task;

public class TsaarevTask extends net.hedtech.banner.arsys.Tsaarev.TsaarevTask {
	public TsaarevTask(String taskName) {
		super(taskName);
	}
	
	public TsaarevTask(String taskName, Hashtable sharedLibraries, Hashtable parameters) {
		super(taskName, sharedLibraries, parameters);
	}
	
	@Override
	public net.hedtech.banner.arsys.ext.Tsaarev.model.TsaarevModel getModel() {
		return (net.hedtech.banner.arsys.ext.Tsaarev.model.TsaarevModel)super.getModel();
	}
	
	public net.hedtech.banner.arsys.ext.Tsaarev.services.TsaarevServices getServices() {
		return (net.hedtech.banner.arsys.ext.Tsaarev.services.TsaarevServices)getSupportCodeManager().getServices();
	}
	
	// Attached Libraries
    public net.hedtech.general.common.libraries.Goqrpls.GoqrplsServices getGoqrpls()
    {
		return (net.hedtech.general.common.libraries.Goqrpls.GoqrplsServices)getSupportCodeManager().getLibrary("GOQRPLS");
    }
	
}
