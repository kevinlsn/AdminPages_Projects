package net.hedtech.banner.arsys.ext.Tsaarev.model;

import morphis.foundations.core.appsupportlib.model.SimpleBusinessObject;
import morphis.foundations.core.appsupportlib.model.configuration.SimpleBusinessObjectConfiguration;
import morphis.foundations.core.types.*;
import static morphis.foundations.core.types.Types.*;

public class FormHeader extends net.hedtech.banner.arsys.Tsaarev.model.FormHeader {

	public FormHeader() {
		super();
	}

	public FormHeader(SimpleBusinessObjectConfiguration configuration, String name) {
		super(configuration, name);
	}

	public NString getModId() {
		return toStr(super.getValue("MOD_ID"));
	}

	public void setModId(NString value) {
		super.setValue("MOD_ID", value);
	}

	

	
	
}