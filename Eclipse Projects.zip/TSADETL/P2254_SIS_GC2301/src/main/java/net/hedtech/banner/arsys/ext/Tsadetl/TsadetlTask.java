package net.hedtech.banner.arsys.ext.Tsadetl;

import java.util.Hashtable;

public class TsadetlTask extends net.hedtech.banner.arsys.Tsadetl.TsadetlTask {
	public TsadetlTask(String taskName) {
		super(taskName);
	}
	
	public TsadetlTask(String taskName, Hashtable sharedLibraries, Hashtable parameters) {
		super(taskName, sharedLibraries, parameters);
	}
	
	@Override
	public net.hedtech.banner.arsys.ext.Tsadetl.model.TsadetlModel getModel() {
		return (net.hedtech.banner.arsys.ext.Tsadetl.model.TsadetlModel)super.getModel();
	}
	
	public net.hedtech.banner.arsys.ext.Tsadetl.services.TsadetlServices getServices() {
		return (net.hedtech.banner.arsys.ext.Tsadetl.services.TsadetlServices)getSupportCodeManager().getServices();
	}
	
	// Attached Libraries
    public net.hedtech.general.common.libraries.Goqrpls.GoqrplsServices getGoqrpls()
    {
		return (net.hedtech.general.common.libraries.Goqrpls.GoqrplsServices)getSupportCodeManager().getLibrary("GOQRPLS");
    }
	
}
