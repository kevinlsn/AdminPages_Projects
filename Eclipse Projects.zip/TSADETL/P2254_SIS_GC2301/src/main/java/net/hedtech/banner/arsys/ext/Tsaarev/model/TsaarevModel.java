package net.hedtech.banner.arsys.ext.Tsaarev.model;

import java.util.Hashtable;
import morphis.foundations.core.appsupportlib.model.*;
import morphis.foundations.core.appsupportlib.runtime.*;

import net.hedtech.general.common.libraries.Goqolib.model.*;
import net.hedtech.general.common.libraries.Toqolib.model.*;

public class TsaarevModel extends net.hedtech.banner.arsys.Tsaarev.model.TsaarevModel {
	
	public TsaarevModel(ITask task, Hashtable parameters) {
		super(task, parameters);
	}

	public FormHeader getFormHeader() {
		return (FormHeader) getBusinessObject("FORM_HEADER");
	}
	
}