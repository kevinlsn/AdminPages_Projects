package net.hedtech.banner.arsys.itesm.arsys.Tzampse.model;

import morphis.foundations.core.appsupportlib.model.SimpleBusinessObject;
import morphis.foundations.core.appsupportlib.model.configuration.SimpleBusinessObjectConfiguration;
import morphis.foundations.core.types.*;
import static morphis.foundations.core.types.Types.*;

public class KeyBlock extends morphis.foundations.flavors.forms.appsupportlib.model.SimpleBusinessObject {

	public KeyBlock() {
		super();
	}

	public KeyBlock(SimpleBusinessObjectConfiguration configuration, String name) {
		super(configuration, name);
	}
	
	public NString getStvtermCode() {
		return toStr(super.getValue("STVTERM_CODE"));
	}
	
	public void setStvtermCode(NString value) {
		super.setValue("STVTERM_CODE", value);
	}

	public NString getStvtermDesc() {
		return toStr(super.getValue("STVTERM_DESC"));
	}
	
	public void setStvtermDesc(NString value) {
		super.setValue("STVTERM_DESC", value);
	}

	public NString getStvlevlCode() {
		return toStr(super.getValue("STVLEVL_CODE"));
	}
	
	public void setStvlevlCode(NString value) {
		super.setValue("STVLEVL_CODE", value);
	}

	public NString getStvlevlDesc() {
		return toStr(super.getValue("STVLEVL_DESC"));
	}
	
	public void setStvlevlDesc(NString value) {
		super.setValue("STVLEVL_DESC", value);
	}

	

	

	

	

	

	
}