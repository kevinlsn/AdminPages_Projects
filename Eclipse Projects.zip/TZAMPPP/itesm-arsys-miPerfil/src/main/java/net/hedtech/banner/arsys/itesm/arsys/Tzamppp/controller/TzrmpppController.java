package net.hedtech.banner.arsys.itesm.arsys.Tzamppp.controller;

import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.util.globals.Globals.setGlobal;
import static net.hedtech.general.common.forms.services.BaseTaskServices.executeAction;

import org.apache.bcel.generic.IFNULL;

import net.hedtech.general.common.forms.controller.DefaultBlockController;
import net.hedtech.banner.arsys.itesm.arsys.Tzamppp.TzampppTask;
import morphis.foundations.core.appsupportlib.runtime.action.*;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.util.Ref;

import static morphis.foundations.core.types.Types.*;
import morphis.core.utils.behavior.annotations.*;
import morphis.foundations.core.appdatalayer.data.*;
import morphis.foundations.core.appsupportlib.exceptions.ApplicationException;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import net.hedtech.general.common.dbservices.GNls;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.nextBlock;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.errorMessage;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.runtime.*;
import net.hedtech.banner.arsys.itesm.arsys.Tzamppp.model.*;
import morphis.foundations.core.appdatalayer.events.BeforeQuery;
import morphis.foundations.core.appdatalayer.events.QueryEvent;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appdatalayer.events.BeforeRowInsert;
import morphis.foundations.core.appdatalayer.events.BeforeRowUpdate;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;

public class TzrmpppController extends DefaultBlockController {

	public TzrmpppController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public TzampppTask getTask() {
		return (TzampppTask) super.getTask();
	}

	public TzampppModel getFormModel() {
		return getTask().getModel();
	}

	@After
	@ActionTrigger(action="PRE-BLOCK", function=KeyFunction.BLOCK_IN)
	public void tzrmppp_blockIn()
	{
		//TODO to be filled by the user
	}

	@BeforeQuery
	public void tzrmppp_BeforeQuery(QueryEvent queryEvent) {
		((IDBBusinessObject) queryEvent.getSource()).getSelectCommandParams().add(DbManager.getDataBaseFactory()
				.createDataParameter("TERM_CODE", this.getFormModel().getKeyBlock().getStvtermCode()));
		//KLSN 03/11/23 START
		((IDBBusinessObject) queryEvent.getSource()).getSelectCommandParams().add(DbManager.getDataBaseFactory()
				.createDataParameter("LEVL_CODE", this.getFormModel().getKeyBlock().getTzrmpppLevlCode()));
		//KLSN 03/11/23 END
	}

	@BeforeRowInsert
	public void tzrmppp_BeforeRowInsert(RowAdapterEvent rowAdapterEvent) {
		defaultValues();
	}

	@BeforeRowUpdate
	public void tzrmppp_BeforeRowUpdate(RowAdapterEvent rowAdapterEvent) {
		defaultValues();
		
	}
	
	private void defaultValues() {
		TzrmpppAdapter adapter =(TzrmpppAdapter)getFormModel().getTzrmppp().getRowAdapter(true);
		if (adapter == null) {
			return;
		}
		
		adapter.setTzrmpppActivityDate(NDate.getNow());
		adapter.setTzrmpppCreateUserId(getGlobal("CURRENT_USER"));
		adapter.setTzrmpppTermCode(this.getFormModel().getKeyBlock().getStvtermCode());
		//KLSN 09-11-23 START
		adapter.setTzrmpppLevlCode(this.getFormModel().getKeyBlock().getTzrmpppLevlCode());
		//KLSN 09-11-23 END
		adapter.setTzrmpppDataOrigin(toStr("TZAMPPP"));
		
		if (NString.isNullOrEmpty(adapter.getTzrmpppPayPlanType())) {
			adapter.setTzrmpppPayPlanType(toStr("D"));
		}
		
		if (NString.isNullOrEmpty(adapter.getTzrmpppSelectStatus())) {
			adapter.setTzrmpppSelectStatus(toStr("0"));
		}
		
		if (NString.isNullOrEmpty(adapter.getTzrmpppDefault())) {
			adapter.setTzrmpppDefault(toStr("N"));
		}
	}
	
	@ActionTrigger(function = KeyFunction.NEXT_BLOCK)
	public void tzrmppp_KeyAction_next_block() {
		MessageServices.errorMessage(GNls.Fget(NString.toStr("TZAMPPP-002"), NString.toStr("FORM"),
				NString.toStr("**ERROR** Invalid function.")));
		throw new ApplicationException();
	}

	@ActionTrigger(item = "TZRMPPP_INSTALLMENT_PLAN", function = KeyFunction.LIST_VALUES)
	public void tzrmppp_installment_plan_KeyAction_list_values() {		
		executeAction("G$_REVOKE_ACCESS");
		getTask().getGoqrpls().gCheckFailure();
		setGlobal("FORM_WAS_CALLED", toStr("Y"));
		getTask().getGoqrpls().gSecuredFormCall(getGlobal("CURRENT_USER"), toStr("TSAISTC"), toStr("QUERY"));
		
		if (!getGlobal("VALUE").isNull()) {
			TzrmpppAdapter adapter =(TzrmpppAdapter)getFormModel().getTzrmppp().getRowAdapter(true);
			if (adapter == null) {
				return;
			}
			Ref<NNumber> n_paymts = new Ref<NNumber>(NNumber.getNull());
			NString desc= this.getTask().getServices().getTbbistcDesc(getGlobal("VALUE"),n_paymts);
			if (!NString.isNullOrEmpty(desc)) {
				adapter.setTzrmpppInstallmentPlan(getGlobal("VALUE"));
				adapter.setTzrmpppPayPlanDesc(desc);
				adapter.setTzrmpppNumberOfPayments(n_paymts.val);
			}else {
				adapter.setTzrmpppInstallmentPlan(NString.getNull());
				adapter.setTzrmpppPayPlanDesc(NString.getNull());
				adapter.setTzrmpppNumberOfPayments(NNumber.getNull());
			}
			
		}
		setGlobal("FORM_WAS_CALLED", toStr(""));
		setGlobal("VALUE","");
		
	}

	@ActionTrigger(function = KeyFunction.DELETE_RECORD)
	public void tzrmppp_KeyAction_delete_record() {
		
		TzrmpppAdapter adapter =(TzrmpppAdapter)getFormModel().getTzrmppp().getRowAdapter(true);
		if (adapter == null) {
			return;
		}
		
		if (this.getTask().getServices().countExistsTzrmpps(adapter.getTzrmpppInstallmentPlan(), adapter.getTzrmpppTermCode())) {
			
			MessageServices.errorMessage(GNls.Fget(NString.toStr("TZAMPPP-001"), NString.toStr("FORM"),
					NString.toStr("**Error** Cannot delete record. Child record exists on TZAMPPS.")));
			throw new ApplicationException();
			
		}
		else {
			deleteRecord();
		}
	}

	@ValidationTrigger(item = "TZRMPPP_INSTALLMENT_PLAN")
	public void tzrmppp_installment_plan_validation() {
		TzrmpppAdapter adapter =(TzrmpppAdapter)getFormModel().getTzrmppp().getRowAdapter(true);
		if (adapter == null) {
			return;
		}
		Ref<NNumber> n_paymts = new Ref<NNumber>(NNumber.getNull());
		NString desc= this.getTask().getServices().getTbbistcDesc(adapter.getTzrmpppInstallmentPlan(),n_paymts);
		if (!NString.isNullOrEmpty(desc)) {			
			adapter.setTzrmpppPayPlanDesc(desc);
			adapter.setTzrmpppNumberOfPayments(n_paymts.val);
		}else {
			adapter.setTzrmpppInstallmentPlan(NString.getNull());
			adapter.setTzrmpppPayPlanDesc(NString.getNull());
			adapter.setTzrmpppNumberOfPayments(NNumber.getNull());
		}
		
	}

	// KLSN 08-11-23 START
	@ActionTrigger(item = "TZRMPPP_LEVL_CODE", function = KeyFunction.LIST_VALUES)
	public void tzrmppp_levl_code_KeyAction_list_values() {
		//TaskServices.listValues();
		
		setGlobal("VALUE","");
		TaskServices.listValues();
		if ( !getGlobal("VALUE").isNull() )
		{
			TzrmpppAdapter adapter = (TzrmpppAdapter)getFormModel().getTzrmppp().getRowAdapter(true);
 
			if(adapter == null){
				return;
			}	
			adapter.setTzrmpppLevlCode(getGlobal("VALUE"));
			setGlobal("VALUE","");
			getTask().getGoqrpls().gCheckFailure();
			//nextItem();
		
		}	
	}
	
	// KLSN 08-11-23 END
	
	
}