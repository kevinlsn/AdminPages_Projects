package net.hedtech.banner.arsys.itesm.arsys.Tzampse.controller;

import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.util.globals.Globals.setGlobal;
import static net.hedtech.general.common.forms.services.BaseTaskServices.executeAction;

import net.hedtech.general.common.forms.controller.DefaultBlockController;
import net.hedtech.banner.arsys.itesm.arsys.Tzampse.TzampseTask;
import net.hedtech.banner.arsys.itesm.arsys.Tzampse.model.TzampseModel;
import morphis.foundations.core.appsupportlib.runtime.action.*;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import morphis.foundations.core.types.NDate;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.util.Ref;

import static morphis.foundations.core.types.Types.*;
import morphis.core.utils.behavior.annotations.*;
import morphis.foundations.core.appdatalayer.data.*;
import morphis.foundations.core.appsupportlib.exceptions.ApplicationException;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import net.hedtech.general.common.dbservices.GNls;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.nextBlock;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.errorMessage;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.runtime.*;
import net.hedtech.banner.arsys.itesm.arsys.Tzampse.model.*;
import morphis.foundations.core.appdatalayer.events.BeforeQuery;
import morphis.foundations.core.appdatalayer.events.QueryEvent;
import morphis.foundations.core.appdatalayer.events.RowAdapterEvent;
import morphis.foundations.core.appdatalayer.events.BeforeRowInsert;
import morphis.foundations.core.appdatalayer.events.BeforeRowUpdate;
import morphis.foundations.core.appsupportlib.runtime.action.ValidationTrigger;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;

public class TzrmpseController extends DefaultBlockController {

	public TzrmpseController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public TzampseTask getTask() {
		return (TzampseTask) super.getTask();
	}

	public TzampseModel getFormModel() {
		return getTask().getModel();
	}

	@After
	@ActionTrigger(action="PRE-BLOCK", function=KeyFunction.BLOCK_IN)
	public void tzrmpse_blockIn()
	{
		//TODO to be filled by the user
	}

	@BeforeQuery
	public void tzrmpse_BeforeQuery(QueryEvent queryEvent) {
		((IDBBusinessObject) queryEvent.getSource()).getSelectCommandParams().add(DbManager.getDataBaseFactory()
				.createDataParameter("TERM_CODE", this.getFormModel().getKeyBlock().getStvtermCode()));

		((IDBBusinessObject) queryEvent.getSource()).getSelectCommandParams().add(DbManager.getDataBaseFactory()
				.createDataParameter("LEVL_CODE", this.getFormModel().getKeyBlock().getStvlevlCode()));
	}

	@BeforeRowInsert
	public void tzrmpse_BeforeRowInsert(RowAdapterEvent rowAdapterEvent) {	
		initDefaults();
	}

	@BeforeRowUpdate
	public void tzrmpse_BeforeRowUpdate(RowAdapterEvent rowAdapterEvent) {
		initDefaults();
	}
	
	private void initDefaults() {
		TzrmpseAdapter adapter= (TzrmpseAdapter)getFormModel().getTzrmpse().getRowAdapter(true);
		if (adapter == null) {
			return;
		}
		
		adapter.setTzrmpseDataOrigin(toStr("TZAMPSE"));
		adapter.setTzrmpseActivityDate(NDate.getNow());
		adapter.setTzrmpseCreateUserId(getGlobal("CURRENT_USER"));
		adapter.setTzrmpseTermCode(getFormModel().getKeyBlock().getStvtermCode());
		adapter.setTzrmpseLevlCode(getFormModel().getKeyBlock().getStvlevlCode());
		
		if (NString.isNullOrEmpty(adapter.getTzrmpseObligatorio())) {
			adapter.setTzrmpseObligatorio(toStr("N"));
		}
		
	}

	@ValidationTrigger(item = "TZRMPSE_ATTS_CODE")
	public void tzrmpse_atts_code_validation() {
		TzrmpseAdapter adapter= (TzrmpseAdapter)getFormModel().getTzrmpse().getRowAdapter(true);
		if (adapter == null) {
			return;
		}
		if (!NString.isNullOrEmpty(adapter.getTzrmpseAttsCode())) {		
			if (NString.isNullOrEmpty(this.getTask().getServices().getStvattsDesc(adapter.getTzrmpseAttsCode()))) {
				adapter.setTzrmpseAttsCode(NString.getNull());
			}
		}
	}

	@ActionTrigger(function = KeyFunction.NEXT_BLOCK)
	public void tzrmpse_KeyAction_next_block() {
		MessageServices.errorMessage(GNls.Fget(NString.toStr("TZAMPSE-001"), NString.toStr("FORM"),
				NString.toStr("**ERROR** Invalid function.")));
		throw new ApplicationException();
	}

	@ActionTrigger(item = "TZRMPSE_DETAIL_CODE", function = KeyFunction.LIST_VALUES)
	public void tzrmpse_detail_code_KeyAction_list_values() {
		executeAction("G$_REVOKE_ACCESS");
		getTask().getGoqrpls().gCheckFailure();
		setGlobal("FORM_WAS_CALLED", toStr("Y"));
		getTask().getGoqrpls().gSecuredFormCall(getGlobal("CURRENT_USER"), toStr("TSADETC"), toStr("QUERY"));
		
		if (!getGlobal("VALUE").isNull()) {
			TzrmpseAdapter adapter =(TzrmpseAdapter)getFormModel().getTzrmpse().getRowAdapter(true);
			if (adapter == null) {
				return;
			}
			
			adapter.setTzrmpseDetailCode(getGlobal("VALUE"));
		}
		
		setGlobal("FORM_WAS_CALLED", toStr(""));
		setGlobal("VALUE","");
	}

	@ActionTrigger(item = "TZRMPSE_ATTS_CODE", function = KeyFunction.LIST_VALUES)
	public void tzrmpse_atts_code_KeyAction_list_values() {
		TzrmpseAdapter adapter =(TzrmpseAdapter)getFormModel().getTzrmpse().getRowAdapter(true);
		if (adapter == null) {
			return;
		}
		setGlobal("VALUE","");
		listValues();
		
		if (!getGlobal("VALUE").isNull()) {
			adapter.setTzrmpseAttsCode(getGlobal("VALUE"));
		}
		setGlobal("VALUE","");
	}

	@ValidationTrigger(item = "TZRMPSE_DETAIL_CODE")
	public void tzrmpse_detail_code_validation() {
		
		TzrmpseAdapter adapter =(TzrmpseAdapter)getFormModel().getTzrmpse().getRowAdapter(true);
		if (adapter == null) {
			return;
		}
		
		if (!this.getTask().getServices().validarTsadetc(adapter.getTzrmpseDetailCode())) {
			adapter.setTzrmpseDetailCode(NString.getNull());
		}
		
	}
}