package net.hedtech.banner.arsys.itesm.arsys.Tzampse.model;

import java.util.Date;
import java.math.BigDecimal;
import org.jdesktop.databuffer.DataRow;
//import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.types.*;
import morphis.foundations.core.appsupportlib.model.*;
import morphis.foundations.flavors.forms.appdatalayer.data.BaseRowAdapter;

public class TzrmpseAdapter extends BaseRowAdapter {

	public TzrmpseAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NString getTzrmpseTermCode() {
		NString v = new NString((String)this.getValue("TZRMPSE_TERM_CODE"));
		return v;
	}
	
	public void setTzrmpseTermCode(NString value) {
		this.setValue("TZRMPSE_TERM_CODE", value.getValue());
	}

	public NString getTzrmpseLevlCode() {
		NString v = new NString((String)this.getValue("TZRMPSE_LEVL_CODE"));
		return v;
	}
	
	public void setTzrmpseLevlCode(NString value) {
		this.setValue("TZRMPSE_LEVL_CODE", value.getValue());
	}

	public NString getTzrmpseDetailCode() {
		NString v = new NString((String)this.getValue("TZRMPSE_DETAIL_CODE"));
		return v;
	}
	
	public void setTzrmpseDetailCode(NString value) {
		this.setValue("TZRMPSE_DETAIL_CODE", value.getValue());
	}

	public NString getTzrmpseAttsCode() {
		NString v = new NString((String)this.getValue("TZRMPSE_ATTS_CODE"));
		return v;
	}
	
	public void setTzrmpseAttsCode(NString value) {
		this.setValue("TZRMPSE_ATTS_CODE", value.getValue());
	}

	public NString getTzrmpseObligatorio() {
		NString v = new NString((String)this.getValue("TZRMPSE_OBLIGATORIO"));
		return v;
	}
	
	public void setTzrmpseObligatorio(NString value) {
		this.setValue("TZRMPSE_OBLIGATORIO", value.getValue());
	}

	public NString getTzrmpseDefault() {
		NString v = new NString((String)this.getValue("TZRMPSE_DEFAULT"));
		return v;
	}
	
	public void setTzrmpseDefault(NString value) {
		this.setValue("TZRMPSE_DEFAULT", value.getValue());
	}

	public NNumber getTzrmpseEstatus() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TZRMPSE_ESTATUS"));
		return v;
	}
	
	public void setTzrmpseEstatus(NNumber value) {
		this.setValue("TZRMPSE_ESTATUS", value.getValue());
	}

	public NString getTzrmpseDataOrigin() {
		NString v = new NString((String)this.getValue("TZRMPSE_DATA_ORIGIN"));
		return v;
	}
	
	public void setTzrmpseDataOrigin(NString value) {
		this.setValue("TZRMPSE_DATA_ORIGIN", value.getValue());
	}

	public NString getTzrmpseCreateUserId() {
		NString v = new NString((String)this.getValue("TZRMPSE_CREATE_USER_ID"));
		return v;
	}
	
	public void setTzrmpseCreateUserId(NString value) {
		this.setValue("TZRMPSE_CREATE_USER_ID", value.getValue());
	}

	public NDate getTzrmpseActivityDate() {
		NDate v = new NDate((java.util.Date)this.getValue("TZRMPSE_ACTIVITY_DATE"));
		return v;
	}
	
	public void setTzrmpseActivityDate(NDate value) {
		this.setValue("TZRMPSE_ACTIVITY_DATE", value.getValue());
	}

}