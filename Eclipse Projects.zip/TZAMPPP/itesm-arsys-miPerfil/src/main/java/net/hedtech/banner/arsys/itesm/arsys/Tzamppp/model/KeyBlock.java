package net.hedtech.banner.arsys.itesm.arsys.Tzamppp.model;

import morphis.foundations.core.appsupportlib.model.SimpleBusinessObject;
import morphis.foundations.core.appsupportlib.model.configuration.SimpleBusinessObjectConfiguration;
import morphis.foundations.core.types.*;
import static morphis.foundations.core.types.Types.*;

public class KeyBlock extends morphis.foundations.flavors.forms.appsupportlib.model.SimpleBusinessObject {

	public KeyBlock() {
		super();
	}

	public KeyBlock(SimpleBusinessObjectConfiguration configuration, String name) {
		super(configuration, name);
	}
	
	public NString getStvtermCode() {
		return toStr(super.getValue("STVTERM_CODE"));
	}
	
	public void setStvtermCode(NString value) {
		super.setValue("STVTERM_CODE", value);
	}

	public NString getStvtermDesc() {
		return toStr(super.getValue("STVTERM_DESC"));
	}
	
	public void setStvtermDesc(NString value) {
		super.setValue("STVTERM_DESC", value);
	}

	//KLSN 03/11/23 START
	
	public NString getTzrmpppLevlCode() {
		return toStr(super.getValue("TZRMPPP_LEVL_CODE")); 
	}

	public void setTzrmpppLevlCode(NString value) {
		super.setValue("TZRMPPP_LEVL_CODE", value); 
	}

	public NString getTzrmpppLevlDesc() {
		return toStr(super.getValue("TZRMPPP_LEVL_DESC"));
	}

	public void setTzrmpppLevlDesc(NString value) {
		super.setValue("TZRMPPP_LEVL_DESC", value);
	}
	
	//KLSN 03/11/23 END
}