package net.hedtech.banner.arsys.itesm.arsys.Tzamppp.services;

import morphis.foundations.core.appdatalayer.data.DataCursor;
import morphis.foundations.core.appdatalayer.data.ResultSet;
import morphis.foundations.core.appsupportlib.runtime.ISupportCodeContainer;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.util.Ref;

import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.util.globals.Globals.setGlobal;
import morphis.common.forms.baseForm.services.DefaultSupportCodeObject;
import net.hedtech.banner.arsys.itesm.arsys.Tzamppp.TzampppTask;
import net.hedtech.banner.arsys.itesm.arsys.Tzamppp.model.TzampppModel;

public class TzampppServices extends DefaultSupportCodeObject {

	public TzampppServices(ISupportCodeContainer container) {
		super(container);
	}

	public TzampppTask getTask() {
		return (TzampppTask) super.getContainer();
	}

	public TzampppModel getFormModel() {
		return getTask().getModel();
	}
	
	// TODO: put your services here
	
	public NString getStvtermDesc(NString term_code) {

		String ret = "";

		{
			String sqlptiCursor = "select stvterm_desc from stvterm "
					+ "	where stvterm_code=:code ";
			DataCursor ptiCursor = new DataCursor(sqlptiCursor);
			try {
				// Setting query parameters
				ptiCursor.addParameter("code", term_code);

				// F2J_WARNING : Make sure that the method "Close" is being called over the
				// variable ptiCursor.
				ptiCursor.open();
				ResultSet ptiCursorResults = ptiCursor.fetchInto();
				if (ptiCursorResults != null) {
					ret = ptiCursorResults.getString(0);
					ptiCursor.close();
					
					return toStr(ret);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				ptiCursor.close();
			}

		}

		return toStr(ret);
	}
	
	//KLSN 03/11/23 START
	
	public NString getStvlevlDesc(NString levl_code) {

		String ret = "";

		{
			String sqlptiCursor = "select stvterm_desc from stvterm "
					+ "	where stvterm_code=:code ";
			DataCursor ptiCursor = new DataCursor(sqlptiCursor);
			try {
				// Setting query parameters
				ptiCursor.addParameter("code", levl_code);

				// F2J_WARNING : Make sure that the method "Close" is being called over the
				// variable ptiCursor.
				ptiCursor.open();
				ResultSet ptiCursorResults = ptiCursor.fetchInto();
				if (ptiCursorResults != null) {
					ret = ptiCursorResults.getString(0);
					ptiCursor.close();
					
					return toStr(ret);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				ptiCursor.close();
			}

		}

		return toStr(ret);
	}
	
	//KLSN 03/11/23 END

	public NString getTbbistcDesc(NString inst_code, Ref<NNumber> out_num_paymts) {

		String ret = "";

		{
			String sqlptiCursor = "select TBBISTC_DESC,TBBISTC_NUMBER_OF_PAYMENTS from "
					+ "				TBBISTC where TBBISTC_INSTALLMENT_PLAN=:code ";
			DataCursor ptiCursor = new DataCursor(sqlptiCursor);
			try {
				// Setting query parameters
				ptiCursor.addParameter("code", inst_code);

				// F2J_WARNING : Make sure that the method "Close" is being called over the
				// variable ptiCursor.
				ptiCursor.open();
				ResultSet ptiCursorResults = ptiCursor.fetchInto();
				if (ptiCursorResults != null) {
					ret = ptiCursorResults.getString(0);
					out_num_paymts.val=NNumber.toNumber(ptiCursorResults.getInt32(1));
					ptiCursor.close();
					
					return toStr(ret);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				ptiCursor.close();
			}

		}

		return toStr(ret);
	}

	

	public boolean countExistsTzrmpps(NString inst_code, NString term_code) {

		NNumber ret = NNumber.getNull();

		{
			String sqlptiCursor = "select count(1) from TZRMPPS where TZRMPPS_TERM_CODE=:term_code"
					+ " and  TZRMPPS_INSTALLMENT_PLAN=:plan_code ";
			DataCursor ptiCursor = new DataCursor(sqlptiCursor);
			try {
				// Setting query parameters
				ptiCursor.addParameter("term_code", term_code);
				ptiCursor.addParameter("plan_code", inst_code);

				// F2J_WARNING : Make sure that the method "Close" is being called over the
				// variable ptiCursor.
				ptiCursor.open();
				ResultSet ptiCursorResults = ptiCursor.fetchInto();
				if (ptiCursorResults != null) {
					ret = NNumber.toNumber(ptiCursorResults.getInt32(0));
					ptiCursor.close();
										
				}
			} catch (Exception e) {
				ret=toNumber(0);
				e.printStackTrace();
			} finally {
				ptiCursor.close();
			}

		}

		return ret.greater(0)?true:false;
	}
	
}