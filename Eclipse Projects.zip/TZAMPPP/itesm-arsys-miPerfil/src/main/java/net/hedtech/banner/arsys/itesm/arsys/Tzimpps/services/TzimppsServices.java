package net.hedtech.banner.arsys.itesm.arsys.Tzimpps.services;

import morphis.foundations.core.appdatalayer.data.DataCursor;
import morphis.foundations.core.appdatalayer.data.ResultSet;
import morphis.foundations.core.appsupportlib.runtime.ISupportCodeContainer;
import morphis.foundations.core.types.NString;

import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.util.globals.Globals.setGlobal;
import morphis.common.forms.baseForm.services.DefaultSupportCodeObject;
import net.hedtech.banner.arsys.itesm.arsys.Tzimpps.TzimppsTask;
import net.hedtech.banner.arsys.itesm.arsys.Tzimpps.model.TzimppsModel;

public class TzimppsServices extends DefaultSupportCodeObject {

	public TzimppsServices(ISupportCodeContainer container) {
		super(container);
	}

	public TzimppsTask getTask() {
		return (TzimppsTask) super.getContainer();
	}

	public TzimppsModel getFormModel() {
		return getTask().getModel();
	}

	// TODO: put your services here
	public NString getStvtermDesc(NString term_code) {

		String ret = "";

		{
			String sqlptiCursor = "select stvterm_desc from stvterm "
					+ "	where stvterm_code=:code ";
			DataCursor ptiCursor = new DataCursor(sqlptiCursor);
			try {
				// Setting query parameters
				ptiCursor.addParameter("code", term_code);

				// F2J_WARNING : Make sure that the method "Close" is being called over the
				// variable ptiCursor.
				ptiCursor.open();
				ResultSet ptiCursorResults = ptiCursor.fetchInto();
				if (ptiCursorResults != null) {
					ret = ptiCursorResults.getString(0);
					ptiCursor.close();
					
					return toStr(ret);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				ptiCursor.close();
			}

		}

		return toStr(ret);
	}
}