package net.hedtech.banner.arsys.itesm.arsys.Tzimpps.controller;

import morphis.foundations.core.appsupportlib.exceptions.ApplicationException;
import morphis.foundations.core.appsupportlib.model.IDBBusinessObject;
import morphis.foundations.core.appsupportlib.runtime.MessageServices;
import morphis.foundations.core.appsupportlib.runtime.action.ActionTrigger;
import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import morphis.foundations.core.types.NString;

import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.util.globals.Globals.setGlobal;

import net.hedtech.general.common.dbservices.GNls;
import net.hedtech.general.common.forms.controller.DefaultBlockController;
import net.hedtech.banner.arsys.itesm.arsys.Tzimpps.TzimppsTask;
import net.hedtech.banner.arsys.itesm.arsys.Tzimpps.model.TzimppsModel;
import morphis.foundations.core.appdatalayer.data.DbManager;
import morphis.foundations.core.appdatalayer.events.BeforeQuery;
import morphis.foundations.core.appdatalayer.events.QueryEvent;

public class TzimppsDataController extends DefaultBlockController {

	public TzimppsDataController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public TzimppsTask getTask() {
		return (TzimppsTask) super.getTask();
	}

	public TzimppsModel getFormModel() {
		return getTask().getModel();
	}

	@BeforeQuery
	public void tzimpps_data_BeforeQuery(QueryEvent queryEvent) {
		((IDBBusinessObject) queryEvent.getSource()).getSelectCommandParams().add(DbManager.getDataBaseFactory()
				.createDataParameter("term_code", this.getFormModel().getKeyBlock().getStvtermCode()));

		((IDBBusinessObject) queryEvent.getSource()).getSelectCommandParams().add(DbManager.getDataBaseFactory()
				.createDataParameter("p_pidm", this.getFormModel().getKeyBlock().getPidm()));

	}
	
	@ActionTrigger(function = KeyFunction.NEXT_BLOCK)
	public void tzimpps_KeyAction_next_block() {
		MessageServices.errorMessage(GNls.Fget(NString.toStr("TZIMPPS-001"), NString.toStr("FORM"),
				NString.toStr("**ERROR** Invalid function.")));
		throw new ApplicationException();
	}
	
}