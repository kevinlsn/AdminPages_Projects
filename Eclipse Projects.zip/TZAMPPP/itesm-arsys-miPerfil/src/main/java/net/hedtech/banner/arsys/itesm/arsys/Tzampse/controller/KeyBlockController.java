package net.hedtech.banner.arsys.itesm.arsys.Tzampse.controller;

import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.util.globals.Globals.setGlobal;
import net.hedtech.general.common.forms.controller.DefaultBlockController;
import net.hedtech.banner.arsys.itesm.arsys.Tzampse.TzampseTask;
import net.hedtech.banner.arsys.itesm.arsys.Tzampse.model.TzampseModel;
import morphis.foundations.core.appsupportlib.runtime.action.*;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import morphis.foundations.core.types.NString;

import static morphis.foundations.core.types.Types.*;
import morphis.core.utils.behavior.annotations.*;
import morphis.foundations.core.appdatalayer.data.*;
import morphis.foundations.core.appsupportlib.exceptions.ApplicationException;
import net.hedtech.general.common.dbservices.GNls;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.nextBlock;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.errorMessage;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.runtime.*;

public class KeyBlockController extends DefaultBlockController {

	public KeyBlockController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public TzampseTask getTask() {
		return (TzampseTask) super.getTask();
	}

	public TzampseModel getFormModel() {
		return getTask().getModel();
	}

	@ActionTrigger(action="KEY-NXTBLK", function=KeyFunction.NEXT_BLOCK)
	public void keyBlock_NextBlock()
	{
		nextBlock();
	}

	@ActionTrigger(action="POST-BLOCK", function=KeyFunction.BLOCK_OUT)
	public void keyBlock_blockOut()
	{
		getFormModel().getButtonControlBlock().setCheckKeys(toStr("Y"));
	}
	
	@ValidationTrigger(item = "STVTERM_CODE")
	public void term_code_validation() {
	
		if (!NString.isNullOrEmpty(this.getFormModel().getKeyBlock().getStvtermCode())) {
			this.getFormModel().getKeyBlock().setStvtermDesc(this.getTask().getServices().getStvtermDesc(this.getFormModel().getKeyBlock().getStvtermCode()));
		}
	}
	
	
	@ActionTrigger(item = "STVTERM_CODE", function = KeyFunction.LIST_VALUES)
	public void term_code_KeyAction_list_values() {
		setGlobal("VALUE","");
		TaskServices.listValues();
		
		if ( !getGlobal("VALUE").isNull() )
		{
			
			this.getFormModel().getKeyBlock().setStvtermCode(getGlobal("VALUE"));
			getTask().getGoqrpls().gCheckFailure();
			nextItem();
		}		
		setGlobal("VALUE","");
	}
	
	@ValidationTrigger(item = "STVLEVL_CODE")
	public void levl_code_validation() {
	
		if (!NString.isNullOrEmpty(this.getFormModel().getKeyBlock().getStvlevlCode())) {
			this.getFormModel().getKeyBlock().setStvlevlDesc(this.getTask().getServices().getStvlevlDesc(this.getFormModel().getKeyBlock().getStvlevlCode()));
		}
	}
	
	
	@ActionTrigger(item = "STVLEVL_CODE", function = KeyFunction.LIST_VALUES)
	public void levl_code_KeyAction_list_values() {
		setGlobal("VALUE","");
		TaskServices.listValues();
		
		if ( !getGlobal("VALUE").isNull() )
		{
			
			this.getFormModel().getKeyBlock().setStvlevlCode(getGlobal("VALUE"));
			getTask().getGoqrpls().gCheckFailure();
			nextItem();
		}		
		setGlobal("VALUE","");
	}
	
}