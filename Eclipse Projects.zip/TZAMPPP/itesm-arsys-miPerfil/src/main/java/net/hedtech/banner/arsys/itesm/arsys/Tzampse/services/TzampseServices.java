package net.hedtech.banner.arsys.itesm.arsys.Tzampse.services;

import morphis.foundations.core.appdatalayer.data.DataCursor;
import morphis.foundations.core.appdatalayer.data.ResultSet;
import morphis.foundations.core.appsupportlib.runtime.ISupportCodeContainer;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;

import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.types.Types.toNumber;
import static morphis.foundations.core.util.globals.Globals.setGlobal;
import morphis.common.forms.baseForm.services.DefaultSupportCodeObject;
import net.hedtech.banner.arsys.itesm.arsys.Tzampse.TzampseTask;
import net.hedtech.banner.arsys.itesm.arsys.Tzampse.model.TzampseModel;

public class TzampseServices extends DefaultSupportCodeObject {

	public TzampseServices(ISupportCodeContainer container) {
		super(container);
	}

	public TzampseTask getTask() {
		return (TzampseTask) super.getContainer();
	}

	public TzampseModel getFormModel() {
		return getTask().getModel();
	}

	// TODO: put your services here

	public NString getStvtermDesc(NString term_code) {

		String ret = "";

		{
			String sqlptiCursor = "select stvterm_desc from stvterm "
					+ "	where stvterm_code=:code ";
			DataCursor ptiCursor = new DataCursor(sqlptiCursor);
			try {
				// Setting query parameters
				ptiCursor.addParameter("code", term_code);

				// F2J_WARNING : Make sure that the method "Close" is being called over the
				// variable ptiCursor.
				ptiCursor.open();
				ResultSet ptiCursorResults = ptiCursor.fetchInto();
				if (ptiCursorResults != null) {
					ret = ptiCursorResults.getString(0);
					ptiCursor.close();
					
					return toStr(ret);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				ptiCursor.close();
			}

		}

		return toStr(ret);
	}
	
	public NString getStvlevlDesc(NString levl_code) {

		String ret = "";

		{
			String sqlptiCursor = "select stvlevl_desc from stvlevl "
					+ "	where stvlevl_code=:code ";
			DataCursor ptiCursor = new DataCursor(sqlptiCursor);
			try {
				// Setting query parameters
				ptiCursor.addParameter("code", levl_code);

				// F2J_WARNING : Make sure that the method "Close" is being called over the
				// variable ptiCursor.
				ptiCursor.open();
				ResultSet ptiCursorResults = ptiCursor.fetchInto();
				if (ptiCursorResults != null) {
					ret = ptiCursorResults.getString(0);
					ptiCursor.close();
					
					return toStr(ret);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				ptiCursor.close();
			}

		}

		return toStr(ret);
	}
	
	public NString getStvattsDesc(NString atts_code) {

		String ret = "";

		{
			String sqlptiCursor = "select stvatts_desc from stvatts "
					+ "	where stvatts_code=:code ";
			DataCursor ptiCursor = new DataCursor(sqlptiCursor);
			try {
				// Setting query parameters
				ptiCursor.addParameter("code", atts_code);

				// F2J_WARNING : Make sure that the method "Close" is being called over the
				// variable ptiCursor.
				ptiCursor.open();
				ResultSet ptiCursorResults = ptiCursor.fetchInto();
				if (ptiCursorResults != null) {
					ret = ptiCursorResults.getString(0);
					ptiCursor.close();
					
					return toStr(ret);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				ptiCursor.close();
			}

		}

		return toStr(ret);
	}
	

public NNumber validarPrimaryFaculties (NString p_term, NString p_crn) {
	
	NNumber ret = NNumber.toNumber(0);
	
	{
		String sqlptiCursor = "select COUNT(1) from TZRMPSE where TZRMPSE_TERM_CODE=:P_TERM " + 
				"  and  TZRMPSE_LEVL_CODE= :P_LEVL " + 
				"  and  TZRMPSE_DETAIL_CODE=:P_DETAIL'  "+
				"  and  TZRMPSE_ATTS_CODE=:P_ATTS'  ";
		
		DataCursor ptiCursor = new DataCursor(sqlptiCursor);
		try {
						
			ptiCursor.addParameter("P_TERM", p_term);
			ptiCursor.addParameter("P_CRN", p_crn);
			
			ptiCursor.open();
			ResultSet ptiCursorResults = ptiCursor.fetchInto();
			if (ptiCursorResults != null) {
				ret= toNumber(ptiCursorResults.getInt32(0));			
				ptiCursor.close();								
			}
		} catch (Exception e) {
			e.printStackTrace();			
			ptiCursor.close();
		} finally {			
			return ret;
		}

	}

}

//

public boolean validarTsadetc (NString p_code) {
	
	NNumber ret = NNumber.toNumber(0);
	
	{
		String sqlptiCursor = "select COUNT(1) from TBBDETC"
				+ " where TBBDETC_DETAIL_CODE=:code ";
		
		DataCursor ptiCursor = new DataCursor(sqlptiCursor);
		try {
						
			ptiCursor.addParameter("code", p_code);
						
			ptiCursor.open();
			ResultSet ptiCursorResults = ptiCursor.fetchInto();
			if (ptiCursorResults != null) {
				ret= toNumber(ptiCursorResults.getInt32(0));			
				ptiCursor.close();								
			}
		} catch (Exception e) {
			e.printStackTrace();			
			ptiCursor.close();
		} finally {			
			return ret.greater(0)?true:false;
		}

	}

}
	
}