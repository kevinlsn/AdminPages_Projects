package net.hedtech.banner.arsys.itesm.arsys.Tzimpps.model;

import java.util.Date;
import java.math.BigDecimal;
import org.jdesktop.databuffer.DataRow;
//import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.types.*;
import morphis.foundations.core.appsupportlib.model.*;
import morphis.foundations.flavors.forms.appdatalayer.data.BaseRowAdapter;

public class TzrmppsAdapter extends BaseRowAdapter {

	public TzrmppsAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NNumber getTzrmppsPidm() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TZRMPPS_PIDM"));
		return v;
	}
	
	public void setTzrmppsPidm(NNumber value) {
		this.setValue("TZRMPPS_PIDM", value.getValue());
	}

	public NString getTzrmppsInstallmentPlan() {
		NString v = new NString((String)this.getValue("TZRMPPS_INSTALLMENT_PLAN"));
		return v;
	}
	
	public void setTzrmppsInstallmentPlan(NString value) {
		this.setValue("TZRMPPS_INSTALLMENT_PLAN", value.getValue());
	}

	public NString getTzrmppsTermCode() {
		NString v = new NString((String)this.getValue("TZRMPPS_TERM_CODE"));
		return v;
	}
	
	public void setTzrmppsTermCode(NString value) {
		this.setValue("TZRMPPS_TERM_CODE", value.getValue());
	}

	public NString getTzrmppsPayPlanType() {
		NString v = new NString((String)this.getValue("TZRMPPS_PAY_PLAN_TYPE"));
		return v;
	}
	
	public void setTzrmppsPayPlanType(NString value) {
		this.setValue("TZRMPPS_PAY_PLAN_TYPE", value.getValue());
	}

	public NString getTzrmppsDataOrigin() {
		NString v = new NString((String)this.getValue("TZRMPPS_DATA_ORIGIN"));
		return v;
	}
	
	public void setTzrmppsDataOrigin(NString value) {
		this.setValue("TZRMPPS_DATA_ORIGIN", value.getValue());
	}

	public NString getTzrmppsCreateUserId() {
		NString v = new NString((String)this.getValue("TZRMPPS_CREATE_USER_ID"));
		return v;
	}
	
	public void setTzrmppsCreateUserId(NString value) {
		this.setValue("TZRMPPS_CREATE_USER_ID", value.getValue());
	}

	public NDate getTzrmppsActivityDate() {
		NDate v = new NDate((java.util.Date)this.getValue("TZRMPPS_ACTIVITY_DATE"));
		return v;
	}
	
	public void setTzrmppsActivityDate(NDate value) {
		this.setValue("TZRMPPS_ACTIVITY_DATE", value.getValue());
	}

}