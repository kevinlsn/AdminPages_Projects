package net.hedtech.banner.arsys.itesm.arsys.Tzamppp;

import java.util.Hashtable;
import net.hedtech.general.common.forms.BaseTask;

public class TzampppTask extends BaseTask {
	public TzampppTask(String taskName) {
		super(taskName);
	}
	
	public TzampppTask(String taskName, Hashtable sharedLibraries, Hashtable parameters) {
		super(taskName, sharedLibraries, parameters);
	}
	
	@Override
	public net.hedtech.banner.arsys.itesm.arsys.Tzamppp.model.TzampppModel getModel() {
		return (net.hedtech.banner.arsys.itesm.arsys.Tzamppp.model.TzampppModel)super.getModel();
	}
	
	public net.hedtech.banner.arsys.itesm.arsys.Tzamppp.services.TzampppServices getServices() {
		return (net.hedtech.banner.arsys.itesm.arsys.Tzamppp.services.TzampppServices)getSupportCodeManager().getServices();
	}
	
	// Attached Libraries
	
	public net.hedtech.general.common.libraries.Goqrpls.GoqrplsServices getGoqrpls() {
		return (net.hedtech.general.common.libraries.Goqrpls.GoqrplsServices)getSupportCodeManager().getLibrary("GOQRPLS");
	}
}
