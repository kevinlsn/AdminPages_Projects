package net.hedtech.banner.arsys.itesm.arsys.Tzampse;

import java.util.Hashtable;
import net.hedtech.general.common.forms.BaseTask;

public class TzampseTask extends BaseTask {
	public TzampseTask(String taskName) {
		super(taskName);
	}
	
	public TzampseTask(String taskName, Hashtable sharedLibraries, Hashtable parameters) {
		super(taskName, sharedLibraries, parameters);
	}
	
	@Override
	public net.hedtech.banner.arsys.itesm.arsys.Tzampse.model.TzampseModel getModel() {
		return (net.hedtech.banner.arsys.itesm.arsys.Tzampse.model.TzampseModel)super.getModel();
	}
	
	public net.hedtech.banner.arsys.itesm.arsys.Tzampse.services.TzampseServices getServices() {
		return (net.hedtech.banner.arsys.itesm.arsys.Tzampse.services.TzampseServices)getSupportCodeManager().getServices();
	}
	
	// Attached Libraries
	
	public net.hedtech.general.common.libraries.Goqrpls.GoqrplsServices getGoqrpls() {
		return (net.hedtech.general.common.libraries.Goqrpls.GoqrplsServices)getSupportCodeManager().getLibrary("GOQRPLS");
	}
}
