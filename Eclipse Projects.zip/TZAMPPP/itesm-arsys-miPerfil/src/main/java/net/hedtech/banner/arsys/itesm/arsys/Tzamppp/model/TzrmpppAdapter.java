package net.hedtech.banner.arsys.itesm.arsys.Tzamppp.model;

import java.util.Date;
import java.math.BigDecimal;
import org.jdesktop.databuffer.DataRow;
//import morphis.foundations.core.appdatalayer.data.BaseRowAdapter;
import morphis.foundations.core.types.*;
import morphis.foundations.core.appsupportlib.model.*;
import morphis.foundations.flavors.forms.appdatalayer.data.BaseRowAdapter;

public class TzrmpppAdapter extends BaseRowAdapter {

	public TzrmpppAdapter(DataRow row, IDBBusinessObject businessObject) {
		super(row, businessObject);
	}
	
	//Data Columns
	
	public NString getTzrmpppPayPlanType() {
		NString v = new NString((String)this.getValue("TZRMPPP_PAY_PLAN_TYPE"));
		return v;
	}
	
	public void setTzrmpppPayPlanType(NString value) {
		this.setValue("TZRMPPP_PAY_PLAN_TYPE", value.getValue());
	}

	public NString getTzrmpppInstallmentPlan() {
		NString v = new NString((String)this.getValue("TZRMPPP_INSTALLMENT_PLAN"));
		return v;
	}
	
	public void setTzrmpppInstallmentPlan(NString value) {
		this.setValue("TZRMPPP_INSTALLMENT_PLAN", value.getValue());
	}

	public NString getTzrmpppTermCode() {
		NString v = new NString((String)this.getValue("TZRMPPP_TERM_CODE"));
		return v;
	}
	
	public void setTzrmpppTermCode(NString value) {
		this.setValue("TZRMPPP_TERM_CODE", value.getValue());
	}

	public NString getTzrmpppPayPlanDesc() {
		NString v = new NString((String)this.getValue("TZRMPPP_PAY_PLAN_DESC"));
		return v;
	}
	
	public void setTzrmpppPayPlanDesc(NString value) {
		this.setValue("TZRMPPP_PAY_PLAN_DESC", value.getValue());
	}

	public NNumber getTzrmpppNumberOfPayments() {
		NNumber v = new NNumber((java.math.BigDecimal)this.getValue("TZRMPPP_NUMBER_OF_PAYMENTS"));
		return v;
	}
	
	public void setTzrmpppNumberOfPayments(NNumber value) {
		this.setValue("TZRMPPP_NUMBER_OF_PAYMENTS", value.getValue());
	}

	public NString getTzrmpppSelectStatus() {
		NString v = new NString((String)this.getValue("TZRMPPP_SELECT_STATUS"));
		return v;
	}
	
	public void setTzrmpppSelectStatus(NString value) {
		this.setValue("TZRMPPP_SELECT_STATUS", value.getValue());
	}

	public NString getTzrmpppDataOrigin() {
		NString v = new NString((String)this.getValue("TZRMPPP_DATA_ORIGIN"));
		return v;
	}
	
	public void setTzrmpppDataOrigin(NString value) {
		this.setValue("TZRMPPP_DATA_ORIGIN", value.getValue());
	}

	public NString getTzrmpppCreateUserId() {
		NString v = new NString((String)this.getValue("TZRMPPP_CREATE_USER_ID"));
		return v;
	}
	
	public void setTzrmpppCreateUserId(NString value) {
		this.setValue("TZRMPPP_CREATE_USER_ID", value.getValue());
	}

	public NDate getTzrmpppActivityDate() {
		NDate v = new NDate((java.util.Date)this.getValue("TZRMPPP_ACTIVITY_DATE"));
		return v;
	}
	
	public void setTzrmpppActivityDate(NDate value) {
		this.setValue("TZRMPPP_ACTIVITY_DATE", value.getValue());
	}

	public NString getTzrmpppDefault() {
		NString v = new NString((String) this.getValue("TZRMPPP_DEFAULT"));
		return v;
	}

	public void setTzrmpppDefault(NString value) {
		this.setValue("TZRMPPP_DEFAULT", value.getValue());
	}

	public NString getTzrmpppLevlCode() {
		NString v = new NString((String) this.getValue("TZRMPPP_LEVL_CODE"));
		return v;
	}

	public void setTzrmpppLevlCode(NString value) {
		this.setValue("TZRMPPP_LEVL_CODE", value.getValue());
	}

}