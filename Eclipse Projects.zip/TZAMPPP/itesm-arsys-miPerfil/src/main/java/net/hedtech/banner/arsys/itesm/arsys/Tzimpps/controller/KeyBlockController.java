package net.hedtech.banner.arsys.itesm.arsys.Tzimpps.controller;

import morphis.foundations.core.appsupportlib.runtime.control.IFormController;
import static morphis.foundations.core.appsupportlib.runtime.TaskServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ItemServices.*;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ViewServices.*;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ValueSetServices.*;
import static morphis.foundations.core.appsupportlib.runtime.LovServices.*;
import static morphis.foundations.core.appsupportlib.runtime.ListServices.*;
import static morphis.foundations.core.appsupportlib.runtime.TreeServices.*;
import static morphis.foundations.core.appsupportlib.Math.*;
import static morphis.foundations.core.appsupportlib.Lib.*;
import static morphis.foundations.core.appsupportlib.Globals.*;
import static morphis.foundations.core.types.Types.*;
import static morphis.foundations.core.util.globals.Globals.setGlobal;
import static net.hedtech.general.common.forms.services.BaseTaskServices.executeAction;

import net.hedtech.general.common.forms.controller.DefaultBlockController;
import net.hedtech.general.common.libraries.Goqolib.services.GIdClass;
import net.hedtech.general.common.libraries.Goqolib.services.GNameClass;
import net.hedtech.banner.arsys.itesm.arsys.Tzimpps.TzimppsTask;
import net.hedtech.banner.arsys.itesm.arsys.Tzimpps.model.TzimppsModel;
import morphis.foundations.core.appsupportlib.runtime.action.*;
import morphis.foundations.core.appsupportlib.ui.KeyFunction;
import morphis.foundations.core.types.NNumber;
import morphis.foundations.core.types.NString;
import morphis.foundations.core.util.Ref;

import static morphis.foundations.core.types.Types.*;
import morphis.core.utils.behavior.annotations.*;
import morphis.foundations.core.appdatalayer.data.*;
import morphis.foundations.core.appsupportlib.exceptions.ApplicationException;
import net.hedtech.general.common.dbservices.GNls;
import static morphis.foundations.core.appsupportlib.runtime.BlockServices.nextBlock;
import static morphis.foundations.core.appsupportlib.runtime.MessageServices.errorMessage;
import morphis.foundations.core.appsupportlib.Lib;
import morphis.foundations.core.appsupportlib.runtime.*;

public class KeyBlockController extends DefaultBlockController {

	public KeyBlockController(IFormController parentController, String name) {
		super(parentController, name);
	}

	@Override
	public TzimppsTask getTask() {
		return (TzimppsTask) super.getTask();
	}

	public TzimppsModel getFormModel() {
		return getTask().getModel();
	}

	private GIdClass getGIdClass() {
		return (net.hedtech.general.common.libraries.Goqolib.services.GIdClass) this.getTask().getTaskPart("GOQOLIB").getSupportCodeManager().getPackage("G$_ID_CLASS");
	}	
	private GNameClass getGNameClass() {
		return (net.hedtech.general.common.libraries.Goqolib.services.GNameClass) this.getTask().getTaskPart("GOQOLIB").getSupportCodeManager().getPackage("G$_NAME_CLASS");
	}
	
	@ActionTrigger(action="KEY-NXTBLK", function=KeyFunction.NEXT_BLOCK)
	public void keyBlock_NextBlock()
	{
		nextBlock();
	}

	@ActionTrigger(action="POST-BLOCK", function=KeyFunction.BLOCK_OUT)
	public void keyBlock_blockOut()
	{
		getFormModel().getButtonControlBlock().setCheckKeys(toStr("Y"));
	}
	@ValidationTrigger(item = "STVTERM_CODE")
	public void term_code_validation() {
	
		if (!NString.isNullOrEmpty(this.getFormModel().getKeyBlock().getStvtermCode())) {
			this.getFormModel().getKeyBlock().setStvtermDesc(this.getTask().getServices().getStvtermDesc(this.getFormModel().getKeyBlock().getStvtermCode()));
		}
	}
	
	
	@ActionTrigger(item = "STVTERM_CODE", function = KeyFunction.LIST_VALUES)
	public void term_code_KeyAction_list_values() {
		setGlobal("VALUE","");
		TaskServices.listValues();
		
		if ( !getGlobal("VALUE").isNull() )
		{
			
			this.getFormModel().getKeyBlock().setStvtermCode(getGlobal("VALUE"));
			getTask().getGoqrpls().gCheckFailure();
			nextItem();
		}		
		setGlobal("VALUE","");
	}
	
	
	@ActionTrigger(action="WHEN-BUTTON-PRESSED", item="ID_LBT")
	public void idLbt_buttonClick()
	{
		/* ItemServices.goItem("ID");
		id_ListValues(); */
		
		TaskServices.goBlock("KEY_BLOCK");
		getTask().getGoqrpls().gKeyOptMenu(toStr("KEY_BLOCK.ID"), 
			GNls.Fget(toStr("SPAPERS-0025"), toStr("FORM"), toStr("Person Search")), toStr("LIST_VALUES"), 
			GNls.Fget(toStr("SPAPERS-0027"), toStr("FORM"), toStr("Alternate ID Search")), toStr("DUPLICATE_ITEM"), 
			toStr(""), toStr(""),
			toStr(""), toStr("")
		);
				
		getTask().getGoqrpls().gCheckFailure();
		getFormModel().getButtonControlBlock().setCheckKeys(toStr("N"));
	}
	
	@ActionTrigger(action="PRE-TEXT-ITEM", item="ID", function=KeyFunction.ITEM_IN)
	public void id_itemIn()
	{
		
		getGIdClass().itemIn();
	}
	
	@ActionTrigger(action="POST-CHANGE", item="ID")
	public void id_PostChange()
	{
		
		getGIdClass().postChange();
	}

	

	@ActionTrigger(action="KEY-LISTVAL", item="ID", function=KeyFunction.LIST_VALUES)
	public void id_ListValues()
	{
		
			goItem(toStr("KEY_BLOCK.ID"));
			getTask().getGoqrpls().gCopyFldAttr();
			executeAction("G$_REVOKE_ACCESS");
			getTask().getGoqrpls().gCheckFailure();
			setGlobal("FORM_WAS_CALLED", toStr("Y"));
			getTask().getGoqrpls().gSecuredFormCall(getGlobal("CURRENT_USER"), toStr("SOAIDEN"), toStr("QUERY"));
			getTask().getGoqrpls().gResetGlobal();
			// 
			
			
			
			if ( !getGlobal("VALUE").isNull() )
			{
				//executeAction("LIST_VALUES_COPY");
				this.getFormModel().getKeyBlock().setId(getGlobal("VALUE"));
				getTask().getGoqrpls().gCheckFailure();
				nextItem();
			}
			// 
			setGlobal("FORM_WAS_CALLED", toStr(""));
			setGlobal("VALUE","");
		}
	
	@ActionTrigger(action="KEY-DUP-ITEM", item="ID", function=KeyFunction.DUPLICATE_ITEM)
	public void id_KeyDupItem()
	{
		
			getTask().getGoqrpls().gCopyFldAttr();
			executeAction("G$_REVOKE_ACCESS");
			getTask().getGoqrpls().gCheckFailure();
			getTask().getGoqrpls().gSecuredFormCall(getGlobal("CURRENT_USER"), toStr("GUIALTI"), toStr("QUERY"));
			getTask().getGoqrpls().gResetGlobal();
			// 
			if ( !getGlobal("VALUE").isNull() )
			{
				//executeAction("LIST_VALUES_COPY");
				this.getFormModel().getKeyBlock().setId(getGlobal("VALUE"));
				getTask().getGoqrpls().gCheckFailure();
				nextItem();
			}
			// 
			//  MW 01/13/2002 Added following CHECK_KEYS lines of code
			// for the SSN/SID Alternate ID Search changes. 
			getFormModel().getButtonControlBlock().setCheckKeys(toStr("N"));
			getTask().getGoqrpls().gCheckFailure();
			setGlobal("VALUE","");
		}
	

	@ValidationTrigger(item="ID")
	public void id_validate()
	{
		
		this.id_PostChange();

			Ref<NString> pId_ref = new Ref<NString>(getFormModel().getKeyBlock().getId());
			Ref<NNumber> pPidm_ref = new Ref<NNumber>(getFormModel().getKeyBlock().getPidm());
			Ref<NString> pFullName_ref = new Ref<NString>(getFormModel().getKeyBlock().getFullName());
			Ref<NString> pConfidInd_ref = new Ref<NString>(getFormModel().getKeyBlock().getConfidInd());
			Ref<NString> pDcsdInd_ref = new Ref<NString>(getFormModel().getKeyBlock().getDcsdInd());
			getTask().getGoqrpls().gValidId(pId_ref, pPidm_ref, pFullName_ref, pConfidInd_ref, pDcsdInd_ref);
			getFormModel().getKeyBlock().setId(pId_ref.val);
			getFormModel().getKeyBlock().setPidm(pPidm_ref.val);
			getFormModel().getKeyBlock().setFullName(pFullName_ref.val);
			getFormModel().getKeyBlock().setConfidInd(pConfidInd_ref.val);
			getFormModel().getKeyBlock().setDcsdInd(pDcsdInd_ref.val);
			getTask().getGoqrpls().gCheckFailure();
		}

	
	

	@ActionTrigger(action="KEY-NEXT-ITEM", item="FULL_NAME", function=KeyFunction.NEXT_ITEM)
	public void fullName_keyNexItem()
	{
		
		getGNameClass().nextItem();
	}
	
	
}