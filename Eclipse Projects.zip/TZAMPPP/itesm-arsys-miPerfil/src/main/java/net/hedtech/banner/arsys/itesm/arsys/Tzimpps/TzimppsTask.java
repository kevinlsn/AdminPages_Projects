package net.hedtech.banner.arsys.itesm.arsys.Tzimpps;

import java.util.Hashtable;
import net.hedtech.general.common.forms.BaseTask;

public class TzimppsTask extends BaseTask {
	public TzimppsTask(String taskName) {
		super(taskName);
	}
	
	public TzimppsTask(String taskName, Hashtable sharedLibraries, Hashtable parameters) {
		super(taskName, sharedLibraries, parameters);
		overrideSaveButtonBehavior(FooterButtonBehavior.HIDE);
	}
	
	@Override
	public net.hedtech.banner.arsys.itesm.arsys.Tzimpps.model.TzimppsModel getModel() {
		return (net.hedtech.banner.arsys.itesm.arsys.Tzimpps.model.TzimppsModel)super.getModel();
	}
	
	public net.hedtech.banner.arsys.itesm.arsys.Tzimpps.services.TzimppsServices getServices() {
		return (net.hedtech.banner.arsys.itesm.arsys.Tzimpps.services.TzimppsServices)getSupportCodeManager().getServices();
	}
	
	// Attached Libraries
	
	public net.hedtech.general.common.libraries.Goqrpls.GoqrplsServices getGoqrpls() {
		return (net.hedtech.general.common.libraries.Goqrpls.GoqrplsServices)getSupportCodeManager().getLibrary("GOQRPLS");
	}
}
